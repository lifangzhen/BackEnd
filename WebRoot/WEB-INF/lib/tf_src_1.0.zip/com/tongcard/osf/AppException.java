/*
 Copyright (C) 2008 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2008-3-13上午09:39:31
 TODO
 */

package com.tongcard.osf;

public class AppException extends RuntimeException implements OSFException {
	private static final long serialVersionUID = 1L;
	public AppException(String msg, Throwable ex){
        super(msg,ex);
    }

    public AppException(String errorCode) {
        this.errorCode = errorCode;
     }
    public AppException(String errorCode,String msg){
        super(msg);
        this.errorCode = errorCode;
    }
    public AppException(String errorCode,String msg,Throwable ex){
        super(msg,ex);
        this.errorCode = errorCode;
    }
    public String getErrorCode() {
        return errorCode;
    }
 
    @Override
	public String toString() {
    	if(this.errorCode != null)
    		return "error code " + this.errorCode + ' ' + super.toString();
    	else
    		return super.toString();
	}

	private String errorCode;
}
