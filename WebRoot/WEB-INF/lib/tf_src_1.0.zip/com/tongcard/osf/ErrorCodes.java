/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf;

public interface ErrorCodes {
	public static final String ERROR_SYS_GENERAL = "errors.sys.general";

}
