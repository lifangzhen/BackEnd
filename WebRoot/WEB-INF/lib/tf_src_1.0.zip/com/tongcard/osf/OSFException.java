/*
 Copyright (C) 2008 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2008-3-13上午09:39:31
 TODO
 */

package com.tongcard.osf;



public interface OSFException {
    public String getErrorCode();
    public Throwable getCause();
}
