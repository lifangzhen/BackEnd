/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf;

public class SysException extends RuntimeException implements OSFException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String errorCode;
    private Object[] attachedObjects;

    public SysException(Object[] attachedObjects, Throwable cause){
    	this(null, attachedObjects, cause);
    }
    public SysException(String errorCode, Object[] attachedObjects,
        Throwable cause) {
        super(cause);
        this.errorCode = errorCode;
        this.attachedObjects = attachedObjects;
    }

    public SysException(Object[] attachedObjects){
    	this(null, attachedObjects);
    }
    public SysException(String errorCode, Object[] attachedObjects) {
        this.errorCode = errorCode;
        this.attachedObjects = attachedObjects;
    }

    public SysException(Throwable cause){
    	this((String)null, cause);
    }
    
    public SysException(String errorCode, Throwable cause) {
        super(cause);
        this.errorCode = errorCode;
    }

    public SysException(){
    	
    }
    public SysException(String errorCode) {
        this.errorCode = errorCode;
    }

    public Object[] getAttachedObjects() {
        return attachedObjects;
    }

    public void setAttachedObjects(Object[] attachedObjects) {
        this.attachedObjects = attachedObjects;
    }

    public String getErrorCode() {
    	if(errorCode != null)
    	return errorCode;
    	else return this.getClass().getName();
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    
}
