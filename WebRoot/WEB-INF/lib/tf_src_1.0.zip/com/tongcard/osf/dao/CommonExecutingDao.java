/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-11-12
 TODO
 */
package com.tongcard.osf.dao;

/**
 * @author linyong
 *
 */
public interface CommonExecutingDao {
	public void insert(final String statementName, final Object parameterObject);
	 
	public void update(final String statementName, final Object parameterObject);
	
	public void delete(final String statementName, final Object parameterObject);
	
	public void execute(final String statementName, final Object parameterObject);
}
