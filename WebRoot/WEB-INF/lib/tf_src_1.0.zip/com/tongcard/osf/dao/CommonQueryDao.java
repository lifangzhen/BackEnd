/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.dao;

import java.util.List;
import java.util.Map;
import com.ibatis.sqlmap.client.event.RowHandler;

public interface CommonQueryDao {
	public Object queryForObject(final String statementName,
			final Object parameterObject);

	public List queryForList(final String statementName,
			final Object parameterObject);

	public List queryForList(final String statementName,
			final Object parameterObject, final int skipResults,
			final int maxResults);

	public void queryWithRowHandler(final String statementName,
			final Object parameterObject, final RowHandler rowHandler);

	public Map queryForMap(final String statementName,
			final Object parameterObject, final String keyProperty);

	public Map queryForMap(final String statementName,
			final Object parameterObject, final String keyProperty,
			final String valueProperty);

}
