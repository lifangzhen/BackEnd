/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.dao.ibatis;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;


import com.tongcard.osf.dao.CommonExecutingDao;

public class CommonExecutingDaoIbatis extends SqlMapClientDaoSupport implements
		CommonExecutingDao {
	public void insert(final String statementName, final Object parameterObject) {

		this.getSqlMapClientTemplate().insert(statementName, parameterObject);

	}

	public void update(final String statementName, final Object parameterObject) {

		this.getSqlMapClientTemplate().update(statementName, parameterObject);

	}
	
	public void delete(final String statementName, final Object parameterObject) {

		this.getSqlMapClientTemplate().delete(statementName, parameterObject);

	}
	
	public void execute(final String statementName, final Object parameterObject) {

		this.getSqlMapClientTemplate().update(statementName, parameterObject);

	}
}
