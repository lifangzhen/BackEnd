/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import com.ibatis.sqlmap.client.event.RowHandler;
import com.tongcard.osf.dao.CommonQueryDao;

public class CommonQueryDaoIbatis extends SqlMapClientDaoSupport implements
		CommonQueryDao {
	protected static final Log log = LogFactory.getLog(CommonQueryDaoIbatis.class);	
	public Object queryForObject(final String statementName,
			final Object parameterObject) {
		return this.getSqlMapClientTemplate().queryForObject(statementName,
				parameterObject);
	}

	public List queryForList(final String statementName,
			final Object parameterObject) {
		return this.getSqlMapClientTemplate().queryForList(statementName,
				parameterObject);

	}

	public List queryForList(final String statementName,
			final Object parameterObject, final int skipResults,
			final int maxResults) {
		return this.getSqlMapClientTemplate().queryForList(statementName,
				parameterObject, skipResults, maxResults);

	}

	public void queryWithRowHandler(final String statementName,
			final Object parameterObject, final RowHandler rowHandler) {
		this.getSqlMapClientTemplate().queryWithRowHandler(statementName,
				parameterObject, rowHandler);

	}

	public Map queryForMap(final String statementName,
			final Object parameterObject, final String keyProperty) {
		return this.getSqlMapClientTemplate().queryForMap(statementName,
				parameterObject, keyProperty);
	}

	public Map queryForMap(final String statementName,
			final Object parameterObject, final String keyProperty,
			final String valueProperty) {
		return this.getSqlMapClientTemplate().queryForMap(statementName,
				parameterObject, keyProperty, valueProperty);

	}
}
