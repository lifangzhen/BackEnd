/*
 Copyright (C) 2008 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2008-3-11下午03:14:50
 TODO
 */
package com.tongcard.osf.datasource;

import java.lang.ThreadLocal;

import javax.sql.DataSource;

/**
 * @author linyong 类说明：线程绑定的数据源名称
 */
public class DataSourceUtil {

	private static final ThreadLocal<String> dataSourceNameHolder = new ThreadLocal<String>();
	private static final ThreadLocal<String> secondDataSourceNameHolder = new ThreadLocal<String>();
	//给当前线程绑定归档数据源
	private static final ThreadLocal<String> archiveDataSourceNameHolder = new ThreadLocal<String>();
	/**
	 * 设置当前数据源名称
	 * @param dataSourceName
	 */
	public static void setCurrentDataSourceName(String dataSourceName) {
		dataSourceNameHolder.set(dataSourceName);
	}
	/**
	 * 获得当前数据源名称
	 */
	public static String getCurrentDataSourceName() {
		return (String) dataSourceNameHolder.get();
	}
	/**
	 * 清空当前数据源
	 */
	public static void clearCurrentDataSourceName() {
		dataSourceNameHolder.remove();
	}
	/**
	 * 根据数据源名称获取数据源
	 * @param dataSourceName 数据源名称
	 * @return
	 */
	public static DataSource getDataSource(String dataSourceName){
		return DynamicDataSource.getDataSource(dataSourceName);
	}
	/**
	 * 获取当前数据源
	 * @return
	 */
	public static DataSource getDataSource(){
		return DynamicDataSource.getDataSource(getCurrentDataSourceName());
	}
	/***************第二数据源管理 用于交叉营销等同时访问两个数据源情况***************/
	/**
	 * 设置当前数据源名称
	 * @param dataSourceName
	 */
	public static void setSecondDataSourceName(String dataSourceName) {
		secondDataSourceNameHolder.set(dataSourceName);
	}
	/**
	 * 获得当前数据源名称
	 */
	public static String getSecondDataSourceName() {
		return (String) secondDataSourceNameHolder.get();
	}
	/**
	 * 清空当前数据源
	 */
	public static void clearSecondDataSourceName() {
		secondDataSourceNameHolder.remove();
	}
	
	
	
	
	/**
	 * 设置归档数据源
	 * @param dataSourceName
	 */
	public static void setArchiveDataSourceName(String dataSourceName){
		archiveDataSourceNameHolder.set(dataSourceName);
	}
	
	/**
	 * 获得归档数据源名称
	 */
	public static String getArchiveDataSourceName() {
		return (String) archiveDataSourceNameHolder.get();
	}
	
	/**
	 * 清空归档数据源
	 */
	public static void clearArchiveDataSourceName() {
		archiveDataSourceNameHolder.remove();
	}
	
	/**
	 * 获得归档数据库
	 */
	public static DataSource getArchiveDataSource(String dataSourceName){ 
		return ArchiveDataSource.getDataSource(dataSourceName);
	}
}
