package com.tongcard.osf.idgenerator.service;

public interface IDGenerator extends IdGen{
	
    public String getNext(String seriesID);

    public String getNext(String seriesID, String argument);

    public String getNext(String seriesID, String argument1, String argument2);

    public String getNext(String seriesID, String argument1, String argument2,
                          String argument3);

    public String getNext(String seriesID, String argument1, String argument2,
                          String argument3, String argument4);
    
    
    public String[] getNext(String seriesID,int number);

    public String[] getNext(String seriesID, String argument,int number);

    public String[] getNext(String seriesID, String argument1, String argument2,int number);

    public String[] getNext(String seriesID, String argument1, String argument2,
                          String argument3,int number);

    public String[] getNext(String seriesID, String argument1, String argument2,
                          String argument3, String argument4,int number);
}
