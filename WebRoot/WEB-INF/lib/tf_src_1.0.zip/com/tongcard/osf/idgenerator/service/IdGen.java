package com.tongcard.osf.idgenerator.service;

/**
 * 流水号生成接口
 * @author Lizs
 *
 */
public interface IdGen {
	/**
	 * 生成1个流水号
	 * @param seriesID 名称
	 * @param arguments 参数
	 * @return
	 */
    String getNext(String seriesID, String[] arguments);
    /**
     * 生成多个流水号
     * @param seriesID
     * @param arguments
     * @param number
     * @return
     */
    String[] getNext(String seriesID, String[] arguments,int number);
    /**
     * 重新初始化
     *
     */
    void init();
}
