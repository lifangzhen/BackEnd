package com.tongcard.osf.idgenerator.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import junit.framework.TestCase;

public class IdGenerateTest extends TestCase {
	private ApplicationContext ac = new ClassPathXmlApplicationContext("spring-application.xml");
	
	@Override
	protected void setUp() throws Exception {

	}

	@Override
	protected void tearDown() throws Exception {
		// TODO Auto-generated method stub
		super.tearDown();
	}

	public void atestGen1(){
		IDGenerator idg = (IDGenerator)ac.getBean("idGenerator");
		long s = System.currentTimeMillis();
		String a = idg.getNext("coupon_type_no");
		idg.getNext("coupon_type_no");
		idg.getNext("coupon_type_no");
		idg.getNext("coupon_type_no");
		String b = idg.getNext("coupon_type_no");
		long e = System.currentTimeMillis();
		
		System.out.println("new id:" + a + ' ' + b + " time:" + (e-s));
	}
	public void atestGen2(){
		IDGenerator idg = (IDGenerator)ac.getBean("idGenerator");
		
		String[] result = idg.getNext("coupon_type_no",2);
		for(int i = 0 ; i < result.length; i ++ ){
			System.out.println(result[i]);
		}
	}
	public void testGen3(){
		for(String a:ac.getBeanDefinitionNames())
			System.out.println(a);
		IDGenerator idg = (IDGenerator)ac.getBean("idGenerator");
		for(int i =0; i < 100; i++){
	           Thread t = new Thread(new R(idg));
	           t.start();
	    }
		try{
			Thread.sleep(100000);
		}
		catch(Exception e){
			
		}
	}
}
class R implements Runnable{
	IDGenerator idg = null;
    public R(IDGenerator idg){
    	this.idg = idg;
    }
    public void run() {
    	for(int i =0; i < 100; i++){
	    	long s = System.currentTimeMillis();
			String id = idg.getNext("coupon_type_no");
			long e = System.currentTimeMillis();
			
			System.out.println("new id:" + id + " time:" + (e-s));
    	}
    }
    
}