package com.tongcard.osf.idgenerator.service.impl;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.tongcard.osf.idgenerator.service.IDGenerator;

public class IDGeneratorImpl extends IdGenImpl implements IDGenerator {
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public String getNext(String seriesID){
        return getNext(seriesID, (String[])null);
    }
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public String getNext(String seriesID, String argument){
        return getNext(seriesID, new String[] {argument});
    }
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public String getNext(String seriesID, String argument1, String argument2){
        return getNext(seriesID, new String[] {argument1, argument2});
    }
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public String getNext(String seriesID, String argument1, String argument2,
                          String argument3){
        return getNext(seriesID, new String[] {argument1, argument2, argument3});
    }
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public String getNext(String seriesID, String argument1, String argument2,
                          String argument3, String argument4){
        return getNext(seriesID, new String[] {argument1, argument2, argument3,
                       argument4});
    }
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public String[] getNext(String seriesID,int number){
        return getNext(seriesID, (String[])null,number);
    }
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public String[] getNext(String seriesID, String argument,int number){
        return getNext(seriesID, new String[] {argument},number);
    }
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public String[] getNext(String seriesID, String argument1, String argument2,int number){
        return getNext(seriesID, new String[] {argument1, argument2},number);
    }
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public String[] getNext(String seriesID, String argument1, String argument2,
                          String argument3,int number){
        return getNext(seriesID, new String[] {argument1, argument2, argument3},number);
    }
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public String[] getNext(String seriesID, String argument1, String argument2,
                          String argument3, String argument4,int number){
        return getNext(seriesID, new String[] {argument1, argument2, argument3,
                       argument4},number);
    }
}
