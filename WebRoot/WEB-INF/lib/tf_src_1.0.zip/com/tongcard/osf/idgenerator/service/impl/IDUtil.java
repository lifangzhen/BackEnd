package com.tongcard.osf.idgenerator.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.tongcard.osf.idgenerator.vo.Series;
import com.tongcard.osf.idgenerator.vo.CurrentMax;
import com.tongcard.osf.idgenerator.vo.CurrentMaxPK;
import com.tongcard.osf.idgenerator.service.IDGeneratorException;


/**
 * 流水号数据库操作DAO
 * 从Hibernate代码改编过来
 * @author Lizt
 *
 */
public class IDUtil implements InitializingBean{
	private static String  SEQUENCE_ID = "SEQUENCE_ID";
	private static String  SEQUENCE_RULE = "SEQUENCE_RULE";
	private static String  SEQUENCE_NAME = "SEQUENCE_NAME";
	
	private static String  CURRENT_VALUE = "CURRENT_VALUE";
	private static String  MAX_ID = "MAX_ID";
	
	private String QUERY_SERIES_SQL = "select SEQUENCE_ID,SEQUENCE_NAME,SEQUENCE_RULE from sys_series  where SEQUENCE_ID= :SEQUENCE_ID";
	private String QUERY_CURRENT_MAX_SQL = " select CURRENT_VALUE  from SYS_CURRENT_MAX   where SEQUENCE_ID=:SEQUENCE_ID and MAX_ID=:MAX_ID for update";
	private String UPDATE_CURRENT_MAX_SQL = " update SYS_CURRENT_MAX set CURRENT_VALUE = :CURRENT_VALUE where SEQUENCE_ID=:SEQUENCE_ID and MAX_ID=:MAX_ID ";
	private String INSERT_CURRENT_MAX_SQL = " insert into SYS_CURRENT_MAX(CURRENT_VALUE, SEQUENCE_ID,MAX_ID )values(:CURRENT_VALUE, :SEQUENCE_ID,:MAX_ID)";
	
	private String INCREASE_CURRENT_MAX_SQL = " update SYS_CURRENT_MAX set CURRENT_VALUE = CURRENT_VALUE + :NUMBER where SEQUENCE_ID=:SEQUENCE_ID and MAX_ID=:MAX_ID ";
	private String GET_CURRENT_MAX_SQL = " select CURRENT_VALUE  from SYS_CURRENT_MAX   where SEQUENCE_ID=:SEQUENCE_ID and MAX_ID=:MAX_ID ";
	private String NEW_CURRENT_MAX_SQL = " insert into SYS_CURRENT_MAX(CURRENT_VALUE, SEQUENCE_ID,MAX_ID )values(:NUMBER, :SEQUENCE_ID,:MAX_ID)";
		
	private DataSource dataSource = null;
	private NamedParameterJdbcTemplate jdbcTemplate = null;
    
	public IDUtil() {
    }
    /**
     * 获取指定条件的当前最大号对象,如果不存在返回一个新的
     * @param series Series
     * @param maxID String
     * @throws IDGeneratorException
     * @return CurrentMax
     */
    public CurrentMax getCurrentMaxForced(Series series, String maxID)
        throws IDGeneratorException{
        if (series == null)
            throw new IDGeneratorException("没有定义流水号","series define no found");
        //创建主键类
        CurrentMaxPK pk = new CurrentMaxPK(maxID,series);
        //获取当前最大值对象
        CurrentMax currentMax = getCurrentMax(pk);
        if (currentMax == null){
            //创建一个新的
            currentMax = new CurrentMax();
            currentMax.setComp_id(pk);
            //设置缺省值为零
            currentMax.setValue(new java.math.BigDecimal("0"));
        }
        return currentMax;
    }
    /**
     * 得到当前最大值对象
     * @param pk CurrentMaxPK
     * @return CurrentMax
     */
    public CurrentMax getCurrentMax(CurrentMaxPK pk) {
        CurrentMax cm = getCurrentMaxByJDBC(pk);
        return cm;

    }
    /**
     * 创建一个新的当前最大值对象
     * @param pk CurrentMaxPK
     * @return CurrentMax
     */
    public CurrentMax genCurrentMax(CurrentMaxPK pk){
        //创建一个新的
        CurrentMax currentMax = new CurrentMax();
        currentMax.setComp_id(pk);
        //设置缺省值为零
        currentMax.setValue(new java.math.BigDecimal("0"));
        return currentMax;
    }
    /**
     * 创建主键
     * @param series Series
     * @param maxID String
     * @return CurrentMaxPK
     */
    public CurrentMaxPK genCurrentMaxPK(Series series, String maxID){
        if (series == null)
            throw new IDGeneratorException("没有定义流水号","407000000");
        //创建主键类
        CurrentMaxPK pk = new CurrentMaxPK(maxID,series);
        return pk;
    }
    /**
     * 保存当前最大号
     * @param cm CurrentMax
     */
    public void saveCurrentMax(CurrentMax cm){
    	this.updateCurrentMaxByJDBC(cm);
    }
    /**
     * 更新当前最大号
     * @param cm CurrentMax
     */
    public void updateCurrentMax(CurrentMax cm){
    	this.updateCurrentMaxByJDBC(cm);

    }
    /**
     * 创建一个新的当前最大号
     * @param cm CurrentMax
     */
    public void createCurrentMax(CurrentMax cm){
    	this.createCurrentMaxByJDBC(cm);
    }
    /**
     * 获取流水号定义对象
     * @param id String
     * @return Series
     */
    public Series getSeries(String id){
    	Map<String,String> args = new HashMap<String,String>();
    	args.put(SEQUENCE_ID, id);
    	
    	Map result = this.jdbcTemplate.queryForMap(QUERY_SERIES_SQL, args);
    	if(result == null)
    		return null;
    	else{
	    	Series s = new Series();
	    	s.setId(id);
	    	s.setName((String)result.get(SEQUENCE_NAME));
	    	s.setRule((String)result.get(SEQUENCE_RULE));
	    	
	    	return s;
    	}
    	
		

    }
    public CurrentMax getOrGenCurrentMaxByJDBC(CurrentMaxPK pk,int number){
    	CurrentMax cm = new CurrentMax();
    	cm.setComp_id(pk);
    	Map<String,Object> args = new HashMap<String,Object>();
    	args.put(SEQUENCE_ID, pk.getSeries().getId());
    	args.put(MAX_ID, pk.getMaxId());
    	args.put("NUMBER", number);
        this.jdbcTemplate.update(INCREASE_CURRENT_MAX_SQL, args);

        List<Map> result = this.jdbcTemplate.queryForList(GET_CURRENT_MAX_SQL, args);
        Map record = null;
        if(result != null && result.size()> 0)
        	record = result.get(0);
        if (record == null){
        	this.jdbcTemplate.update(NEW_CURRENT_MAX_SQL, args);
        	cm.setValue(new BigDecimal(number));
            cm.setComp_id(pk);
        }
        else{
        	cm.setValue(new BigDecimal((record.get("CURRENT_VALUE").toString())));
        }
        return cm;
    	
    }
    public CurrentMax getCurrentMaxByJDBC(CurrentMaxPK pk){
    	
    	Map<String,String> args = new HashMap<String,String>();
    	args.put(SEQUENCE_ID, pk.getSeries().getId());
    	args.put(MAX_ID, pk.getMaxId());
        List<Map> result = this.jdbcTemplate.queryForList(QUERY_CURRENT_MAX_SQL, args);
        Map record = null;
        if(result != null && result.size()> 0)
        	record = result.get(0);
        if (record == null){
            return null;            
        }
        CurrentMax cm = new CurrentMax();
        cm.setValue(new BigDecimal((record.get("CURRENT_VALUE").toString())));
        cm.setComp_id(pk);

        return cm;
    }
    public void updateCurrentMaxByJDBC(CurrentMax cm){
    	
    	Map<String,Object> args = new HashMap<String,Object>();
    	args.put(SEQUENCE_ID, cm.getComp_id().getSeries().getId());
    	args.put(MAX_ID, cm.getComp_id().getMaxId());
    	args.put(CURRENT_VALUE, cm.getValue());
    	
        this.jdbcTemplate.update(UPDATE_CURRENT_MAX_SQL, args);
        
    }
    public void createCurrentMaxByJDBC(CurrentMax cm){
    	Map<String,Object> args = new HashMap<String,Object>();
    	args.put(SEQUENCE_ID, cm.getComp_id().getSeries().getId());
    	args.put(MAX_ID, cm.getComp_id().getMaxId());
    	args.put(CURRENT_VALUE, cm.getValue());
    	
        this.jdbcTemplate.update(INSERT_CURRENT_MAX_SQL, args);
        
    }
	public DataSource getDataSource() {
		return dataSource;
	}
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	public void afterPropertiesSet() throws Exception {
		this.jdbcTemplate = new NamedParameterJdbcTemplate(this.dataSource);
		
	}
	public void testJdbcSpeed(){
		long st = System.currentTimeMillis();
    	new JdbcTemplate(this.dataSource).queryForInt("select 1 as b from dual ");
    	
    	long en = System.currentTimeMillis();
    	System.out.println("jdbc query time:" + (en-st));
		
	}
	public void testJdbcSpeed2(){
		try{
		long st = System.currentTimeMillis();
		   // 载入驱动  
		   Class.forName("oracle.jdbc.OracleDriver");  
		  // 建立连接  
		   java.sql.Connection con =  java.sql.DriverManager.getConnection(  
		      "jdbc:oracle:thin:@192.168.1.14:1522:orcl", "tmpdb1", "naalee");  
		    // 创建状态  
		   java.sql.Statement stmt = con.createStatement();  
		  // 执行SQL语句，返回结果集  
		   java.sql.ResultSet rs = stmt.executeQuery("select 1 as b from dual");  
		   // 对结果集进行处理  
		  while (rs.next()) {  
			  System.out.println(rs.getString(1));
		  }  
		  // 释放资源  
		   stmt.close();  
		  con.close();  

		
    	
    	long en = System.currentTimeMillis();
    	System.out.println("native jdbc query time:" + (en-st));
		}
		catch(Exception e){}
		
	}
	
}
