package com.tongcard.osf.idgenerator.service.impl;

import com.tongcard.osf.idgenerator.service.IdGen;
import com.tongcard.osf.idgenerator.service.IDGeneratorException;

import com.tongcard.osf.idgenerator.vo.Series;
import com.tongcard.osf.idgenerator.vo.CurrentMax;
import com.tongcard.osf.idgenerator.vo.CurrentMaxPK;

import java.math.BigDecimal;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import java.text.SimpleDateFormat;
import java.text.Format;

import org.dom4j.Attribute;
import org.dom4j.Element;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.DocumentException;

import org.apache.commons.lang.StringUtils;


public abstract class IdGenImpl
    implements IdGen {
    
	public IdGenImpl() {
    }
	
    /**
     * 取下一个序列号(主键流水号)
     * @param seriesID String
     * @param arguments String[]
     * @return String
     */
    public String getNext(String seriesID, String[] arguments) {
   	
        if (seriesID == null) {
            throw new IDGeneratorException("参数seriesID的值不能为空","seriesID can't be null");
        }
        Series series = getSeries(seriesID);
        if (series == null) {
            throw new IDGeneratorException("未发现此流水号的定义","seriesID no found");
        }
        //当前最大的number 字符容器型
        StringBuffer numberString = new StringBuffer();
        //当前最大的number长度；缺省是10
        int length = 10;
        //结果字符串
        List result = new ArrayList();
        //最大号的maxID
        StringBuffer maxID = new StringBuffer();
        //当前长度
        int currentSize = 0;
        //总长度
        int size = 0;
        //规则Xml document
        Document doc = series.getRuleDocument();

        if (doc == null) {
            throw new IDGeneratorException("规则不能为空:" + seriesID,"rule can't be null");
        }
        else {
            try {
                
                Element root = doc.getRootElement();
                
                Attribute a = root.attribute("size");
                if(a != null)
                	try{
                		size = Integer.parseInt(a.getValue());
                	}
                	catch(Exception e){
                		throw new IDGeneratorException("流水号长度定义错误","size define error");
                	}
                	
                //参数个数
                int argNum = 0;
                //序列号个数
                int numNum = 0;
                for (Iterator iter = root.elementIterator(); iter.hasNext(); ) {
                    Element e = (Element) iter.next();
                    //元素名称
                    String name = e.getName();
                    if ("solidString".equals(name)) {
                        String content = e.attribute("content").getValue();
                        maxID.append(content);
                        result.add(content);
                        currentSize += content.length();
                    }
                    else if ("argument".equals(name)) {
                        if (arguments == null || arguments.length <= argNum) {
                            throw new IDGeneratorException("参数数量不够","more arguments required");
                        }
                        maxID.append(arguments[argNum]);
                        result.add(arguments[argNum]);
                        currentSize += arguments[argNum].length();
                        argNum++;
                    }
                     else if ("argument-invisible".equals(name)) {
                        if (arguments == null || arguments.length <= argNum) {
                            throw new IDGeneratorException("参数数量不够","more arguments required");
                        }
                        maxID.append(arguments[argNum]);
                        argNum++;
                    }
                    else if ("num".equals(name)) {
                        if (numNum > 1) {
                            throw new IDGeneratorException("规则定义中的序列数不能多于一个","num more than one ");
                        }
                        numNum++;
                        if(size == 0){
                        	length = Integer.parseInt(e.attribute("length").getValue());
                        }
                        result.add(numberString);
                    }
                    else if ("date".equals(name)){
                        String pattern = e.attribute("format").getValue();
                        try{
                            Format f = new SimpleDateFormat(pattern);
                            String date = f.format(new Date());
                            maxID.append(date);
                            currentSize += date.length();
                            result.add(date);
                        }catch(RuntimeException re){
                            throw new IDGeneratorException("规则定义中的日期格式不正确","date format error",re);
                        }
                    }
                }
            }
            catch (IDGeneratorException e) {
                throw e;
            }
            catch (RuntimeException e) {
                throw new IDGeneratorException("应用流水号生成规则时失败,原因:流水号规则定义未遵守流水号规范","rule error", e);
            }
        }
        //如果规则为空,则maxID = "*"
        if (maxID.length() == 0) {
            maxID.append("*");
        }
        //新的当前最大号
        int newMaxNumber = genNextNumber(series, maxID.toString());
        int len = 0;
        if(size != 0)
	        len = size - currentSize ;
        else
        	len = length;
        //转化为固定长度的字符串
        numberString.append(StringUtils.leftPad(String.valueOf(newMaxNumber),len,'0'));
        //新的主键
        StringBuffer newID = new StringBuffer();
        for (Iterator iter = result.iterator(); iter.hasNext(); ) {
            newID.append(iter.next());
        }
        return newID.toString();
    }
    /**
     * 生成多个流水号
     */
    public String[] getNext(String seriesID, String[] arguments, int number) {
    	if (number < 1) {
            throw new IDGeneratorException("参数number的值不能小于1","number can't be less than 1");
        }
    	if (seriesID == null) {
            throw new IDGeneratorException("参数seriesID的值不能为空","seriesID can't be null");
        }
        Series series = getSeries(seriesID);
        if (series == null) {
            throw new IDGeneratorException("未发现此流水号的定义","seriesID no found");
        }
        //当前最大的number字符容器
        StringBuffer numberStringBuffer = new StringBuffer();
        //当前最大的number长度；缺省是10
        int length = 10;
        //结果字符串
        List result = new ArrayList();
        //最大号的maxID
        StringBuffer maxID = new StringBuffer();
        //当前长度
        int currentSize = 0;
        //总长度
        int size = 0;
        //规则字符串
        String rule = series.getRule();
        if (rule == null || "".equals(rule.trim())) {
            throw new IDGeneratorException("规则不能为空","rule can't be null");
        }
        else {
            try {
                Document doc = DocumentHelper.parseText(rule);
                Element root = doc.getRootElement();
                
                Attribute a = root.attribute("size");
                if(a != null)
                	try{
                		size = Integer.parseInt(a.getValue());
                	}
                	catch(Exception e){
                		throw new IDGeneratorException("流水号长度定义错误","size define error");
                	}
                	
                //参数个数
                int argNum = 0;
                //序列号个数
                int numNum = 0;
                for (Iterator iter = root.elementIterator(); iter.hasNext(); ) {
                    Element e = (Element) iter.next();
                    //元素名称
                    String name = e.getName();
                    if ("solidString".equals(name)) {
                        String content = e.attribute("content").getValue();
                        maxID.append(content);
                        result.add(content);
                        currentSize += content.length();
                    }
                    else if ("argument".equals(name)) {
                        if (arguments == null || arguments.length <= argNum) {
                            throw new IDGeneratorException("参数数量不够","more arguments required");
                        }
                        maxID.append(arguments[argNum]);
                        result.add(arguments[argNum]);
                        currentSize += arguments[argNum].length();
                        argNum++;
                    }
                     else if ("argument-invisible".equals(name)) {
                        if (arguments == null || arguments.length <= argNum) {
                            throw new IDGeneratorException("参数数量不够","more arguments required");
                        }
                        maxID.append(arguments[argNum]);
                        argNum++;
                    }
                    else if ("num".equals(name)) {
                        if (numNum > 1) {
                            throw new IDGeneratorException("规则定义中的序列数不能多于一个","num more than one ");
                        }
                        numNum++;
                        if(size == 0){
                        	length = Integer.parseInt(e.attribute("length").getValue());
                        }
                        result.add(numberStringBuffer);
                    }
                    else if ("date".equals(name)){
                        String pattern = e.attribute("format").getValue();
                        try{
                            Format f = new SimpleDateFormat(pattern);
                            String date = f.format(new Date());
                            maxID.append(date);
                            currentSize += date.length();
                            result.add(date);
                        }catch(RuntimeException re){
                            throw new IDGeneratorException("规则定义中的日期格式不正确","date format error",re);
                        }
                    }
                }
            }
            catch (DocumentException e) {
                throw new IDGeneratorException("解析流水号规则失败","rule parse failed", e);
            }
            catch (IDGeneratorException e) {
                throw e;
            }
            catch (RuntimeException e) {
                throw new IDGeneratorException("应用流水号生成规则时失败,原因:流水号规则定义未遵守流水号规范","rule error", e);
            }
        }
        //如果规则为空,则maxID = "*"
        if (maxID.length() == 0) {
            maxID.append("*");
        }
        //计算所需长度；确定补0个数
        int len = 0;
        if(size != 0)
	        len = size - currentSize ;
        else
        	len = length;
        
        //新的当前最大号
        int[] newMaxNumber = genNextNumbers(series, maxID.toString(),number);
        String[] numberSet = new String[newMaxNumber.length];
        for(int i = 0; i < newMaxNumber.length; i++){
        	//转化为固定长度的字符串
        	numberStringBuffer.delete(0, numberStringBuffer.length());
            numberStringBuffer.append(StringUtils.leftPad(String.valueOf(newMaxNumber[i]),len,'0'));
            //新的主键
            StringBuffer newID = new StringBuffer();
            for (Iterator iter = result.iterator(); iter.hasNext(); ) {
                newID.append(iter.next());
            }
            numberSet[i] = newID.toString();
        }
        return numberSet;
	}
    /**
     * 生成一个新的最大号，此方法需要在一个新的事物方法中运行
     * 如果想避免插入数据并发冲突，可以对currentMax加锁，不过性能将大受影响
     * @param series Series
     * @param maxID <any>
     * @return BigDecimal
     */
     public int genNextNumber(Series series, String maxID) {

//        CurrentMaxPK pk = util.genCurrentMaxPK(series, maxID);
//        CurrentMax cm =util.getOrGenCurrentMaxByJDBC(pk, 1);
//        return cm.getValue().intValue();

// 		//原始方法
        int newValue;
        boolean isNew = false;        
        CurrentMaxPK pk = util.genCurrentMaxPK(series, maxID);
        CurrentMax cm = util.getCurrentMax(pk);
        if (cm == null) {
            isNew = true;
            cm = util.genCurrentMax(pk);
        }
        BigDecimal oldValue = cm.getValue();
        if (oldValue == null) {
            oldValue = new BigDecimal("0");
        }
        newValue = oldValue.intValue() + 1;
        
        cm.setValue(new BigDecimal(newValue));
        if(isNew){
            try{
            util.createCurrentMax(cm);
            }catch(RuntimeException e){
                if(util.getCurrentMax(pk) != null)//是主键重复，则迭代此函数
                    newValue = genNextNumber(series,maxID);
                else
                    throw e;
            }
        }
        else
            util.updateCurrentMax(cm);
        return newValue;
    }
     /**
      * 生成多个新的最大号，此方法需要在一个新的事物方法中运行
      * @param series Series
      * @param maxID String
      * @param number int
      * @return int[]
      */
      public int[] genNextNumbers(Series series, String maxID,int number) {
    	  
//    	  CurrentMaxPK pk = util.genCurrentMaxPK(series, maxID);
//          CurrentMax cm =util.getOrGenCurrentMaxByJDBC(pk, 1);
//          int newLastValue = cm.getValue().intValue();
//          //处理结果
//          int[] result = new int[number];
//          for(int i = 0; i < number; i++){
//         	 result[i] = newLastValue - i;
//          }
//          return result;
//         //旧的方法          
         int intOldValue;
         int newLastValue;
         boolean isNew = false;
         CurrentMaxPK pk = util.genCurrentMaxPK(series, maxID);
         CurrentMax cm = util.getCurrentMax(pk);
         if (cm == null) {
             isNew = true;
             cm = util.genCurrentMax(pk);
         }
         BigDecimal oldValue = cm.getValue();
         if (oldValue == null) {
             oldValue = new BigDecimal("0");
         }
         intOldValue = oldValue.intValue();
         newLastValue = oldValue.intValue() + number;
         cm.setValue(new BigDecimal(newLastValue));
         //service.saveCurrentMax(cm);
         if(isNew){
             try{
            	 util.createCurrentMax(cm);
             }catch(RuntimeException e){
                 if(util.getCurrentMax(pk) != null)//是主键重复，则迭代此函数
                     return genNextNumbers(series,maxID, number);
                 else
                     throw e;
             }
         }
         else
             util.updateCurrentMax(cm);
         //处理结果
         int[] result = new int[number];
         for(int i = 0; i < number; i++){
        	 result[i] = intOldValue + i + 1;
         }
         return result;
     }
    /**
     * 取流水号定义，用cache缓存
     * @param seriesID String
     * @return Series
     */
    public Series getSeries(String seriesID){
        Series series = (Series)cache.get(seriesID);
        if (series == null){
            series = util.getSeries(seriesID);
            cache.put(seriesID, series);
        }
        return series;
    }
    public IDUtil getUtil() {
        return util;
    }

    public void setUtil(IDUtil util) {
        this.util = util;
    }
    /**
    * dao工具类
    */
    private IDUtil util;

    private Map cache = new HashMap();

	public void init() {
		cache = new HashMap();
	}
}