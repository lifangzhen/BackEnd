package com.tongcard.osf.idgenerator.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


public class CurrentMax implements Serializable {

    private CurrentMaxPK comp_id;


    private BigDecimal value;


    private String type;

    private String affix;

    /** full constructor */
    public CurrentMax(CurrentMaxPK comp_id, BigDecimal value, String type, String affix) {
        this.comp_id = comp_id;
        this.value = value;
        this.type = type;
        this.affix = affix;
    }

    /** default constructor */
    public CurrentMax() {
    }

    /** minimal constructor */
    public CurrentMax(CurrentMaxPK comp_id) {
        this.comp_id = comp_id;
    }

    public CurrentMaxPK getComp_id() {
        return this.comp_id;
    }

    public void setComp_id(CurrentMaxPK comp_id) {
        this.comp_id = comp_id;
    }

    public BigDecimal getValue() {
        return this.value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAffix() {
        return this.affix;
    }

    public void setAffix(String affix) {
        this.affix = affix;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("comp_id", getComp_id())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof CurrentMax) ) return false;
        CurrentMax castOther = (CurrentMax) other;
        return new EqualsBuilder()
            .append(this.getComp_id(), castOther.getComp_id())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getComp_id())
            .toHashCode();
    }

}
