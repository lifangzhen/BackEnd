package com.tongcard.osf.idgenerator.vo;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class CurrentMaxPK implements Serializable {


    private String maxId;


    private Series series;

    /** full constructor */
    public CurrentMaxPK(String maxId, Series series) {
        this.maxId = maxId;
        this.series = series;
    }

    /** default constructor */
    public CurrentMaxPK() {
    }

    public String getMaxId() {
        return this.maxId;
    }

    public void setMaxId(String maxId) {
        this.maxId = maxId;
    }

    public Series getSeries() {
        return this.series;
    }

    public void setSeries(Series series) {
        this.series = series;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("maxId", getMaxId())
            .append("series", getSeries())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof CurrentMaxPK) ) return false;
        CurrentMaxPK castOther = (CurrentMaxPK) other;
        return new EqualsBuilder()
            .append(this.getMaxId(), castOther.getMaxId())
            .append(this.getSeries(), castOther.getSeries())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getMaxId())
            .append(getSeries())
            .toHashCode();
    }

}
