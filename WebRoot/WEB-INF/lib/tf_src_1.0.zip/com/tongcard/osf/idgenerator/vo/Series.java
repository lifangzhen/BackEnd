package com.tongcard.osf.idgenerator.vo;

import java.io.Serializable;
import java.util.Set;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;

import com.tongcard.osf.idgenerator.service.IDGeneratorException;

public class Series implements Serializable {

    private String id;

    private String name;

    private String rule;

    private String affix;

    private Document ruleDocument = null;

    /** full constructor */
    public Series(String id, String name, String rule, String affix) {
        this.id = id;
        this.name = name;
        this.rule = rule;
        this.affix = affix;
    }

    /** default constructor */
    public Series() {
    }

    /** minimal constructor */
    public Series(String id, Set currentMaxs) {
        this.id = id;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRule() {
        return this.rule;
    }

    public void setRule(String rule) {
        this.rule = rule;
    }
    public Document getRuleDocument() {
		if(ruleDocument != null)
			return ruleDocument;
		else if (rule == null){
			return null;
		}
		else {
			try{
				Document doc = DocumentHelper.parseText(rule);
				this.ruleDocument = doc;
				return doc;
			}
			catch (DocumentException e) {
                throw new IDGeneratorException("解析流水号规则失败:" + rule,"rule parse failed", e);
            }
			
		}
	}
    public String getAffix() {
        return this.affix;
    }

    public void setAffix(String affix) {
        this.affix = affix;
    }

    public String toString() {
        return new ToStringBuilder(this)
            .append("id", getId())
            .toString();
    }

    public boolean equals(Object other) {
        if ( !(other instanceof Series) ) return false;
        Series castOther = (Series) other;
        return new EqualsBuilder()
            .append(this.getId(), castOther.getId())
            .isEquals();
    }

    public int hashCode() {
        return new HashCodeBuilder()
            .append(getId())
            .toHashCode();
    }

	

}
