/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.mail;

import java.util.Map;

public interface SimpleMailSender {
	void send(String from, String replyTo, String[] to,  String[] cc, String subject, String text);
	void send(String[] to, String[] cc, String subject, String text);
	void send(String to, String subject, String text);
	void send(String from, String replyTo, String[] to, String[] cc, String subject, String template, Map context);
	void send(String[] to, String[] cc, String subject, String template, Map context);
	void send(String to, String subject, String template, Map context);
}
