/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.mail.impl;

import java.util.Map;

import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import com.tongcard.osf.mail.SimpleMailSender;
import com.tongcard.osf.template.TemplateEngine;

public class SimpleMailSenderImpl implements SimpleMailSender{
	private String from;
	private String replyTo;
	private MailSender mailSender;
	private TemplateEngine templateEngine;
	
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public MailSender getMailSender() {
		return mailSender;
	}
	public void setMailSender(MailSender mailSender) {
		this.mailSender = mailSender;
	}
	public String getReplyTo() {
		return replyTo;
	}
	public void setReplyTo(String replyTo) {
		this.replyTo = replyTo;
	}
	public TemplateEngine getTemplateEngine() {
		return templateEngine;
	}
	public void setTemplateEngine(TemplateEngine templateEngine) {
		this.templateEngine = templateEngine;
	}
	
	public void send(String from, String replyTo, String[] to,  String[] cc, String subject, String text){
		SimpleMailMessage message = new SimpleMailMessage();
		
		message.setFrom(from);
		message.setReplyTo(replyTo);
		message.setTo(to);
		message.setCc(cc);
		message.setSubject(subject);
		message.setText(text);
		mailSender.send(message);
	}
	public void send(String[] to, String[] cc, String subject, String text){
		send(from, replyTo, to, cc, subject, text);
	}
	public void send(String to, String subject, String text){
		send(from, replyTo, new String[]{to}, null, subject, text);
	}
	public void send(String from, String replyTo, String[] to, String[] cc, String subject, String template, Map context){
		String text = this.templateEngine.evaluate(template, context);
		send(from, replyTo, to, cc, subject, text);
	}
	public void send(String[] to, String[] cc, String subject, String template, Map context){
		String text = this.templateEngine.evaluate(template, context);
		send(to, cc, subject, text);
	}
	public void send(String to, String subject, String template, Map context){
		String text = this.templateEngine.evaluate(template, context);
		send(to, subject, text);
	}
}
