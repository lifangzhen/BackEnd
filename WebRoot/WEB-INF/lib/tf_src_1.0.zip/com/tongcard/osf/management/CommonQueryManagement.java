/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-11-12
 TODO
 */
package com.tongcard.osf.management;

import java.util.List;

/**
 * @author linyong
 *
 */
public interface CommonQueryManagement {
	public Object queryForObject(String statementName,Object parameterObject);
	public List queryForList(String statementName,Object parameterObject);
}
