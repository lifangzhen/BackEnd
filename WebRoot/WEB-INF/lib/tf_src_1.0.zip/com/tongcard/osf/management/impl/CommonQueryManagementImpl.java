/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-11-12
 TODO
 */
package com.tongcard.osf.management.impl;
import java.util.List;
import com.tongcard.osf.management.CommonQueryManagement;
import com.tongcard.osf.dao.CommonQueryDao;
import org.springframework.transaction.annotation.Transactional;
/**
 * @author linyong
 *
 */
@Transactional(readOnly = true)
public class CommonQueryManagementImpl implements CommonQueryManagement {
	private CommonQueryDao commonQueryDao;

	public CommonQueryDao getCommonQueryDao() {
		return commonQueryDao;
	}

	public void setCommonQueryDao(CommonQueryDao commonQueryDao) {
		this.commonQueryDao = commonQueryDao;
	}
	
	public Object queryForObject(String statementName,Object parameterObject) {
		return commonQueryDao.queryForObject(statementName, parameterObject);
	}
	
	public List queryForList(String statementName,Object parameterObject){
		
		return commonQueryDao.queryForList(statementName, parameterObject);
	}
}
