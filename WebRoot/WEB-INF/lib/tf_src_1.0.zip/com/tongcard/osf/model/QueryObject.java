/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-11-12
 TODO
 */
package com.tongcard.osf.model;

/**
 * @author linyong
 *
 */
public abstract class QueryObject{
	private Integer start;
	private Integer end;
	/**
	 * @return the begin
	 */
	protected final Integer getStart() {
		return start;
	}
	/**
	 * @param begin the begin to set
	 */
	protected final void setStart(Integer start) {
		this.start = start;
	}
	/**
	 * @return the end
	 */
	protected final Integer getEnd() {
		return end;
	}
	/**
	 * @param end the end to set
	 */
	protected final void setEnd(Integer end) {
		this.end = end;
	}
	
	protected final void setStartAndEnd(Integer currentPage,Integer pageSize) {
		this.start = currentPage*pageSize-(pageSize-1);
		this.end = currentPage*pageSize;
	}
}
