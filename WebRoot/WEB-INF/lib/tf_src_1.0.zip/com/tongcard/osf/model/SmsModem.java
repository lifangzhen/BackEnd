	/*
	 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

	 Author: 
	 Created: Feb 27, 2008
	 TODO
	 */
package com.tongcard.osf.model;

/**
 * @author dingwei
 *
 */
public class SmsModem {

	private Long taskId;
	private String content;
	private String number;
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public Long getTaskId() {
		return taskId;
	}
	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}
	
	
}
