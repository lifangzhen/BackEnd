/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.model;

import java.util.Date;

public class UserLoginLog implements java.io.Serializable {
	private long id = -1;
	private String userName;
	private Date loginTime;
	private Date logoutTime;
	private String duration;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Date getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}
	public Date getLogoutTime() {
		return logoutTime;
	}
	public void setLogoutTime(Date logoutTime) {
		this.logoutTime = logoutTime;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
}
