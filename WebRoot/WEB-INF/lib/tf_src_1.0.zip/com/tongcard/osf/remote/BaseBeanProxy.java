/*
 Copyright (C) 2008 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2008-4-22下午03:54:16
 TODO
 */
package com.tongcard.osf.remote;

import org.springframework.context.ApplicationContext;

/**
 * @author linyong
 * 类说明：
 */
public abstract class BaseBeanProxy {
    public Object getService(String serviceName) {
    	return null;
    }
    
    protected final Object getBean(ApplicationContext ctx,String beanName) {
    	try{
		    Object service = ctx.getBean(beanName);
		return service;
    	}catch(Exception e){
    		e.printStackTrace();
    		return null;
    	}
    }
}
