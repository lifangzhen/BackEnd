/*
 Copyright (C) 2008 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2008-3-25上午09:50:24
 TODO
 */
package com.tongcard.osf.remote;

/**
 * @author linyong
 * 类说明：
 */
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
public class CXFClientGeneratorImpl implements ProxyClientGenerator{

	public final Object getClient(Class clazz, String url) {
		JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
		factory.setServiceClass(clazz);
		factory.setAddress(url);
		Object service = factory.create();
		return service;
	}
	
}
