/*
 Copyright (C) 2008 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2008-3-25上午09:50:24
 TODO
 */
package com.tongcard.osf.remote;

/**
 * @author linyong
 * 类说明：
 */
public interface ProxyClientGenerator {
	public Object getClient(Class clazz, String url);
}
