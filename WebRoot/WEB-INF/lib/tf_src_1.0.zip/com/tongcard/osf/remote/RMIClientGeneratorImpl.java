/*
 Copyright (C) 2008 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2008-3-25上午09:50:24
 TODO
 */
package com.tongcard.osf.remote;

import org.springframework.remoting.rmi.RmiProxyFactoryBean;
/**
 * @author linyong
 * 类说明：
 */
public class RMIClientGeneratorImpl implements ProxyClientGenerator{

	public final Object getClient(Class clazz, String url) {
		RmiProxyFactoryBean proxy =new RmiProxyFactoryBean();
    	proxy.setServiceUrl(url);
    	proxy.setServiceInterface(clazz);
    	proxy.afterPropertiesSet();
		Object service = proxy.getObject();
		return service;
	}
}
