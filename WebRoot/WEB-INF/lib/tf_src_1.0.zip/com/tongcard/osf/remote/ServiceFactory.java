/*
 Copyright (C) 2008 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2008-3-25上午09:50:24
 TODO
 */
package com.tongcard.osf.remote;

import java.util.Hashtable;
import java.util.List;
import java.util.ArrayList;
import org.springframework.beans.factory.InitializingBean;

/**
 * @author linyong
 * 类说明：
 */
public abstract class ServiceFactory implements InitializingBean {
	private static Hashtable<String,Object> serviceObjectCache = new Hashtable<String,Object>();
	private String prefixURL;	
	private BaseBeanProxy beanProxy;
	private List servicePoolList=new ArrayList();
	private ProxyClientGenerator proxyClientGenerator;
	public ProxyClientGenerator getProxyClientGenerator() {
		return proxyClientGenerator;
	}
	
	public void setProxyClientGenerator(ProxyClientGenerator proxyClientGenerator) {
		this.proxyClientGenerator = proxyClientGenerator;
	}
	
	public void setPrefixURL(String prefixURL) {
		this.prefixURL = prefixURL;
	}
	
	public ServiceFactory(){

	}
	
    public void afterPropertiesSet() throws Exception {
       
 
    }
    
    public Object getLocalService(String serviceName){
    	Object service = beanProxy.getService(serviceName);
		return service;
    }
    
    public Object getRemoteService(Class clazz, String serviceName){
    	return null;
    }
    
	protected Object getRomoteServiceClient(Class clazz, String serviceName){
		Object serviceObject=null;
		if (serviceObjectCache.containsKey(serviceName)) {
			serviceObject=serviceObjectCache.get(serviceName);
		} else {
			serviceObject=getRomoteClient(clazz,serviceName);
		}
		return serviceObject;
	}
	
	private Object getRomoteClient(Class clazz, String serviceName){
		String serviceUrl = prefixURL + serviceName;
		Object serviceObject=null;
		if(proxyClientGenerator==null){
			//default remote call
		  setProxyClientGenerator(new RMIClientGeneratorImpl());
		}
		serviceObject=proxyClientGenerator.getClient(clazz, serviceUrl);
		serviceObjectCache.put(serviceName, serviceObject);
		return serviceObject;
	}

	public List getServicePoolList() {
		return servicePoolList;
	}

	public void setServicePoolList(List servicePoolList) {
		this.servicePoolList = servicePoolList;
	}

	public BaseBeanProxy getBeanProxy() {
		return beanProxy;
	}

	public void setBeanProxy(BaseBeanProxy beanProxy) {
		this.beanProxy = beanProxy;
	}


}
