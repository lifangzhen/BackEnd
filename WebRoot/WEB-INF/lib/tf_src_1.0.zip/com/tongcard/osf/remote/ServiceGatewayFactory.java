/*
 Copyright (C) 2008 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2008-3-25上午09:50:24
 TODO
 */
package com.tongcard.osf.remote;

import java.lang.reflect.Method;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.framework.ProxyFactory;

import com.tongcard.osf.OSFException;
import com.tongcard.osf.AppException;
/**
 * @author linyong
 * 类说明：
 */
public class ServiceGatewayFactory extends ServiceFactory{
    private Class  serviceInterface;
    private String serviceName;
    private String displayTime="false";
	public Object getRemoteService(Class clazz, String serviceName){
		setServiceInterface(clazz);
		setServiceName(serviceName);
		Object serviceObject=getObject();
		return serviceObject;
	}	
    /*
     * @see org.springframework.beans.factory.FactoryBean#getObject()
     */
    private Object getObject(){
        return ProxyFactory.getProxy(getObjectType(), new ServiceGatewayInterceptor());
    }

    /*
     * @see org.springframework.beans.factory.FactoryBean#getObjectType()
     */
    private Class getObjectType() {
        return serviceInterface;
    }

    private class ServiceGatewayInterceptor implements MethodInterceptor {

        /*
         * @see org.aopalliance.intercept.MethodInterceptor#invoke(org.aopalliance.intercept.MethodInvocation)
         */
        public Object invoke(MethodInvocation invocation) throws Throwable {
            long start = System.currentTimeMillis();
            String resultCode="SUCESS";
            try
            {
                Method method = invocation.getMethod();
                Object[] args = invocation.getArguments();
                /*java.util.Map map=(java.util.Map)args[0];
                if(ThreadLocalUtils.getDataSource()==null||ThreadLocalUtils.getDataSource().equals("")){
                	if(map.get(OSFConstants.dataSource)==null||map.get(OSFConstants.dataSource).equals("")){
                    	System.out.println("APPLICATION ERROR the error is:DataSource is not set,please set datasource first!");
                    	return null;               		
                	}
                }else{
                    map.put(OSFConstants.dataSource, ThreadLocalUtils.getDataSource());
                }*/
                Object client = getClient();
                return method.invoke(client, args);
            } catch (Exception e)
            {
            	if (e.getCause() instanceof OSFException){
					resultCode = ((OSFException) e.getCause()).getErrorCode();
					System.out.println("ERROR <APPLICATION> OCCUR the error is:"+resultCode);
		               throw new AppException(resultCode);
					
				}else{
					System.out.println("ERROR <SYSTEM> OCCUR the error is:");
					e.printStackTrace();
					return null;
				}
            } finally
            {
               long end = System.currentTimeMillis();
               if("true".equals(displayTime)){
                 System.out.println("INFO "+invocation.getMethod().getDeclaringClass().getName()+"."+invocation.getMethod().getName()+" remote call times=:"+(end - start) +"ms");
               }
            }
        }

        private Object getClient() {
        	return getRomoteServiceClient(serviceInterface,serviceName);
        }

    }


    /**
     * @param serviceInterface
     *            the serviceInterface to set
     */
    public void setServiceInterface(Class serviceInterface) {
        this.serviceInterface = serviceInterface;
    }


	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getDisplayTime() {
		return displayTime;
	}
	public void setDisplayTime(String displayTime) {
		this.displayTime = displayTime;
	}
}
