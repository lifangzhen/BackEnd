/*
 Copyright (C) 2008 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2008-3-27上午10:44:54
 TODO
 */
package com.tongcard.osf.remote;

/**
 * @author linyong
 * 类说明：
 */
public class ServicePoolMappingConfig {
	private Class serviceInterface;
	private String serviceName;
	public Class getServiceInterface() {
		return serviceInterface;
	}
	public void setServiceInterface(Class serviceInterface) {
		if (serviceInterface != null && !serviceInterface.isInterface()) {
			throw new IllegalArgumentException("'serviceInterface' must be an interface");
		}
		this.serviceInterface = serviceInterface;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
}
