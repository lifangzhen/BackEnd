/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.service;

public class CodeConverter {
	private MultiQueryExecutor queryExecutor;
	private String codeSet;
	public String getCodeSet() {
		return codeSet;
	}
	public void setCodeSet(String codeSet) {
		this.codeSet = codeSet;
	}
	public MultiQueryExecutor getQueryExecutor() {
		return queryExecutor;
	}
	public void setQueryExecutor(MultiQueryExecutor queryExecutor) {
		this.queryExecutor = queryExecutor;
	}
	
	public String fromCode(String code){
		if(code == null || code.equals("")) return "";
		return queryExecutor.getDescriptionForCode(this.codeSet, code);
		
	}
}
