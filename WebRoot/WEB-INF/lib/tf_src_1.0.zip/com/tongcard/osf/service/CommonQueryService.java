/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-11-12
 TODO
 */
package com.tongcard.osf.service;

import java.util.List;

/**
 * @author linyong
 *
 */
public interface CommonQueryService {
	public Object queryForObject(String statementName,Object parameterObject);
	public Object[] queryForObjectArray(String statementName,Object parameterObject); 
	public List queryForList(String statementName,Object parameterObject);
	public int queryForObjectArrayCount(String statementName,Object parameterObject);
	public long queryForObjectSum(String statementName,Object parameterObject);
}
