/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.service;

import java.util.List;
import java.util.Map;

public interface MultiQueryExecutor {
	Map execute();
	List getCodeSet(String name);
	String getDescriptionForCode(String codeSet, String value);
}
