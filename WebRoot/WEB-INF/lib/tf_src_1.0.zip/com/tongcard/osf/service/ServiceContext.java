/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.service;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface ServiceContext {
	public String getResult();
	public void setResult(String result);
	public UserProfile getUserInfo();
	public void setUserInfo(UserProfile userInfo);
	public String getSerialNo();
	public void setSerialNo(String serialNo);
	public Date getRequestTime();
	public void setRequestTime(Date date);
	public Date getProcessTime();
	public void setProcessTime(Date date);
	public void setException(Throwable e);
	public Throwable getException();
	
	public HttpServletRequest getServletRequest();
	public HttpServletResponse getServletResponse();
	public void setAttribute(String name, Object attribute);
	public Object getAttribute(String name);
	
	public String RESULT_SUCCESS = "success";
	public String RESULT_FAILURE = "failure";
	
}
