/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.service;


public class SqlExecutingContext {
	private String statementName;
	private Object parameter;
	
	public SqlExecutingContext(String statementName, Object parameter){
		this.statementName = statementName;
		this.parameter = parameter;
	}
	public Object getParameter() {
		return parameter;
	}
	public void setParameter(Object parameter) {
		this.parameter = parameter;
	}
	public String getStatementName() {
		return statementName;
	}
	public void setStatementName(String statementName) {
		this.statementName = statementName;
	}
	
}
