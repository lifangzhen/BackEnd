/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.service;

public interface SqlExecutingService {
	public void execute(ServiceContext serviceContext, SqlExecutingContext sqlExecutingContext);
}
