/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-11-12
 TODO
 */
package com.tongcard.osf.service.impl;
import java.util.List;
import com.tongcard.osf.management.CommonQueryManagement;
import com.tongcard.osf.service.CommonQueryService;

/**
 * @author linyong
 *
 */
public class CommonQueryServiceImpl implements CommonQueryService {
private CommonQueryManagement commonQueryManagement;

public CommonQueryManagement getCommonQueryManagement() {
	return commonQueryManagement;
}

public void setCommonQueryManagement(CommonQueryManagement commonQueryManagement) {
	this.commonQueryManagement = commonQueryManagement;
}

public Object queryForObject(String statementName,Object parameterObject) {
	return commonQueryManagement.queryForObject(statementName, parameterObject);
}

public Object[] queryForObjectArray(String statementName,Object parameterObject) {
	List objectList = commonQueryManagement.queryForList(statementName, parameterObject);
	Object[] objectArray =  new Object[objectList.size()];
	objectList.toArray(objectArray);
	return objectArray;		
}

public List queryForList(String statementName,Object parameterObject) {
	List objectList = commonQueryManagement.queryForList(statementName, parameterObject);
	return objectList;		
}

public int queryForObjectArrayCount(String statementName,Object parameterObject) {
	Integer objectCount=0;
	Object object=commonQueryManagement.queryForObject(statementName, parameterObject);
	if(object!=null){
		objectCount = (Integer)object;
	}
	return objectCount.intValue();		
}
public long queryForObjectSum(String statementName,Object parameterObject) {
	Long objectCount=(long)0;
	Object object=commonQueryManagement.queryForObject(statementName, parameterObject);
	if(object!=null){
		objectCount = (Long)object;
	}
	return objectCount.longValue();		
}
}
