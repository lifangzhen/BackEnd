/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.tongcard.osf.dao.CommonQueryDao;
import com.tongcard.osf.service.MultiQueryExecutor;
import com.tongcard.osf.web.CodeItem;

public class MultiQueryExecutorImpl implements MultiQueryExecutor {
	private CommonQueryDao commonQueryDao;

	private Map configs = new HashMap();

	public CommonQueryDao getCommonQueryDao() {
		return commonQueryDao;
	}

	public void setCommonQueryDao(CommonQueryDao commonQueryDao) {
		this.commonQueryDao = commonQueryDao;
	}

	public Map execute() {
		Map result = new HashMap();
		Set keys = configs.keySet();
		Iterator iterator = keys.iterator();
		while (iterator.hasNext()) {
			String key = (String) iterator.next();
			String query = (String) configs.get(key);
			result.put(key, commonQueryDao.queryForList(query, key));
		}
		return result;
	}

	public Map getConfigs() {
		return configs;
	}

	public void setConfigs(Map configs) {
		this.configs = configs;
	}

	public List getCodeSet(String name) {
		String query = (String) configs.get(name);
		if (query == null)
			return new ArrayList();
		try {
			return commonQueryDao.queryForList(query, name);
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList();
		}
	}
	
	public String getDescriptionForCode(String codeSet, String value){
		List codeSetList = getCodeSet(codeSet);
		for(int i = 0; i < codeSetList.size(); i ++){
			CodeItem codeItem = (CodeItem)codeSetList.get(i);
			if(codeItem.getCode().equals(value))
				return codeItem.getDescription();
		}
		return "";
		
	}
}
