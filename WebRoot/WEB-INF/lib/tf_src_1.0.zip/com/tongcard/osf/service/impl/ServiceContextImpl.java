/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tongcard.osf.service.ServiceContext;
import com.tongcard.osf.service.UserProfile;

public class ServiceContextImpl implements ServiceContext {
	private Date processTime;
	private Date requestTime;
	private String result = RESULT_SUCCESS;
	private String serialNo;
	private UserProfile userInfo;
	private Throwable exception;
	private Map attributes = new HashMap();
	private HttpServletRequest httpServletRequest;
	private HttpServletResponse httpServletResponse;
	
	public Throwable getException() {
		return exception;
	}
	public void setException(Throwable exception) {
		this.exception = exception;
	}
	public Date getProcessTime() {
		return processTime;
	}
	public void setProcessTime(Date processTime) {
		this.processTime = processTime;
	}
	public Date getRequestTime() {
		return requestTime;
	}
	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public UserProfile getUserInfo() {
		return userInfo;
	}
	public void setUserInfo(UserProfile userInfo) {
		this.userInfo = userInfo;
	}
	
	public Object getAttribute(String name){
		return attributes.get(name);
	}
	
	public void setAttribute(String name, Object attribute){
		this.attributes.put(name, attribute);
	}
	
	public HttpServletRequest getServletRequest(){
		return this.httpServletRequest;
	}
	
	public void setServletRequest(HttpServletRequest request){
		this.httpServletRequest = request;
	}
	
	public HttpServletResponse getServletResponse(){
		return this.httpServletResponse;
	}
	
	public void setServletResponse(HttpServletResponse response){
		this.httpServletResponse = response;
	}
}
