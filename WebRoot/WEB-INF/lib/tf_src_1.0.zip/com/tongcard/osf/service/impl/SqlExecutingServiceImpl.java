/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.service.impl;

import com.tongcard.osf.dao.CommonExecutingDao;
import com.tongcard.osf.service.ServiceContext;
import com.tongcard.osf.service.SqlExecutingContext;
import com.tongcard.osf.service.SqlExecutingService;

public class SqlExecutingServiceImpl implements SqlExecutingService {
	private String statement;

	private Object parameter;

	private CommonExecutingDao commonExecutingDao;

	public CommonExecutingDao getCommonExecutingDao() {
		return commonExecutingDao;
	}

	public void setCommonExecutingDao(CommonExecutingDao commonExecutingDao) {
		this.commonExecutingDao = commonExecutingDao;
	}

	public Object getParameter() {
		return parameter;
	}

	public void setParameter(Object parameter) {
		this.parameter = parameter;
	}

	public String getStatement() {
		return statement;
	}

	public void setStatement(String statement) {
		this.statement = statement;
	}

	public void execute(ServiceContext serviceContext,
			SqlExecutingContext sqlExecutingContext) {
		String sqlStatement = null;
		Object parameterObject = null;
		if (sqlExecutingContext != null) {
			sqlStatement = sqlExecutingContext.getStatementName();
			parameterObject = sqlExecutingContext.getParameter();
		}
		if (sqlStatement == null)
			sqlStatement = this.statement;
		if (parameterObject == null)
			parameterObject = this.parameter;
		commonExecutingDao.execute(sqlStatement, parameterObject);
	}
}
