package com.tongcard.osf.sms;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class DynamicProxyJob implements Job {
	public void execute(JobExecutionContext jec) throws JobExecutionException {
		JobDataMap jdm = jec.getJobDetail().getJobDataMap();
		Job tt = (Job)jdm.get("job");
		tt.execute(jec);
	}

}
