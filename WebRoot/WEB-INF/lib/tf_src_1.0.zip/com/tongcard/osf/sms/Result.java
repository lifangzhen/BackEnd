package com.tongcard.osf.sms;

import java.util.Date;

/**
 * 短信发送结果
 */
public class Result implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5979148372308139884L;
	/**
	 * 短信编号
	 */
	private String smsId;
	/**
	 * 是否成功
	 */
	private boolean isSuccess;
	/**
	 * 错误类型
	 */
	private String errorType;
	/**
	 * 错误详细信息
	 */
	private String errorInfo;

	/**
	 * 手机号
	 */
	private String mobile;
	/**
	 * 发送时间
	 */
	private Date time;
	
	private String content;
	
	
	public static String ROUTEWAY_ERROR ="发送失败";
	public static String INVALID_CODE = "无效号码";
	public static String CUSTOMER_IS_BLACK = "黑名单";
	public String getSmsId() {
		return smsId;
	}
	public void setSmsId(String smsId) {
		this.smsId = smsId;
	}
	public boolean isSuccess() {
		return isSuccess;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public String getErrorType() {
		return errorType;
	}
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}
	public String getErrorInfo() {
		return errorInfo;
	}
	public void setErrorInfo(String errorInfo) {
		this.errorInfo = errorInfo;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
}
