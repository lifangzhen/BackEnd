package com.tongcard.osf.sms;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.core.JdbcTemplate;
import com.tongcard.osf.util.UUIDGenerator;

public class SimpleSmsBlackService implements SmsBlackService, InitializingBean {
	protected static Log log = LogFactory.getLog(SimpleSmsBlackService.class);
	private static final String INSERT_SMS_BLACK_SQL = "insert into sms_black_list(black_id,customer_id,merchant_id)values(?,?,?)";
	private static final String DELETE_SMS_BLACK_SQL = "delete from sms_black_list where customer_id = ? and merchant_id = ?";
	private static final String SELECT_SMS_BLACK_SQL = "select count(1) from sms_black_list where customer_id = ? and merchant_id = ?";
	private static final String QUERY_CARD_ID = "select t.id from card t where t.customer_id = ?  and t.merchant_id = ? and t.status = 'normal' ";
	
	
	private JdbcTemplate jdbcTemplate = null;
	private DataSource ds=null;
	public DataSource getDs() {
		return ds;
	}
	public void afterPropertiesSet() throws Exception {
		jdbcTemplate=new JdbcTemplate(ds);
	}
	public void setDs(DataSource ds) {
		this.ds = ds;
	}
	public boolean isBalck(String customerId) {
		try{
			int num = jdbcTemplate.queryForInt(SELECT_SMS_BLACK_SQL,new String[]{customerId,"*"});
			if(num > 0) 
				return true;
			else
				return false;			
		}
		catch(Exception e){
			log.error("sms isBlack error " + customerId, e);
			throw new SmsException("sms isBlack error " + customerId, e); 
		}
	}
	public boolean isBalck(String customerId, String merchantId) {
		try{
			int num = jdbcTemplate.queryForInt(SELECT_SMS_BLACK_SQL,new String[]{customerId,merchantId});
			if(num > 0) 
				return true;
			else
				return false;			
		}
		catch(Exception e){
			log.error("sms isBlack error " + customerId + ' ' + merchantId, e);
			throw new SmsException("sms isBlack error " + customerId + ' ' + merchantId, e); 
		}
	}

	public void setBlack(String customerId, String merchantId) {
		try{
			jdbcTemplate.update(INSERT_SMS_BLACK_SQL,new String[]{UUIDGenerator.getUUID(), customerId,merchantId});		
		}
		catch(Exception e){
			log.error("sms setBlack error " + customerId + ' ' + merchantId, e);
			throw new SmsException("sms setBlack error " + customerId + ' ' + merchantId, e); 
		}

	}
	public void setBlack(String customerId) {
		try{
			jdbcTemplate.update(INSERT_SMS_BLACK_SQL,new String[]{UUIDGenerator.getUUID(),customerId,"*"});		
		}
		catch(Exception e){
			log.error("sms setBlack error " + customerId , e);
			throw new SmsException("sms setBlack error " + customerId , e); 
		}

	}
	public void setOpen(String customerId, String merchantId) {
		try{
			jdbcTemplate.update(DELETE_SMS_BLACK_SQL,new String[]{customerId,merchantId});		
		}
		catch(Exception e){
			log.error("sms setOpen error " + customerId + ' ' + merchantId, e);
			throw new SmsException("sms setOpen error " + customerId + ' ' + merchantId, e); 
		}

	}
	public void setOpen(String customerId) {
		try{
			jdbcTemplate.update(DELETE_SMS_BLACK_SQL,new String[]{customerId,"*"});		
		}
		catch(Exception e){
			log.error("sms setOpen error " + customerId , e);
			throw new SmsException("sms setOpen error " + customerId , e); 
		}

	}
	public String queryCardIdByCustomerId(String customerId, String merchantId){
		try{
			List<Map<String, String>> tmpMap = jdbcTemplate.queryForList( QUERY_CARD_ID , new String[]{customerId,merchantId});
			if( tmpMap == null || tmpMap.size() <= 0  ){
				return customerId ;
			}else{
				return tmpMap.get(0).get("ID");
			}
			
		}
		catch(Exception e){
			log.error("sms isBlack error " + customerId + ' ' + merchantId, e);
			throw new SmsException("sms isBlack error " + customerId + ' ' + merchantId, e); 
		}
	}

}
