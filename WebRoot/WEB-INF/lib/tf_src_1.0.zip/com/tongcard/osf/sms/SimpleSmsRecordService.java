package com.tongcard.osf.sms;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;

import org.springframework.jdbc.core.JdbcTemplate;
import com.tongcard.osf.util.UUIDGenerator;

public class SimpleSmsRecordService implements SmsRecordService, InitializingBean{

	public List<SmsRecord> querySmsRecord(String bizType,String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content,String beginDate,String endDate, int beginRow, int endRow) {
		StringBuffer sql = new StringBuffer();
		sql.append(SELECT_SMS_RECORD_SQL);
		if(bizType != null)
			sql.append(" and BIZ_ID='").append(bizType).append("'");
		if(bizName != null)
			sql.append(" and BIZ_NAME='").append(bizName).append("'");
		if(merchantId != null)
			sql.append(" and MERCHANT_ID='").append(merchantId).append("'");
		if(storeId != null)
			sql.append(" and STORE_ID='").append(storeId).append("'");
		if(customerId != null)
			sql.append(" and CUSTOMER_ID='").append(customerId).append("'");
		if(mobile != null)
			sql.append(" and MOBILE='").append(mobile).append("'");
		if(templateName != null)
			sql.append(" and TEMPLATE_NAME='").append(templateName).append("'");
		if(content != null)
			sql.append(" and CONTENT='").append(content).append("'");
		if(beginDate != null)
			sql.append(" and sent_time >= to_date('").append(beginDate).append("','yyyy-mm-dd')");
		if(endDate != null)
			sql.append(" and sent_time <= to_date('").append(endDate).append("','yyyy-mm-dd')");
		StringBuffer allSql = new StringBuffer();
		allSql.append("select * from (")
			.append(sql)
			.append(") m  ")
			.append(" where m.rowNumber >= " + beginRow)
			.append(" and m.rowNumber <= " + endRow);
		
		try{
			List<Map> result = jdbcTemplate.queryForList(allSql.toString());
			List<SmsRecord> srs = new ArrayList<SmsRecord>();
			for(Map r1:result){
				SmsRecord sr = new SmsRecord();
				sr.setBizType((String)r1.get("BIZ_ID"));
				sr.setBizName((String)r1.get("BIZ_NAME"));	
				sr.setContent((String)r1.get("CONTENT"));	
				sr.setCustomerId((String)r1.get("CUSTOMER_ID"));
				sr.setMerchantId((String)r1.get("MERCHANT_ID"));
				sr.setMobile((String)r1.get("MOBILE"));
				sr.setSendTime((java.sql.Timestamp)r1.get("SENT_TIME"));
				sr.setStoreId((String)r1.get("STORE_ID"));
				sr.setTemplateName((String)r1.get("TEMPLATE_NAME"));
				srs.add(sr);
			}
			return srs; 
		}
		catch(Exception e){
			throw new SmsException("短信查询异常",e);
		}
	}
	public int querySmsRecordCount(String bizType, String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate, String endDate) {
		StringBuffer sql = new StringBuffer();
		sql.append(COUNT_SMS_RECORD_SQL);
		
		if(bizType != null)
			sql.append(" and BIZ_ID='").append(bizType).append("'");
		if(bizName != null)
			sql.append(" and BIZ_NAME='").append(bizName).append("'");
		if(merchantId != null)
			sql.append(" and MERCHANT_ID='").append(merchantId).append("'");
		if(storeId != null)
			sql.append(" and STORE_ID='").append(storeId).append("'");
		if(customerId != null)
			sql.append(" and CUSTOMER_ID='").append(customerId).append("'");
		if(mobile != null)
			sql.append(" and MOBILE='").append(mobile).append("'");
		if(templateName != null)
			sql.append(" and TEMPLATE_NAME='").append(templateName).append("'");
		if(content != null)
			sql.append(" and CONTENT='").append(content).append("'");
		if(beginDate != null)
			sql.append(" and sent_time >= to_date('").append(beginDate).append("','yyyy-mm-dd')");
		if(endDate != null)
			sql.append(" and sent_time <= to_date('").append(endDate).append("','yyyy-mm-dd')");
		
		try{
			return jdbcTemplate.queryForInt(sql.toString());
		}
		catch(Exception e){
			throw new SmsException("短信查询异常",e);
		}
	}
	
	public int querySmsSendCount(String bizId, String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate, String endDate) {
		StringBuffer sql = new StringBuffer();
		sql.append(COUNT_SMS_SEND_SQL);
		
		if(bizId != null)
			sql.append(" and BIZ_ID='").append(bizId).append("'");
		if(bizName != null)
			sql.append(" and BIZ_NAME='").append(bizName).append("'");
		if(merchantId != null)
			sql.append(" and MERCHANT_ID='").append(merchantId).append("'");
		if(storeId != null)
			sql.append(" and STORE_ID='").append(storeId).append("'");
		if(customerId != null)
			sql.append(" and CUSTOMER_ID='").append(customerId).append("'");
		if(mobile != null)
			sql.append(" and MOBILE='").append(mobile).append("'");
		if(templateName != null)
			sql.append(" and TEMPLATE_NAME='").append(templateName).append("'");
		if(content != null)
			sql.append(" and CONTENT='").append(content).append("'");
		if(beginDate != null)
			sql.append(" and sent_time >= to_date('").append(beginDate).append("','yyyy-mm-dd')");
		if(endDate != null)
			sql.append(" and sent_time <= to_date('").append(endDate).append("','yyyy-mm-dd')");
		
		try{
			return jdbcTemplate.queryForInt(sql.toString());
		}
		catch(Exception e){
			throw new SmsException("短信查询异常",e);
		}
	}
	
	protected static Log log = LogFactory.getLog(SimpleSmsRecordService.class);	
	private JdbcTemplate jdbcTemplate = null;
	private JdbcTemplate jdbcArchiveTemplate = null;
	private DataSource ds=null;
	public DataSource getDs() {
		return ds;
	}

	public void setDs(DataSource ds) {
		this.ds = ds;
	}
	
	private DataSource archiveDs;
	
	public DataSource getArchiveDs() {
		return archiveDs;
	}
	public void setArchiveDs(DataSource archiveDs) {
		this.archiveDs = archiveDs;
	}
	
	public List<SmsRecord> querySmsRecordArchive(String bizType,String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content,String beginDate,String endDate, int beginRow, int endRow) {
		StringBuffer sql = new StringBuffer();
		sql.append(SELECT_SMS_RECORD_SQL);
		if(bizType != null)
			sql.append(" and BIZ_ID='").append(bizType).append("'");
		if(bizName != null)
			sql.append(" and BIZ_NAME='").append(bizName).append("'");
		if(merchantId != null)
			sql.append(" and MERCHANT_ID='").append(merchantId).append("'");
		if(storeId != null)
			sql.append(" and STORE_ID='").append(storeId).append("'");
		if(customerId != null)
			sql.append(" and CUSTOMER_ID='").append(customerId).append("'");
		if(mobile != null)
			sql.append(" and MOBILE='").append(mobile).append("'");
		if(templateName != null)
			sql.append(" and TEMPLATE_NAME='").append(templateName).append("'");
		if(content != null)
			sql.append(" and CONTENT='").append(content).append("'");
		if(beginDate != null)
			sql.append(" and sent_time >= to_date('").append(beginDate).append("','yyyy-mm-dd')");
		if(endDate != null)
			sql.append(" and sent_time <= to_date('").append(endDate).append("','yyyy-mm-dd')");
		StringBuffer allSql = new StringBuffer();
		allSql.append("select * from (")
			.append(sql)
			.append(") m  ")
			.append(" where m.rowNumber >= " + beginRow)
			.append(" and m.rowNumber <= " + endRow);
		
		try{
			List<Map> result = jdbcArchiveTemplate.queryForList(allSql.toString());
			List<SmsRecord> srs = new ArrayList<SmsRecord>();
			for(Map r1:result){
				SmsRecord sr = new SmsRecord();
				sr.setBizType((String)r1.get("BIZ_ID"));
				sr.setBizName((String)r1.get("BIZ_NAME"));	
				sr.setContent((String)r1.get("CONTENT"));	
				sr.setCustomerId((String)r1.get("CUSTOMER_ID"));
				sr.setMerchantId((String)r1.get("MERCHANT_ID"));
				sr.setMobile((String)r1.get("MOBILE"));
				sr.setSendTime((java.sql.Timestamp)r1.get("SENT_TIME"));
				sr.setStoreId((String)r1.get("STORE_ID"));
				sr.setTemplateName((String)r1.get("TEMPLATE_NAME"));
				srs.add(sr);
			}
			return srs; 
		}
		catch(Exception e){
			throw new SmsException("短信查询异常",e);
		}
	}
	public int querySmsRecordCountArchive(String bizType, String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate, String endDate) {
		StringBuffer sql = new StringBuffer();
		sql.append(COUNT_SMS_RECORD_SQL);
		
		if(bizType != null)
			sql.append(" and BIZ_ID='").append(bizType).append("'");
		if(bizName != null)
			sql.append(" and BIZ_NAME='").append(bizName).append("'");
		if(merchantId != null)
			sql.append(" and MERCHANT_ID='").append(merchantId).append("'");
		if(storeId != null)
			sql.append(" and STORE_ID='").append(storeId).append("'");
		if(customerId != null)
			sql.append(" and CUSTOMER_ID='").append(customerId).append("'");
		if(mobile != null)
			sql.append(" and MOBILE='").append(mobile).append("'");
		if(templateName != null)
			sql.append(" and TEMPLATE_NAME='").append(templateName).append("'");
		if(content != null)
			sql.append(" and CONTENT='").append(content).append("'");
		if(beginDate != null)
			sql.append(" and sent_time >= to_date('").append(beginDate).append("','yyyy-mm-dd')");
		if(endDate != null)
			sql.append(" and sent_time <= to_date('").append(endDate).append("','yyyy-mm-dd')");
		
		try{
			return jdbcArchiveTemplate.queryForInt(sql.toString());
		}
		catch(Exception e){
			throw new SmsException("短信查询异常",e);
		}
	}
	
	public int querySmsSendCountArchive(String bizId, String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate, String endDate) {
		StringBuffer sql = new StringBuffer();
		sql.append(COUNT_SMS_SEND_SQL);
		
		if(bizId != null){
			sql.append(" and BIZ_ID='").append(bizId).append("'");
		}
		if(bizName != null)
			sql.append(" and BIZ_NAME='").append(bizName).append("'");
		if(merchantId != null)
			sql.append(" and MERCHANT_ID='").append(merchantId).append("'");
		if(storeId != null)
			sql.append(" and STORE_ID='").append(storeId).append("'");
		if(customerId != null)
			sql.append(" and CUSTOMER_ID='").append(customerId).append("'");
		if(mobile != null)
			sql.append(" and MOBILE='").append(mobile).append("'");
		if(templateName != null)
			sql.append(" and TEMPLATE_NAME='").append(templateName).append("'");
		if(content != null)
			sql.append(" and CONTENT='").append(content).append("'");
		if(beginDate != null)
			sql.append(" and sent_time >= to_date('").append(beginDate).append("','yyyy-mm-dd')");
		if(endDate != null)
			sql.append(" and sent_time <= to_date('").append(endDate).append("','yyyy-mm-dd')");
		try{
			return jdbcArchiveTemplate.queryForInt(sql.toString());
		}
		catch(Exception e){
			throw new SmsException("短信查询异常",e);
		}
	}
	
	
	
	public int querySmsSendCountArchiveForMarketingResult(String bizId, String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate, String endDate) {
		StringBuffer sql = new StringBuffer();
		sql.append(COUNT_SMS_SEND_SQL);
		
		if(bizId != null){
			sql.append(" and ( BIZ_ID='").append(bizId).append("'");
			sql.append( " or marketing_id = '").append( bizId ).append("' )");
		}
		if(bizName != null)
			sql.append(" and BIZ_NAME='").append(bizName).append("'");
		if(merchantId != null)
			sql.append(" and MERCHANT_ID='").append(merchantId).append("'");
		if(storeId != null)
			sql.append(" and STORE_ID='").append(storeId).append("'");
		if(customerId != null)
			sql.append(" and CUSTOMER_ID='").append(customerId).append("'");
		if(mobile != null)
			sql.append(" and MOBILE='").append(mobile).append("'");
		if(templateName != null)
			sql.append(" and TEMPLATE_NAME='").append(templateName).append("'");
		if(content != null)
			sql.append(" and CONTENT='").append(content).append("'");
		if(beginDate != null)
			sql.append(" and sent_time >= to_date('").append(beginDate).append("','yyyy-mm-dd')");
		if(endDate != null)
			sql.append(" and sent_time <= to_date('").append(endDate).append("','yyyy-mm-dd')");
		try{
			return jdbcArchiveTemplate.queryForInt(sql.toString());
		}
		catch(Exception e){
			throw new SmsException("短信查询异常",e);
		}
	}
	
	/**
	 *根据 活动查询券到期发送提醒短信的数量
	 *最后修改2011-9-14【由于折扣券到期提醒的定时中，发短信是类型不是统一的“优惠到期提醒”，而定义成为“折扣券到期提醒”，现在代码已经统一过来，
	 *但是已经存在类型叫作“折扣券到期提醒”的短信，这一部分数据库中的类型仍然是“折扣券到期提醒”，所以在统计到期提醒时，要加上 or  biz_type ='折扣券到期提醒' 】
	 */
	
	
	public int querySmsSendCountByMarketingId(String marketingId,String bizType) {
		// TODO Auto-generated method stub
		StringBuffer sql = new StringBuffer();
		sql.append(COUNT_SMS_SEND_SQL);
		sql.append("  and marketing_id= '"+marketingId +"' and ( biz_type='"+bizType+"' or biz_type ='折扣券到期提醒' ) " );
		int count=jdbcArchiveTemplate.queryForInt(sql.toString());
	   return count;
	}
	
	/**
	 * 统计开卡促销时发送短信的数量
	 */
	
	@Override
	public int querySmsSentCountForOpenCardMarketing(String marketingId,String bizType) {
		// TODO Auto-generated method stub
		StringBuffer sql = new StringBuffer();
		sql.append(COUNT_SMS_SEND_SQL);
		sql.append("  and marketing_id= '"+marketingId +"' and biz_type='"+bizType+"' ");
		int count=jdbcArchiveTemplate.queryForInt(sql.toString());
	   return count;
	}
	/**
	 *  最后修改，2011-8-4号。当商户短信余额不足时给运营工程师发短信，也是要记一条发送短信的记录，因为insert into sms_send_record的语句修改了，加了一个marketingId，因此在给运维工程师发短信时也是调用这个方法
	 *  这时如果Object[] args = new Object[17];就会报错nested exception is java.sql.SQLException: 索引中丢失  IN 或 OUT 参数:: 18。所以第18个参数设置为null.给运维工程师发短信不记marketingId，不计作活动的成本。
	 */
	public void record(String bizId, String bizType,String bizName, String merchantId, String merchantName,String storeId, String customerId, String customerName, String mobile,String templateId,String templateName, String template, String content, boolean is_success, String errorType, String errorInfo ){
		Object[] args = new Object[18];
		int i = 0;
		args[i++] = UUIDGenerator.getUUID();
		args[i++] = bizId;
		args[i++] = bizType;
		args[i++] = bizName;
		args[i++] = merchantId;
		args[i++] = merchantName;
		args[i++] = storeId;
		
		args[i++] = customerId;
		args[i++] = customerName;		
		args[i++] = mobile;
		args[i++] = templateId;
		args[i++] = templateName;
		
		args[i++] = template;
		args[i++] = content;
		if(is_success)
			args[i++] = "true";
		else
			args[i++] = "false";
		args[i++] = errorType;
		String info = errorInfo;
		if(errorInfo != null && errorInfo.length()> 50)
			info = errorInfo.substring(0,50);
		args[i++] = info;
		args[i++] = null;
		try{
			jdbcTemplate.update(INSERT_SMS_RECORD_SQL, args);
		}
		catch(Exception e){
			log.error("sms record error " + bizId + ' ' + bizType + ' '+ bizName + ' ' + merchantId + ' ' + customerId + ' ' +  mobile + ' ' + content + ' ' + is_success, e);
		}
	}
	/**
	 * 活动发券到期提醒发送短信2011-8-3（活动效果发券到期提醒，加了marketingId）
	 */
	@Override
	public void record(String bizId, String bizType, String bizName,
			String merchantId, String merchantName, String storeId,
			String customerId, String customerName, String mobile,
			String templateId, String templateName, String template,
			String content, boolean is_success, String errorType,
			String errorInfo, String marketingId) {
		// TODO Auto-generated method stub
		
		Object[] args = new Object[18];
		int i = 0;
	
		args[i++] = UUIDGenerator.getUUID();
		args[i++] = bizId;
		args[i++] = bizType;
		args[i++] = bizName;
		args[i++] = merchantId;
		args[i++] = merchantName;
		args[i++] = storeId;
		
		args[i++] = customerId;
		args[i++] = customerName;		
		args[i++] = mobile;
		args[i++] = templateId;
		args[i++] = templateName;
		
		args[i++] = template;
		args[i++] = content;
		if(is_success){
			args[i++] = "true";
		}
		else{
			args[i++] = "false";
		}
		args[i++] = errorType;
		String info = errorInfo;
		if(errorInfo != null && errorInfo.length()> 50){
			info = errorInfo.substring(0,50);
		}
		args[i++] = info;
		args[i++] = marketingId;
	
		try{
			jdbcTemplate.update(INSERT_SMS_RECORD_SQL, args);
		}
		catch(Exception e){
			log.error("sms record error " + bizId + ' ' + bizType + ' '+ bizName + ' ' + merchantId + ' ' + customerId + ' ' +  mobile + ' ' + content + ' ' + is_success, e);
		}
	}
	public void afterPropertiesSet() throws Exception {
		jdbcTemplate=new JdbcTemplate(ds);
		jdbcArchiveTemplate = new JdbcTemplate(archiveDs);
	}	
	private static final String INSERT_SMS_RECORD_SQL="insert into SMS_SEND_RECORD (SMS_ID,BIZ_ID,BIZ_TYPE,BIZ_NAME, MERCHANT_ID, MERCHANT_NAME, STORE_ID, CUSTOMER_ID, CUSTOMER_NAME, MOBILE, TEMPLATE_ID, TEMPLATE_NAME,TEMPLATE,CONTENT,SENT_TIME,IS_SUCCESS,ERROR_TYPE, ERROR_INFO,RECORD_STATE,MARKETING_ID) values (?,?,?,?,?, ?, ?,?,?,?,?,  ?,?,?,sysdate,?, ?,?,'normal',? )";
	
	private static final String INSERT_SMS_RECORD_SQL1="insert into SMS_SEND_RECORD (MARKETING_ID,SMS_ID,BIZ_ID,BIZ_TYPE) values (?,?,?,?)";
	
	private static final String SELECT_SMS_RECORD_SQL="SELECT SMS_ID,BIZ_ID,BIZ_TYPE,BIZ_NAME, MERCHANT_ID, MERCHANT_NAME, STORE_ID, CUSTOMER_ID, CUSTOMER_NAME, MOBILE, TEMPLATE_ID, TEMPLATE_NAME,TEMPLATE,CONTENT,SENT_TIME, ROW_NUMBER() Over(order by SENT_TIME desc)as rowNumber from SMS_SEND_RECORD where IS_SUCCESS = 'true'";
	
	private static final String COUNT_SMS_RECORD_SQL="SELECT count(1) num from SMS_SEND_RECORD where IS_SUCCESS = 'true' ";
	
	private static final String COUNT_SMS_SEND_SQL = "SELECT sum(ceil(length(CONTENT)/(select value from sys_constants_config where key='sms_calc_count'))) num from SMS_SEND_RECORD where IS_SUCCESS = 'true' ";
	
	//private static final String COUNT_SMS_SEND_BY_MARKETING_SQL="SELECT sum(ceil(length(CONTENT)/70)) num from SMS_SEND_RECORD where IS_SUCCESS = 'true' and marketing_id= ?" ;
}
