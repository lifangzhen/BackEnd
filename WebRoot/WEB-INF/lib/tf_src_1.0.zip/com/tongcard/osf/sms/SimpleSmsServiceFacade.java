package com.tongcard.osf.sms;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;

import com.tongcard.osf.AppException;
import com.tongcard.osf.sms.sp.SmsServiceProvider;
import com.tongcard.osf.util.ExpressionUtil;

public class SimpleSmsServiceFacade implements SmsService,InitializingBean{
	

	private SmsServiceProvider defaultSP = null;
	private SmsRecordService srs = null;
	private SmsBlackService sbs = null;
	protected static Log log = LogFactory.getLog(SimpleSmsServiceFacade.class);
	
	public Result[] send(String bizId, String bizType,String bizName, String merchantId, 
			String merchantName, String storeId,String[] customerIds, String[] customerNames,
			String[] mobiles, String templateId, String templateName, String template, Map arguments) {
		Map args = (arguments == null)?new HashMap():arguments;
		
		Result[] rs = null;
		if(mobiles != null){
			rs = new Result[mobiles.length];
			int i= 0;
			for(String mobile:mobiles){
				Result result = null;
				String content = null;
				
				boolean mobileIsValid = SmsUtil.isValidMobileCode(mobile);
				
				boolean mobileIsBlack = false;//
				if(merchantId == null )
					mobileIsBlack = sbs.isBalck(customerIds[i]);
				else
					mobileIsBlack = sbs.isBalck(customerIds[i], merchantId);
				
				if( (!mobileIsBlack) && mobileIsValid){
					args.put("商户简称", merchantName);
					args.put("手机号", mobile);
					args.put("会员姓名", customerNames[i]);
//					args.put("卡号", customerIds[i]);
//					if(customerIds[i] != null && customerIds[i].length() == 16)
//						args.put("卡号后四位", customerIds[i].substring(12));
					
					String cardId = this.queryCardIdByCustomerId( customerIds[i] , merchantId );
					args.put("卡号", cardId);
					if(cardId != null && cardId.length() == 16)
						args.put("卡号后四位", cardId.substring(12));
					
					content = ExpressionUtil.replace(template, args);
					
					try{
						Map<String, Object> params = new HashMap<String, Object>();
						params.put("biz_type", bizType);
						params.put("merchantId", merchantId);
						result = this.send(mobile, content, params);
						result.setContent(content);
					}
					catch(Exception e){
						log.error(e.getMessage(),e);
						result = new Result();
						result.setSuccess(false);
						result.setMobile(mobile);
						result.setErrorType(Result.ROUTEWAY_ERROR);
						if(e instanceof AppException){
							result.setErrorInfo(((AppException)e).getErrorCode() + ':' + e.getMessage());
						}
						else{
							result.setErrorInfo(e.getMessage());
						}
					}
				}
				else{
					result = new Result();
					result.setSuccess(false);
					result.setMobile(mobile);
					if(mobileIsBlack)
						result.setErrorType(Result.CUSTOMER_IS_BLACK);
					else
						result.setErrorType(Result.INVALID_CODE);
				}
				if(result.getErrorInfo() != null && result.getErrorInfo().length() > 500){
					result.setErrorInfo(result.getErrorInfo().substring(0,500));
				}
				//record
				srs.record(bizId, bizType,bizName, merchantId, merchantName, storeId, customerIds[i], customerNames[i], mobile, templateId, templateName, template, content, result.isSuccess(), result.getErrorType(), result.getErrorInfo());
				rs[i++] = result;
			}
		}
		return rs;
	}

	@Override
	public void record(String bizId, String bizType, String bizName,
			String merchantId, String merchantName, String storeId,
			String customerId, String customerName, String mobile,
			String templateId, String templateName, String template,
			String content, boolean is_success, String errorType,
			String errorInfo, String marketingId) {
		// TODO Auto-generated method stub
		srs.record(bizId, bizType,bizName, merchantId, merchantName, storeId,
				customerId, customerName, mobile, templateId, templateName,
				template, content, is_success, errorType, errorInfo,marketingId);
	}

	@Override
	public Result[] send(String bizId, String bizType, String bizName,
			String merchantId, String merchantName, String storeId,
			String[] customerIds, String[] customerNames, String[] mobiles,
			String templateId, String templateName, String template,
			Map arguments, String marketingId) {
		// TODO Auto-generated method stub
		Map args = (arguments == null)?new HashMap():arguments;
		
		Result[] rs = null;
		if(mobiles != null){
			rs = new Result[mobiles.length];
			int i= 0;
			for(String mobile:mobiles){
				Result result = null;
				String content = null;
				
				boolean mobileIsValid = SmsUtil.isValidMobileCode(mobile);
				
				boolean mobileIsBlack = false;//
				if(merchantId == null )
					mobileIsBlack = sbs.isBalck(customerIds[i]);
				else
					mobileIsBlack = sbs.isBalck(customerIds[i], merchantId);
				
				if( (!mobileIsBlack) && mobileIsValid){
					args.put("商户简称", merchantName);
					args.put("手机号", mobile);
					args.put("会员姓名", customerNames[i]);
//					args.put("卡号", customerIds[i]);
//					if(customerIds[i] != null && customerIds[i].length() == 16)
//						args.put("卡号后四位", customerIds[i].substring(12));
					
					String cardId = this.queryCardIdByCustomerId( customerIds[i] , merchantId );
					args.put("卡号", cardId);
					if(cardId != null && cardId.length() == 16)
						args.put("卡号后四位", cardId.substring(12));
					content = ExpressionUtil.replace(template, args);
					
					try{
						Map<String, Object> params = new HashMap<String, Object>();
						params.put("biz_type", bizType);
						params.put("merchantId", merchantId);
						result = this.send(mobile, content, params);
						result.setContent(content);
					}
					catch(Exception e){
						log.error(e.getMessage(),e);
						result = new Result();
						result.setSuccess(false);
						result.setMobile(mobile);
						result.setErrorType(Result.ROUTEWAY_ERROR);
						if(e instanceof AppException){
							result.setErrorInfo(((AppException)e).getErrorCode() + ':' + e.getMessage());
						}
						else{
							result.setErrorInfo(e.getMessage());
						}
					}
				}
				else{
					result = new Result();
					result.setSuccess(false);
					result.setMobile(mobile);
					if(mobileIsBlack)
						result.setErrorType(Result.CUSTOMER_IS_BLACK);
					else
						result.setErrorType(Result.INVALID_CODE);
				}
				if(result.getErrorInfo() != null && result.getErrorInfo().length() > 500){
					result.setErrorInfo(result.getErrorInfo().substring(0,500));
				}
				//record
				srs.record(bizId, bizType,bizName, merchantId, merchantName, storeId, customerIds[i], customerNames[i], mobile, templateId, templateName, template, content, result.isSuccess(), result.getErrorType(), result.getErrorInfo(),marketingId);
				rs[i++] = result;
			}
		}
		return rs;
	}

	public Result[] send(String bizId, String bizType, String bizName,String merchantId,
			String merchantName, String storeId,String[] customerIds, String[] customerNames,
			String[] mobiles, String content) {
		Result[] rs = null;
//		//没有黑名单处理，暂时先不批量发送		
//		if(defaultSP.isSupportMany()){
//			rs = defaultSP.send(mobiles, content);
//		}
//		else{
			if(mobiles != null){
				rs = new Result[mobiles.length];
				int i= 0;
				for(String mobile:mobiles){
					Result result = null;

					boolean mobileIsValid = SmsUtil.isValidMobileCode(mobile);
					
					boolean mobileIsBlack = false;//
					if(merchantId == null )
						mobileIsBlack = sbs.isBalck(customerIds[i]);
					else
						mobileIsBlack = sbs.isBalck(customerIds[i], merchantId);
					
					if( (!mobileIsBlack) && mobileIsValid){
						try{
							Map<String, Object> params = new HashMap<String, Object>();
							params.put("biz_type", bizType);
							params.put("merchantId", merchantId);
							result = this.send(mobile, content, params);
							result.setContent(content);
						}
						catch(Exception e){
							log.error(e.getMessage(),e);
							result = new Result();
							result.setSuccess(false);
							result.setMobile(mobile);
							result.setErrorType(Result.ROUTEWAY_ERROR);
							if(e instanceof AppException){
								result.setErrorInfo(((AppException)e).getErrorCode() + ':' + e.getMessage());
							}
							else{
								result.setErrorInfo(e.getMessage());
							}
						}
					}
					else{
						result = new Result();
						result.setSuccess(false);
						result.setMobile(mobile);
						if(mobileIsBlack)
							result.setErrorType(Result.CUSTOMER_IS_BLACK);
						else
							result.setErrorType(Result.INVALID_CODE);
					}
					rs[i++] = result;
				}
//			}
		}
		if(rs!= null){
			for(int i = 0; i< rs.length; i++){
				srs.record(bizId, bizType,bizName, merchantId, merchantName, storeId, customerIds[i], customerNames[i], mobiles[i], null, null, null, content, rs[i].isSuccess(), rs[i].getErrorType(), rs[i].getErrorInfo());
			}
		}
		return rs;
	}
	/**
	 * 短信条数拆分
	 * @param mobile
	 * @param smsContent
	 * @return
	 */
	private Result send(String mobile,String smsContent, Map<String, Object> params){
		Result result = null;
		if(smsContent == null || smsContent.length() == 0){
			result = this.defaultSP.send(mobile, "", params);
			return result;
		}
		else{
			/*
			按70个字拆分发送短信
			int size = smsContent.length();
			for(int beginIndex = 0; beginIndex < size; beginIndex += 70){
				int endIndex = beginIndex+70;
				if(endIndex > size)
					endIndex = size;
				result = this.defaultSP.send(mobile,smsContent.substring(beginIndex, endIndex));
				if(!result.isSuccess()){
					break;
				}
			}
			*/
			result = this.defaultSP.send(mobile,smsContent, params);
			return result;
		}
		
	}
	public SmsServiceProvider getDefaultSP() {
		return defaultSP;
	}

	public void setDefaultSP(SmsServiceProvider defaultSP) {
		this.defaultSP = defaultSP;
	}

	public SmsRecordService getSrs() {
		return srs;
	}

	public void setSrs(SmsRecordService srs) {
		this.srs = srs;
	}
	public void afterPropertiesSet() throws Exception {
		SmsUtil.setSmsService(this);
		
	}

	public SmsBlackService getSbs() {
		return sbs;
	}

	public void setSbs(SmsBlackService sbs) {
		this.sbs = sbs;
	}

	public boolean isBalck(String customerId) {
		return sbs.isBalck(customerId);
	}

	public boolean isBalck(String customerId, String merchantId) {
		return sbs.isBalck(customerId, merchantId);
	}

	public void setBlack(String customerId, String merchantId) {
		sbs.setBlack(customerId, merchantId);
	}

	public void setBlack(String customerId) {
		sbs.setBlack(customerId);
	}

	public void setOpen(String customerId, String merchantId) {
		sbs.setOpen(customerId, merchantId);
	}

	public void setOpen(String customerId) {
		sbs.setOpen(customerId);
	}

	public List<SmsRecord> querySmsRecord(String bizType, String bizName,String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate, int beginPage, int pageSize) {
		return srs.querySmsRecord(bizType, bizName, merchantId, storeId, customerId,
				mobile, templateName, content, beginDate, endDate, beginPage,
				pageSize);
	}

	public int querySmsRecordCount(String bizType, String bizName,String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate) {
		return srs.querySmsRecordCount(bizType,bizName, merchantId, storeId,
				customerId, mobile, templateName, content, beginDate, endDate);
	}
	
	public List<SmsRecord> querySmsRecordArchive(String bizType, String bizName,String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate, int beginPage, int pageSize) {
		return srs.querySmsRecordArchive(bizType, bizName, merchantId, storeId, customerId,
				mobile, templateName, content, beginDate, endDate, beginPage,
				pageSize);
	}

	public int querySmsRecordCountArchive(String bizType, String bizName,String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate) {
		return srs.querySmsRecordCountArchive(bizType,bizName, merchantId, storeId,
				customerId, mobile, templateName, content, beginDate, endDate);
	}

	public void record(String bizId, String bizType, String bizName,String merchantId,
			String merchantName, String storeId, String customerId,
			String customerName, String mobile, String templateId,
			String templateName, String template, String content,
			boolean is_success, String errorType, String errorInfo) {
		srs.record(bizId, bizType,bizName, merchantId, merchantName, storeId,
				customerId, customerName, mobile, templateId, templateName,
				template, content, is_success, errorType, errorInfo);
	}
	public int querySmsSendCount(String bizId, String bizName,String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate) {
		return srs.querySmsSendCount(bizId,bizName, merchantId, storeId,
				customerId, mobile, templateName, content, beginDate, endDate);
	}
	
	public int querySmsSendCountArchive(String bizId, String bizName,String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate) {
		return srs.querySmsSendCountArchive(bizId,bizName, merchantId, storeId,
				customerId, mobile, templateName, content, beginDate, endDate);
	}
	
	
	public int querySmsSendCountArchiveForMarketingResult(String bizId, String bizName,String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate) {
		return srs.querySmsSendCountArchiveForMarketingResult(bizId,bizName, merchantId, storeId,
				customerId, mobile, templateName, content, beginDate, endDate);
	}

	
	public int querySmsSendCountByMarketingId(String marketingId,String bizType) {
		// TODO Auto-generated method stub
		return srs.querySmsSendCountByMarketingId(marketingId,bizType);
	}

	@Override
	public int querySmsSentCountForOpenCardMarketing(String marketingId,String bizType) {
		// TODO Auto-generated method stub
		return srs.querySmsSentCountForOpenCardMarketing(marketingId,bizType);
	}
	
	public String queryCardIdByCustomerId(String customerId, String merchantId){
		return sbs.queryCardIdByCustomerId(customerId, merchantId);
	}
	
}
