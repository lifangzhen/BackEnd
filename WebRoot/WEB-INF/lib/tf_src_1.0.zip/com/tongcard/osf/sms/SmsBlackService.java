package com.tongcard.osf.sms;

public interface SmsBlackService {
	/**
	  * 屏蔽掉某个商户发来的短信
	  * @param customerId
	  * @param merchantId
	  */
	 public void setBlack(String customerId,String merchantId);
	 /**
	  * 接触短信屏蔽,屏蔽掉所有商户发来的短信
	  * @param customerId
	  */
	 public void setBlack(String customerId);
	 /**
	  * 解除短信屏蔽,可以接收某个商户发来的短信
	  * @param customerId
	  * @param merchantId
	  */
	 public void setOpen(String customerId,String merchantId);
	 /**
	  * 解除短信屏蔽,可以接收所有商户发来的短信
	  * @param customerId
	  * @param merchantId
	  */
	 public void setOpen(String customerId);
	 /**
	  * 判断是否在黑名单中
	  * @param customerId
	  * @return
	  */
	 public boolean isBalck(String customerId);
	 /**
	  * 判断是否在黑名单中
	  * @param customerId
	  * @param merchantId
	  * @return
	  */
	 public boolean isBalck(String customerId, String merchantId);
	 
	 /**
	  * 由于换卡之后  cardId != customerId ,故需要查询一下
	  * @param customerId
	  * @param merchantId
	  * @return
	  */
	 public String queryCardIdByCustomerId(String customerId, String merchantId);
}
