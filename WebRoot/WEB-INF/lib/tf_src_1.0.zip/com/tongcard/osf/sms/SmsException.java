package com.tongcard.osf.sms;

import com.tongcard.osf.AppException;

public class SmsException extends AppException {

	public SmsException(String msg, Throwable ex) {
		super(msg, ex);
	}
}
