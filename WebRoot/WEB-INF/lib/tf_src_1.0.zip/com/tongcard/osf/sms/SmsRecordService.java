package com.tongcard.osf.sms;

import java.util.List;

public interface SmsRecordService {
	public void record(String bizId, String bizType,String bizName, String merchantId, String merchantName,String storeId, String customerId, String customerName, String mobile,String templateId,String templateName, String template, String content, boolean is_success, String errorType, String errorInfo );
	public void record(String bizId, String bizType,String bizName, String merchantId, String merchantName,String storeId, String customerId, String customerName, String mobile,String templateId,String templateName, String template, String content, boolean is_success, String errorType, String errorInfo,String marketingId );
	public List<SmsRecord> querySmsRecord(String bizType,String bizName, String merchantId, String storeId, String customerId,String mobile,String templateName,String content,String beginDate,String endDate, int beginPage, int pageSize);
	public int querySmsRecordCount(String bizType,String bizName, String merchantId, String storeId, String customerId,String mobile,String templateName,String content,String beginDate,String endDate);
	public int querySmsSendCount(String bizId, String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate, String endDate);
	public List<SmsRecord> querySmsRecordArchive(String bizType,String bizName, String merchantId, String storeId, String customerId,String mobile,String templateName,String content,String beginDate,String endDate, int beginPage, int pageSize);
	public int querySmsRecordCountArchive(String bizType,String bizName, String merchantId, String storeId, String customerId,String mobile,String templateName,String content,String beginDate,String endDate);
	public int querySmsSendCountArchive(String bizId, String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate, String endDate);
	public int querySmsSendCountArchiveForMarketingResult(String bizId, String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate, String endDate);
	public int querySmsSendCountByMarketingId(String marketingId,String bizType);
	public int querySmsSentCountForOpenCardMarketing(String marketingId,String bizType);
}
