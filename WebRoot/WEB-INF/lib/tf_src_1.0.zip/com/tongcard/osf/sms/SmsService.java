package com.tongcard.osf.sms;

import java.util.Map;

/**
 * 短信服务
 * @author admin
 *
 */
public interface SmsService extends SmsBlackService,SmsRecordService {
	/**
	 * 短信发送
	 * @param bizId 业务编号:如活动编号
	 * @param bizType 业务类型 如优惠券到期提醒overdueCouponRemind
	 * @param bizName 业务名称
	 * @param merchantId 商户编号
	 * @param merchantName 商户简称
	 * @param storeId 门店编号
	 * @param customerIds 客户编号数组
	 * @param customerNames 会员姓名数组数组
	 * @param mobiles 手机号码数组
	 * @param templateId 短信模板id
	 * @param tempalteName 短信模板名称
	 * @param template 短信模板 手机号请使用[手机号]做变量名, 商户名称请使用[商户名称]作为变量名
	 * @param arguments 短信模板变量
	 * @return 成功失败的结果信息
	 */
	public  Result[] send(String bizId, String bizType, String bizName, String merchantId,String merchantName,String storeId, String[] customerIds, String[] customerNames, String[] mobiles,String templateId,String templateName, String template, Map arguments);
	
	/**
	 * 短信发送
	 * @param bizId 业务编号:如活动编号
	 * @param bizType 业务类型 如优惠券到期提醒overdueCouponRemind
	 * @param bizName 业务名称
	 * @param merchantId 商户编号
	 * @param merchantName 商户简称
	 * @param storeId 门店编号
	 * @param customerIds 客户编号数组
	 * @param customerNames 会员姓名数组数组
	 * @param mobiles 手机号码数组
	 * @param templateId 短信模板id
	 * @param tempalteName 短信模板名称
	 * @param template 短信模板 手机号请使用[手机号]做变量名, 商户名称请使用[商户名称]作为变量名
	 * @param arguments 短信模板变量
	 * @return 成功失败的结果信息
	 */
	public  Result[] send(String bizId, String bizType, String bizName, String merchantId,String merchantName,String storeId, String[] customerIds, String[] customerNames, String[] mobiles,String templateId,String templateName, String template, Map arguments,String marketingId);
	
	/**
	 * 短信发送
	 * @param bizId 业务编号:如活动编号
	 * @param bizType 业务类型 如优惠券到期提醒overdueCouponRemind
	 * @param bizName 业务名称
	 * @param merchantId 商户编号
	 * @param merchantName 商户简称
	 * @param storeId 门店编号
	 * @param customerIds 客户编号数组
	 * @param customerNames 会员姓名数组
	 * @param mobiles 手机号码数组
	 * @param content 短信内容
	 * @return 成功失败的结果信息
	 */
	 public  Result[] send(String bizId, String bizType, String bizName, String merchantId,String merchantName,String storeId, String[] customerIds, String[] customerNames, String[] mobiles, String content);
	 
	 
	 
}
