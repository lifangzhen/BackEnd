package com.tongcard.osf.sms;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * 短信发送接口
 * 
 * @author admin
 * 
 */
public class SmsUtil {
	static private SmsService smsService = null;

	/**
	 * 短信发送
	 * 
	 * @param bizId
	 *            业务编号:如活动编号
	 * @param bizType
	 *            业务类型 如优惠券到期提醒overdueCouponRemind
	 * @param bizName
	 * 			  业务名称           
	 * @param merchantId
	 *            商户编号
	 * @param merchantName
	 *            商户名称
	 * @param storeId
	 *            门店编号
	 * @param customerIds客户编号
	 * @param customerNames
	 *            会员姓名
	 * @param mobiles
	 *            手机号码数组
	 * @param templateId
	 *            短信模板id
	 * @param tempalteName
	 *            短信模板名称
	 * @param template
	 *            短信模板 手机号请使用[手机号]做变量名, 商户名称请使用[商户简称]作为变量名
	 * @param arguments
	 *            短信模板变量 or null
	 * @return 成功失败的结果信息
	 */
	public static Result[] send(String bizId, String bizType, String bizName,
			String merchantId, String merchantName, String storeId,
			String[] customerIds, String[] customerNames, String[] mobiles,
			String templateId, String templateName, String template,
			Map arguments) {
		return smsService.send(bizId, bizType,bizName, merchantId, merchantName,
				storeId, customerIds, customerNames, mobiles, templateId,
				templateName, template, arguments);
	}
	
	/**
	 * 活动优惠券到期提醒发送短信
	 * @param bizId
	 * @param bizType
	 * @param bizName
	 * @param merchantId
	 * @param merchantName
	 * @param storeId
	 * @param customerIds
	 * @param customerNames
	 * @param mobiles
	 * @param templateId
	 * @param templateName
	 * @param template
	 * @param arguments
	 * @return
	 */
	
	public static Result[] send(String bizId, String bizType, String bizName,
			String merchantId, String merchantName, String storeId,
			String[] customerIds, String[] customerNames, String[] mobiles,
			String templateId, String templateName, String template,
			Map arguments,String marketingId) {
		return smsService.send(bizId, bizType,bizName, merchantId, merchantName,
				storeId, customerIds, customerNames, mobiles, templateId,
				templateName, template, arguments,marketingId);
	}


	/**
	 * 短信发送(活动所发的券到期提醒，发送短信)
	 * 
	 * @param bizId
	 *            业务编号:如活动编号
	 * @param bizType
	 *            业务类型 如优惠券到期提醒overdueCouponRemind
	 * @param bizName
	 * 			  业务名称           
	 * @param merchantId
	 *            商户编号
	 * @param merchantName
	 *            商户简称
	 * @param storeId
	 *            门店编号
	 * @param customerId
	 *            客户编号
	 * @param customerName
	 *            会员姓名
	 * @param mobile
	 *            手机号码
	 * @param templateId
	 *            短信模板id
	 * @param tempalteName
	 *            短信模板名称
	 * @param template
	 *            短信模板 手机号请使用[手机号]做变量名, 商户名称请使用[商户简称]作为变量名
	 * @param arguments
	 *            短信模板变量 or null
	 * @return 成功失败的结果信息
	 */
	public static Result send(String bizId, String bizType,String bizName, String merchantId,
			String merchantName, String storeId, String customerId,
			String customerName, String mobile, String templateId,
			String templateName, String template, Map arguments,String marketingId) {
		Result[] rs = send(bizId, bizType,bizName, merchantId, merchantName, storeId,
				new String[] { customerId }, new String[] { customerName },
				new String[] { mobile }, templateId, templateName, template,
				arguments,marketingId);
		return rs[0];
	}
	
	

	/**
	 * 短信发送
	 * 
	 * @param bizId
	 *            业务编号:如活动编号
	 * @param bizType
	 *            业务类型 如优惠券到期提醒overdueCouponRemind
	 * @param bizName
	 * 			  业务名称           
	 * @param merchantId
	 *            商户编号
	 * @param merchantName
	 *            商户简称
	 * @param storeId
	 *            门店编号
	 * @param customerId
	 *            客户编号
	 * @param customerName
	 *            会员姓名
	 * @param mobile
	 *            手机号码
	 * @param templateId
	 *            短信模板id
	 * @param tempalteName
	 *            短信模板名称
	 * @param template
	 *            短信模板 手机号请使用[手机号]做变量名, 商户名称请使用[商户简称]作为变量名
	 * @param arguments
	 *            短信模板变量 or null
	 * @return 成功失败的结果信息
	 */
	public static Result send(String bizId, String bizType,String bizName, String merchantId,
			String merchantName, String storeId, String customerId,
			String customerName, String mobile, String templateId,
			String templateName, String template, Map arguments) {
		Result[] rs = send(bizId, bizType,bizName, merchantId, merchantName, storeId,
				new String[] { customerId }, new String[] { customerName },
				new String[] { mobile }, templateId, templateName, template,
				arguments);
		return rs[0];
	}

	public static void setSmsService(SmsService smsService) {
		SmsUtil.smsService = smsService;
	}

	/**
	 * 短信发送
	 * 
	 * @param bizId
	 *            业务编号:如活动编号
	 * @param bizType
	 *            业务类型 如优惠券到期提醒overdueCouponRemind
	 * @param bizName
	 * 			  业务名称 
	 * @param merchantId
	 *            商户编号
	 * @param merchantName
	 *            商户简称
	 * @param storeId
	 *            门店编号
	 * @param customerIds
	 *            客户编号数组
	 * @param customerNames
	 *            会员姓名数组
	 * @param mobiles
	 *            手机号码数组
	 * @param content
	 *            短信内容
	 * @return 成功失败的结果信息
	 */
	public static Result[] send(String bizId, String bizType,String bizName,
			String merchantId, String merchantName, String storeId,
			String[] customerIds, String[] customerNames, String[] mobiles,
			String content) {
		return smsService.send(bizId, bizType,bizName, merchantId, merchantName,
				storeId, customerIds, customerNames, mobiles, content);
	}

	/**
	 * 短信发送
	 * 
	 * @param bizId
	 *            业务编号:如活动编号
	 * @param bizType
	 *            业务类型 如优惠券到期提醒overdueCouponRemind
	 * @param bizName
	 * 			  业务名称 
	 * @param merchantId
	 *            商户编号
	 * @param merchantName
	 *            商户简称
	 * @param storeId
	 *            门店编号
	 * @param customerId
	 *            客户编号
	 * @param customerName
	 *            会员姓名
	 * @param mobile
	 *            手机号码
	 * @param content
	 *            短信内容
	 * @return 成功失败的结果信息
	 */
	public static Result send(String bizId, String bizType, String bizName,String merchantId,
			String merchantName, String storeId, String customerId,
			String customerName, String mobile, String content) {
		Result[] rs = send(bizId, bizType, bizName, merchantId, merchantName, storeId,
				new String[] { customerId }, new String[] { customerName },
				new String[] { mobile }, content);
		return rs[0];
	}

	public static void main(String[] args) {
		String[] pathsOperation = { "classpath:spring-application.xml" };
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
				pathsOperation);
//		SmsUtil.send("bizId", "bizType","bizName",  "merchant", "merchantName", "storeId",
//				"customerId", "customerName", "12345678901", "templateId",
//				"templateName", "template [商户简称] [  [手机号]  [[会员姓名]]]",
//				new java.util.HashMap());

		SmsUtil.send("bizId", "bizType", "bizName", "merchant", "merchantName", "storeId",
				new String[] { "customerId1", "customerId2" }, new String[] {
						"customerName1", "customerName2" }, new String[] {
						"12345678901", "13465772853" }, "content");
		
		//black management
//		SmsUtil.setBlack("223333");
//		System.out.println("is black: " + SmsUtil.isBalck("223333"));
//		SmsUtil.setOpen("223333");
//		System.out.println("is black: " + SmsUtil.isBalck("223333"));
//		
//		SmsUtil.setBlack("223333","m1");
//		System.out.println("is black: " + SmsUtil.isBalck("223333","m1"));
//		SmsUtil.setOpen("223333","m1");
//		System.out.println("is black: " + SmsUtil.isBalck("223333","m1"));
		
		//System.out.println("sms count:" + querySmsRecordCount(null,null,null,null,null,null,null,null,null));
		List a = querySmsRecord(null,null,null,null,null,null,null,null,"2008-8-15",null, 1,4);
		System.out.println("sms count:" + a.size());

	}
	/**
	 * 判断是否是有效的手机号
	 * @return
	 */
	public static boolean isValidMobileCode(String mobileCode){
		if(mobileCode == null)
			return false;
		if(mobileCode.length() != 11)
			return false;
		if(!StringUtils.isNumeric(mobileCode))
			return false;
		if(mobileCode.startsWith("13") || mobileCode.startsWith("14") || mobileCode.startsWith("15") || mobileCode.startsWith("18"))
			return true;
		
		return false;
	}

	public static boolean isBalck(String customerId, String merchantId) {
		return smsService.isBalck(customerId, merchantId);
	}

	public static  boolean isBalck(String customerId) {
		return smsService.isBalck(customerId);
	}

	public  static void setBlack(String customerId, String merchantId) {
		smsService.setBlack(customerId, merchantId);
	}

	public  static void setBlack(String customerId) {
		smsService.setBlack(customerId);
	}

	public  static void setOpen(String customerId, String merchantId) {
		smsService.setOpen(customerId, merchantId);
	}

	public  static void setOpen(String customerId) {
		smsService.setOpen(customerId);
	}

	public static List<SmsRecord> querySmsRecord(String bizType,String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate, int beginPage, int pageSize) {
		return smsService.querySmsRecord(bizType,bizName, merchantId, storeId,
				customerId, mobile, templateName, content, beginDate, endDate,
				beginPage, pageSize);
	}

	public static int querySmsRecordCount(String bizType,String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate) {
		return smsService.querySmsRecordCount(bizType,bizName, merchantId, storeId,
				customerId, mobile, templateName, content, beginDate, endDate);
	}
	
	public static int querySmsSendCount(String bizId,String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate) {
		return smsService.querySmsSendCount(bizId,bizName, merchantId, storeId,
				customerId, mobile, templateName, content, beginDate, endDate);
	}
	
	public static List<SmsRecord> querySmsRecordArchive(String bizType,String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate, int beginPage, int pageSize) {
		return smsService.querySmsRecordArchive(bizType,bizName, merchantId, storeId,
				customerId, mobile, templateName, content, beginDate, endDate,
				beginPage, pageSize);
	}

	public static int querySmsRecordCountArchive(String bizType,String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate) {
		return smsService.querySmsRecordCountArchive(bizType,bizName, merchantId, storeId,
				customerId, mobile, templateName, content, beginDate, endDate);
	}
	
	public static int querySmsSendCountArchive(String bizId,String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate) {
		return smsService.querySmsSendCountArchive(bizId,bizName, merchantId, storeId,
				customerId, mobile, templateName, content, beginDate, endDate);
	}
	
	public static int querySmsSendCountArchiveForMarketingResult(String bizId,String bizName, String merchantId,
			String storeId, String customerId, String mobile,
			String templateName, String content, String beginDate,
			String endDate) {
		return smsService.querySmsSendCountArchiveForMarketingResult(bizId,bizName, merchantId, storeId,
				customerId, mobile, templateName, content, beginDate, endDate);
	}
	
	public static int querySmsSendCountByMarketingId(String marketingId,String bizType){
		return smsService.querySmsSendCountByMarketingId(marketingId,bizType);
	}
	
	public static int querySmsSentCountForOpenCardMarketing(String marketingId,String bizType){
		return smsService.querySmsSentCountForOpenCardMarketing(marketingId,bizType);
	}
}
