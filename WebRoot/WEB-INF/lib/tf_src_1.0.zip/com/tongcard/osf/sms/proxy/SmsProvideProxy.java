package com.tongcard.osf.sms.proxy;

import java.util.Map;

import com.tongcard.osf.sms.Result;
import com.tongcard.osf.sms.sp.SmsServiceProvider;

public class SmsProvideProxy implements SmsServiceProvider{
	private SmsServiceProvider ssp = null;

	public boolean isSupportMany() {
		return true;
	}

	public Result send(String mobile, String content, Map<String, Object> params) {
		return ssp.send(mobile, content, params);
	}

	public Result[] send(String[] mobiles, String content, Map<String, Object> params) {
		if(ssp.isSupportMany())
			return ssp.send(mobiles, content, params);
		else{
			Result[] r = new Result[mobiles.length];
			for(int i = 0; i< mobiles.length; i++){
				r[i] = ssp.send(mobiles[i], content, params);
			}
			return r;
		}
	}

	public SmsServiceProvider getSsp() {
		return ssp;
	}

	public void setSsp(SmsServiceProvider ssp) {
		this.ssp = ssp;
	}
	

}
