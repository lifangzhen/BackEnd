package com.tongcard.osf.sms.proxy;

import java.util.List;
import java.util.Map;

import com.tongcard.osf.sms.Result;
import com.tongcard.osf.sms.sp.SmsServiceProvider;

public class SmsProviderGroupProxy  implements SmsServiceProvider{
	public boolean isSupportMany(){
		for(SmsServiceProvider sp:sspl){
			if(sp.isSupportMany()){
				return true;
			}
		}
		return false;
	}

	public Result send(String mobile, String content, Map<String, Object> params) {
		Result r = null;
		for(SmsServiceProvider sp:sspl){
			r = sp.send(mobile, content, params);
			if(r.isSuccess()){
				break;
			}
		}
		return r;
	}
	/**
	 * 只采用第一个支持群发的接口进行发送
	 */
	public Result[] send(String[] mobiles, String content, Map<String, Object> params) {
		Result[] r = null;
		for(SmsServiceProvider sp:sspl){
			if(sp.isSupportMany()){
				r = sp.send(mobiles, content, params);
				break;
			}
		}
		return r;
	}

	private List<SmsServiceProvider> sspl = null;

	public List<SmsServiceProvider> getSspl() {
		return sspl;
	}

	public void setSspl(List<SmsServiceProvider> sspl) {
		this.sspl = sspl;
	}
	
}
