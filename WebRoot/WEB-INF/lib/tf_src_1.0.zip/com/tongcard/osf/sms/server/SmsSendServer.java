package com.tongcard.osf.sms.server;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.sql.DataSource;

import org.apache.commons.lang.math.RandomUtils;
import org.apache.commons.lang.time.DateFormatUtils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;



import com.tongcard.osf.sms.Result;
import com.tongcard.osf.sms.SmsUtil;
import com.tongcard.osf.sms.sp.SmsServiceProvider;

public class SmsSendServer implements InitializingBean{
	
	protected static Log log = LogFactory.getLog(SmsSendServer.class);
	
	public static long DURATION = 2 * 3600 * 1000;
	
	private String readySendSql = "insert into SMS_SENT(batch_id, id, mobile, content, ready_sent_time,sent_result)select ?, id, tpa, msg, sysdate, 'ready_send' from tb_sndtmp where mod(id,?) = ? and rownum <= 100";

	private String tagSentSql = "delete from tb_sndtmp t where exists( select 1 from SMS_SENT s where t.id = s.id and s.batch_id = ?)";

	private String querySendSql = "select id, mobile, content from SMS_SENT s where s.batch_id = ?  order by id desc";
		
	private String updateSentResultSql = "update SMS_SENT set sent_result = ?, result_info = ?,work_thread = ?, SENT_TIME = sysdate where batch_id=? and id = ?";
	
	private String deleteSql = "delete from tb_sndtmp t where t.id = ?";
	
	
	private DataSource ds=null;
	
	private int poolSize = 1;
	
	private ExecutorService pool = null;
	
	private Map<Integer, Future> futures = new HashMap<Integer, Future>();
	private Map<Integer, Long> startTimes = new HashMap<Integer, Long>();
	
	private SmsServiceProvider ssp = null;
	
	public void afterPropertiesSet() throws Exception {
		pool = Executors.newFixedThreadPool(this.poolSize);	
	}
	
	public DataSource getDs() {
		return ds;
	}

	public void setDs(DataSource ds) {
		this.ds = ds;
	}
	
	public void sendSms(){
		for(int i = 0; i< poolSize; i++){
			Future lastFuture = futures.get(i);
			long now = System.currentTimeMillis();
			long startTime = lastFuture == null? now:startTimes.get(i);
			
			if(lastFuture == null || lastFuture.isCancelled() || lastFuture.isDone() || (now - startTime > DURATION)){
				if(now - startTime > DURATION)
					lastFuture.cancel(true);
				Future f = pool.submit(new SmsSendTask(i));
				futures.put(i, f);
				startTimes.put(i, now);
			}
		}
	}
	
	public class SmsSendTask implements java.util.concurrent.Callable<Void>{
		private int magicNumber = 0;
		public SmsSendTask(int number){
			this.magicNumber = number;
		}
		public Void call() throws Exception {
			String batchId = DateFormatUtils.format(new Date(), "yyyyMMddhhmmssSSS") + RandomUtils.nextInt();
			send(batchId);
			return null;
		}
		/**
		 * 发送短信，并更新发送结果
		 * @param batchId
		 */
		private void send(final String batchId){
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			jdbcTemplate.execute(new ConnectionCallback(){
				public Object doInConnection(Connection conn){
					
					PreparedStatement readySendpstm = null;
					
					PreparedStatement queryPstm = null;
					ResultSet rs = null;
					PreparedStatement updatePstm = null;
					PreparedStatement deletePstm = null;
					try{
						conn.setAutoCommit(true);
						readySendpstm = conn.prepareStatement(readySendSql);
						readySendpstm.setString(1, batchId);
						readySendpstm.setInt(2, poolSize);
						readySendpstm.setInt(3, magicNumber);
						
						readySendpstm.execute();
						int sendNum = readySendpstm.getUpdateCount();
						if(sendNum > 0){
							
							//准备发送
							queryPstm = conn.prepareStatement(querySendSql);
							queryPstm.setString(1, batchId);
							rs = queryPstm.executeQuery();
							//更新发送结果
							updatePstm = conn.prepareStatement(updateSentResultSql);
							deletePstm = conn.prepareStatement(deleteSql);
							while(rs.next()){
								
								int smsId = rs.getInt("id");
								String mobile = rs.getString("mobile");
								boolean isValidMobile =  SmsUtil.isValidMobileCode(mobile);
								String content = rs.getString("content");
								Result r = null;
								if(isValidMobile){
									try {
										r = ssp.send(mobile, content, null);
									} catch (RuntimeException e) {
										r = new Result();
										r.setContent(content);
										r.setMobile(mobile);
										r.setSuccess(false);
										r.setErrorType("未知");
										r.setErrorInfo(e.getMessage());
										log.error(e.getMessage(),e);
									}
								}
								else{
									r = new Result();
									r.setContent(content);
									r.setMobile(mobile);
									r.setSuccess(false);
									r.setErrorType("无效");
									r.setErrorInfo("无效号码");
								}
								
								updatePstm.setString(1, String.valueOf(r.isSuccess()));
								updatePstm.setString(2, r.getErrorType() + ":" + r.getErrorInfo());
								updatePstm.setInt(3,magicNumber);
								updatePstm.setString(4, batchId);
								updatePstm.setInt(5, smsId);
								updatePstm.execute();
								if(r.isSuccess() || !isValidMobile){
									deletePstm.setInt(1,smsId);
									deletePstm.execute();
								}
							}
						}
					}
					catch(SQLException e){
						e.printStackTrace();
					}
					finally{
						
							if(readySendpstm != null){
								try{
								
									readySendpstm.close();
								}
								catch(SQLException ee){
									
								}
							}
							
							if(rs != null){
								try{
								
									rs.close();
								}
								catch(SQLException ee){
									
								}
							}
							
							if(deletePstm != null){
								try{
								
									deletePstm.close();
								}
								catch(SQLException ee){
									
								}
							}
							
							if(queryPstm != null){
								try{
								
									queryPstm.close();
								}
								catch(SQLException ee){
									
								}
							}
							
							if(updatePstm != null){
								try{
								
									updatePstm.close();
								}
								catch(SQLException ee){
									
								}
							}
					}					
					return null;
				}
			});
		}
	}
	

	public SmsServiceProvider getSsp() {
		return ssp;
	}

	public void setSsp(SmsServiceProvider ssp) {
		this.ssp = ssp;
	}

	public int getPoolSize() {
		return poolSize;
	}

	public void setPoolSize(int poolSize) {
		this.poolSize = poolSize;
	}
}
