package com.tongcard.osf.sms.sp;

import java.util.Map;

import com.tongcard.osf.sms.Result;

/**
 * 
 * @author admin
 *
 */
public interface SmsServiceProvider {
	/**
	 * 是否支持群发
	 * @return
	 */
	public boolean isSupportMany();
	/**
	 * 群发短信
	 * @param mobiles
	 * @param content
	 * @return
	 */
	public Result[] send(String[] mobiles, String content, Map<String, Object> params);
	/**
	 * 单发短信
	 * @param mobile
	 * @param content
	 * @param params 方便携带其他参数
	 * @return
	 */
	public Result send(String mobile, String content, Map<String, Object> params);
	
}
