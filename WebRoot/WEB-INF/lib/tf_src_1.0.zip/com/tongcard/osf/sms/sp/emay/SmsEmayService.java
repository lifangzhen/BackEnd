package com.tongcard.osf.sms.sp.emay;

import java.util.Date;
import java.util.Map;

import cn.net.emay.metone.api.Client;

import com.tongcard.osf.sms.Result;
import com.tongcard.osf.sms.sp.SmsServiceProvider;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.DisposableBean;

public class SmsEmayService implements SmsServiceProvider , InitializingBean, DisposableBean{
	

	private String userAccount = null;
	private String password = null;
	private Client client = null;
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserAccount() {
		return userAccount;
	}

	public void setUserAccount(String userAccount) {
		this.userAccount = userAccount;
	}

	public void afterPropertiesSet() throws Exception {
		client = new Client(userAccount);
		client.registEx(password);
	}
	public void destroy() throws Exception {
		client.logout();		
	}
	public boolean isSupportMany() {
		return true;
	}

	public Result[] send(String[] mobiles, String content, Map<String, Object> params) {
		Date currentTime = new Date();
		boolean result = client.sendSMS(mobiles,content);
		Result[] rs = new Result[mobiles.length];
		for(int i = 0; i < mobiles.length;i++){
			rs[i] = new Result();
			Result r=rs[i];
			r.setSuccess(result);
			r.setMobile(mobiles[i]);
			r.setTime(currentTime);
		}
		return rs;
	}

	public Result send(String mobile, String content, Map<String, Object> params) {
		Date currentTime = new Date();
		boolean result = client.sendSMS(new String[]{mobile},content);
		Result r = new Result();
		r.setSuccess(result);
		r.setMobile(mobile);
		r.setTime(currentTime);

		return r;
	}

}
