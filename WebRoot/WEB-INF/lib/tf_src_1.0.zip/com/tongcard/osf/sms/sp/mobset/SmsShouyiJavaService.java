package com.tongcard.osf.sms.sp.mobset;

import java.util.Date;
import java.util.Calendar;
import java.util.Map;

import com.tongcard.osf.sms.Result;
import com.tongcard.osf.sms.sp.SmsServiceProvider;

import mobset.smsSDK;
import mobset.str_SendMsg;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.DisposableBean;



public class SmsShouyiJavaService implements SmsServiceProvider , InitializingBean, DisposableBean{
	
	private int comAccount = 107749;
	private String userAccount = null;
	private String password = null;
	private smsSDK client = null;
	private long lastCheckTime = 0;
	private long lastInformTime = 0;
	private int informHour = 10;
	private int informDuration = 1;
	//低于警戒值时，通知管理员
	private String adminMobile = null;
	private int warningNum = 1000;
	
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserAccount() {
		return userAccount;
	}

	public void setUserAccount(String userAccount) {
		this.userAccount = userAccount;
	}
	private void heartBeatCheck(){
		Thread t = new Thread(new java.lang.Runnable(){
			public void run() {
				while(true){
					Calendar c = Calendar.getInstance();
					int currentHour = c.get(Calendar.HOUR_OF_DAY);
					lastCheckTime = c.getTimeInMillis();
					try{
						int result = client.Sms_KYSms();
						
						if(result < 0){
							try{
								client.Sms_DisConnect();
							}
							catch(Exception e){}
							int iRet = client.Sms_Connect("www.mobset.com",comAccount,userAccount,password,30); //测试时请更改企业ID,用户名,密码
							if ( iRet==0 )//登录成功
						    	System.out.println("首易短信服务商签到成功");
						    else 
						    	System.out.println("首易短信服务商签到失败,返回码：" + iRet);
						}
						else if(result < warningNum && adminMobile != null ){
							if(c.getTimeInMillis() - lastInformTime >= informDuration * 3600 * 24 * 1000 && currentHour == informHour){
								send(adminMobile,"首易短信服务还剩" + result + "条，需尽快充值", null);
								lastInformTime = c.getTimeInMillis();
							}
						}
					}
					catch(Exception e){
						try{
							client.Sms_DisConnect();
						}
						catch(Exception ee){}
						int iRet = client.Sms_Connect("www.mobset.com",comAccount,userAccount,password,30); //测试时请更改企业ID,用户名,密码
						if ( iRet==0 )//登录成功
					    	System.out.println("首易短信服务商签到成功");
					    else 
					    	System.out.println("首易短信服务商签到失败,返回码：" + iRet);
					}
					try{
						Thread.currentThread().sleep(120000);
					}
					catch(Exception e){}
				}
			}
		});
		t.start();
	}
	public void afterPropertiesSet() throws Exception {
		client = new smsSDK();
	    int iRet = client.Sms_Connect("www.mobset.com",comAccount,userAccount,password,30); //测试时请更改企业ID,用户名,密码
	    lastCheckTime = System.currentTimeMillis();
	    if ( iRet==0 ){//登录成功
	    	
	    	System.out.println("首易短信服务商签到成功");
	    	
	    }else{
	    	System.out.println("首易短信服务商签到失败,返回码：" + iRet);
	    }
	    heartBeatCheck();	   
	}
	public void destroy() throws Exception {
		client.Sms_DisConnect();
		System.out.println("首易短信服务商签出");
	}
	public boolean isSupportMany() {
		return true;
	}

	public Result[] send(String[] mobiles, String content, Map<String, Object> params) {
		Date currentTime = new Date();
		str_SendMsg[] sendMsg = new str_SendMsg[mobiles.length];
		for(int i = 0; i < mobiles.length;i++){
			sendMsg[i]= new str_SendMsg();
			sendMsg[i].strMobile = mobiles[i];
			sendMsg[i].strMsg = content;
		}
		boolean isSent = false;
		int result = client.Sms_Send(sendMsg,mobiles.length);
		if(result >= 0){
			isSent = true;
		}
		else if(result == -2 || result == -1) {
			if(System.currentTimeMillis() - lastCheckTime > 60000){
				try{
					client.Sms_DisConnect();
				}
				catch(Exception e){}
				int iRet = client.Sms_Connect("www.mobset.com",comAccount,userAccount,password,30); //测试时请更改企业ID,用户名,密码
				lastCheckTime = System.currentTimeMillis();
				if ( iRet==0 )//登录成功
			    	System.out.println("首易短信服务商签到成功");
			    else 
			    	System.out.println("首易短信服务商签到失败,返回码：" + iRet);
				if(iRet==0)
					return send(mobiles,content, params);
			}
		}
		Result[] rs = new Result[mobiles.length];
		for(int i = 0; i < mobiles.length;i++){
			rs[i] = new Result();
			Result r=rs[i];
			r.setSuccess(isSent);
			r.setMobile(mobiles[i]);
			r.setTime(currentTime);
			r.setErrorType(String.valueOf(result));
		}
		return rs;
	}

	public Result send(String mobile, String content, Map<String, Object> params) {
		return send(new String[]{mobile},content, params)[0];
	}

	public int getComAccount() {
		return comAccount;
	}

	public void setComAccount(int comAccount) {
		this.comAccount = comAccount;
	}

	public String getAdminMobile() {
		return adminMobile;
	}

	public void setAdminMobile(String adminMobile) {
		this.adminMobile = adminMobile;
	}

	public int getInformHour() {
		return informHour;
	}

	public void setInformHour(int informHour) {
		this.informHour = informHour;
	}

	public int getWarningNum() {
		return warningNum;
	}

	public void setWarningNum(int warningNum) {
		this.warningNum = warningNum;
	}

	public int getInformDuration() {
		return informDuration;
	}

	public void setInformDuration(int informDuration) {
		this.informDuration = informDuration;
	}

}
