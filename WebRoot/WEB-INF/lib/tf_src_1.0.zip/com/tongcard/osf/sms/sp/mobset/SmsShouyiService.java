package com.tongcard.osf.sms.sp.mobset;

import java.util.Date;
import java.util.Calendar;
import java.util.Map;

import com.tongcard.osf.sms.Result;
import com.tongcard.osf.sms.sp.SmsServiceProvider;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.DisposableBean;



public class SmsShouyiService implements SmsServiceProvider , InitializingBean, DisposableBean{
	
	private int comAccount = 107749;
	private String userAccount = null;
	private String password = null;
	private long lastCheckTime = 0;
	private long lastInformTime = 0;
	private int informHour = 10;
	private int informDuration = 1;
	//低于警戒值时，通知管理员
	private String adminMobile = null;
	private int warningNum = 1000;
	
	private String baseUrl = "http://web.mobset.com/SDK";
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserAccount() {
		return userAccount;
	}

	public void setUserAccount(String userAccount) {
		this.userAccount = userAccount;
	}
	private void balanceMonitor(){
		Thread t = new Thread(new java.lang.Runnable(){
			public void run() {
				while(true){
					Calendar c = Calendar.getInstance();
					int currentHour = c.get(Calendar.HOUR_OF_DAY);
					lastCheckTime = c.getTimeInMillis();
					try{
						if(currentHour == informHour && c.getTimeInMillis() - lastInformTime >= informDuration * 3600 * 24 * 1000){							
						int result = queryBalance();
							if (result > 0 && result < warningNum
									&& adminMobile != null) {
								send(adminMobile, "首易短信服务还剩" + result
										+ "条，需尽快充值", null);
								lastInformTime = c.getTimeInMillis();
							}
						}
					}
					catch(Exception e){
					}
					try{
						Thread.currentThread().sleep(informDuration * 3600 * 24 * 1000);
					}
					catch(Exception e){}
				}
			}
		});
		t.start();
	}
	public void afterPropertiesSet() throws Exception {
		balanceMonitor();	   
	}
	public void destroy() throws Exception {
	}
	public boolean isSupportMany() {
		return true;
	}

	public Result[] send(String[] mobiles, String content, Map<String, Object> params) {
		Date currentTime = new Date();
		Result[] rs = new Result[mobiles.length];
		for(int i = 0; i < mobiles.length;i++){
			int result = this.sendSms(mobiles[i], content);
			rs[i] = new Result();
			Result r=rs[i];
			if(result > 0)
				r.setSuccess(true);
			else
				r.setSuccess(false);
			r.setMobile(mobiles[i]);
			r.setTime(currentTime);
			r.setErrorType(String.valueOf(result));
			r.setErrorInfo(String.valueOf(result));
		}
		return rs;
	}

	public Result send(String mobile, String content, Map<String, Object> params) {
		return send(new String[]{mobile},content, params)[0];
	}

	public int getComAccount() {
		return comAccount;
	}

	public void setComAccount(int comAccount) {
		this.comAccount = comAccount;
	}

	public String getAdminMobile() {
		return adminMobile;
	}

	public void setAdminMobile(String adminMobile) {
		this.adminMobile = adminMobile;
	}

	public int getInformHour() {
		return informHour;
	}

	public void setInformHour(int informHour) {
		this.informHour = informHour;
	}

	public int getWarningNum() {
		return warningNum;
	}

	public void setWarningNum(int warningNum) {
		this.warningNum = warningNum;
	}

	public int getInformDuration() {
		return informDuration;
	}

	public void setInformDuration(int informDuration) {
		this.informDuration = informDuration;
	}
	public int sendSms(String mobile, String content){
		HttpClient httpclient = new HttpClient();
		//设置超时
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(30000); 
		httpclient.getParams().setHttpElementCharset("gbk");
		StringBuffer sb = new StringBuffer();
		sb.append(this.baseUrl)
			.append("/Sms_Send.asp?CorpID=").append(this.comAccount)
			.append("&LoginName=").append(this.userAccount)
			.append("&passwd=").append(this.password)
			.append("&send_no=").append(mobile)
			.append("&msg=").append(content);
		GetMethod get = new GetMethod(sb.toString());
		//设置超时
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(30000); 
		try
		{ 
			int result = httpclient.executeMethod(get);
			String returnValue = get.getResponseBodyAsString();
			if(get.getStatusCode()!=200)
		    {
				return -10;
		    }
			
			try{
				int pos = returnValue.indexOf(',');
				if(pos < 0)
					pos = returnValue.length();
				int rn = Integer.parseInt(returnValue.substring(0, pos));
				return  rn;
			}
			catch(Exception ee){
				return -11;
			}
			
		}
		catch(Exception e){
			return -12;
		}

		
	}
	public int queryBalance(){
		HttpClient httpclient = new HttpClient();
		StringBuffer sb = new StringBuffer();
		sb.append(this.baseUrl)
			.append("/Sms_KYSms.asp?CorpID=").append(this.comAccount)
			.append("&LoginName=").append(this.userAccount)
			.append("&passwd=").append(this.password);
		GetMethod get = new GetMethod(sb.toString());
		//设置超时
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(30000);
		try
		{ 
			int result = httpclient.executeMethod(get);
			String returnValue = get.getResponseBodyAsString();
			if(get.getStatusCode()!=200)
		    {
				return -10;
		    }
			
			try{
				int pos = returnValue.indexOf(',');
				if(pos < 0)
					pos = returnValue.length();
				int rn = Integer.parseInt(returnValue.substring(0, pos));
				return  rn;
			}
			catch(Exception ee){
				return -11;
			}
			
		}
		catch(Exception e){
			return -12;
		}

		
	}
}
