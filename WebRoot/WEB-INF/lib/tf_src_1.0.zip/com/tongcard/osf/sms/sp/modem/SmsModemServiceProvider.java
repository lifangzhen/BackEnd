package com.tongcard.osf.sms.sp.modem;

import com.tongcard.osf.sms.Result;
import com.tongcard.osf.sms.sp.SmsServiceProvider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.dao.DataAccessException;

import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;

public class SmsModemServiceProvider implements SmsServiceProvider,
		InitializingBean {
	protected static Log log = LogFactory.getLog(SmsModemServiceProvider.class);
	private JdbcTemplate jdbcTemplate = null;
	private DataSource ds = null;

	public DataSource getDs() {
		return ds;
	}

	public void setDs(DataSource ds) {
		this.ds = ds;
	}
	/**
	 * 两个参数，分别用?表达，前面一个是短信内容，后面一个是手机号，如:insert into tb_sndtmp(id,msg,tpa)values(SndID.nextval,?,?)
	 */
	private String smsSendSql = INSERT_SMS_SQL;
	
	public String getSmsSendSql() {
		return smsSendSql;
	}

	public void setSmsSendSql(String smsSendSql) {
		this.smsSendSql = smsSendSql;
	}

	public Result send(String mobile, String content, Map<String, Object> params) {
		Result r = new Result();
		try {
			Object[] args = new Object[4];
			args[0] = content;
			args[1] = mobile;
			args[2] = (String)params.get("biz_type");
			args[3] = (String)params.get("merchantId");
			jdbcTemplate.update(smsSendSql,args);
			r.setSuccess(true);
			r.setMobile(mobile);
		} catch (Exception e) {
			log.error(e.getMessage(),e);
			r.setSuccess(false);
			r.setMobile(mobile);
			r.setErrorType(Result.ROUTEWAY_ERROR);
			String eMsg = e.getMessage();
			if(eMsg != null && eMsg.length() > 500){
				eMsg = e.getMessage().substring(0, 500);
			}
			r.setErrorInfo(eMsg);
		}
		return r;
	}

	public boolean isSupportMany() {
		return true;
	}
	public Result[] send(final String[] mobiles, final String content, final Map<String, Object> params) {
		Object rs = jdbcTemplate.execute(new ConnectionCallback(){
			public Object doInConnection(Connection conn) throws SQLException, DataAccessException{
				Result[] rs = new Result[mobiles.length];
				conn.setAutoCommit(false);
				PreparedStatement pstmt = null;
				try{
					pstmt = conn.prepareStatement(smsSendSql);
					for(int i = 0; i< mobiles.length; i++){
						pstmt.setString(1, content);
						pstmt.setString(2, mobiles[i]);
						pstmt.setString(3, (String)params.get("biz_type"));
						pstmt.setString(4, (String)params.get("merchantId"));
						pstmt.addBatch();
						Result r = new Result();
						r.setSuccess(true);
						r.setMobile(mobiles[i]);
						rs[i] = r;
					}
					pstmt.executeBatch();
					conn.commit();
				}
				catch(Exception e){
					log.error(e.getMessage(),e);
					if(conn!= null)
						conn.rollback();
					for(int i = 0; i< mobiles.length; i++){
						rs[i].setSuccess(false);
						rs[i].setErrorType(Result.ROUTEWAY_ERROR);
						String eMsg = e.getMessage();
						if(eMsg != null && eMsg.length() > 500){
							eMsg = e.getMessage().substring(0, 500);
						}
						rs[i].setErrorInfo(eMsg);
					}
				}
				finally{
					if(pstmt!= null){
						try{
							pstmt.close();
						}
						catch(Exception e){
						}
					}
					if(conn!= null){
						try{
							conn.close();
						}
						catch(Exception e){
						}
					}
				}
				
				return rs;
			}
		});
		return (Result[])rs;
	}

	public void afterPropertiesSet() throws Exception {
		jdbcTemplate = new JdbcTemplate(ds);
	}

	private static final String INSERT_SMS_SQL = "insert into tb_sndtmp(id,msg,tpa,biz_type,merchant_id)values(SndID.nextval,?,?,?,?)";

}
