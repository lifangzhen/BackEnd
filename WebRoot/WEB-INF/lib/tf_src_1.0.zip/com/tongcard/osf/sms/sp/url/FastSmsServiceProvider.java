package com.tongcard.osf.sms.sp.url;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.CoreProtocolPNames;
import org.quartz.CronTrigger;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jdbc.core.JdbcTemplate;

import com.tongcard.osf.sms.DynamicProxyJob;
import com.tongcard.osf.sms.Result;
import com.tongcard.osf.sms.server.SmsSendServer;
import com.tongcard.osf.sms.sp.SmsServiceProvider;

public class FastSmsServiceProvider implements SmsServiceProvider, InitializingBean {
	
	protected static Log log = LogFactory.getLog(SmsSendServer.class);
	
	private String querySmsSendUrl = "select value from sys_constants_config where key = 'sms_send_url'";
	private String smsSendUrl = null;
	
	private int poolSize = 1;
	
	private ExecutorService pool = null;
	
	private Map<Integer, Future> futures = new HashMap<Integer, Future>();
	private Map<Integer, Long> startTimes = new HashMap<Integer, Long>();
	
	private Scheduler scheduler = null;
	
	private DataSource ds=null;
	
	private class CheckUrlJob implements Job{
		public CheckUrlJob(){}
		@Override
		public void execute(JobExecutionContext arg0)
				throws JobExecutionException {
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			Object o = jdbcTemplate.queryForObject(querySmsSendUrl, String.class);
			smsSendUrl = (String)o;
		}	
	}
	
	
	public void afterPropertiesSet() throws Exception {
		pool = Executors.newFixedThreadPool(this.poolSize);	
		//先初始化
		new CheckUrlJob().execute(null);
		//再定时更新
		SchedulerFactory sf = new StdSchedulerFactory();
		this.scheduler = sf.getScheduler();
		this.scheduler.start();	
		
		JobDetail job = new JobDetail("checkUrl"+ this.hashCode(), "checkUrl" + this.hashCode(), DynamicProxyJob.class);
		job.getJobDataMap().put("job", new CheckUrlJob());
		CronTrigger trigger = new CronTrigger("checkUrl_trigger"+ this.hashCode(), "checkUrl_tg"+ this.hashCode(), "checkUrl"+ this.hashCode(), "checkUrl"+this.hashCode(), "0 0/1 * * * ?");
		trigger.setMisfireInstruction(CronTrigger.MISFIRE_INSTRUCTION_DO_NOTHING);
		this.scheduler.scheduleJob(job, trigger);
		
	}
	
	public DataSource getDs() {
		return ds;
	}

	public void setDs(DataSource ds) {
		this.ds = ds;
	}

	public int getPoolSize() {
		return poolSize;
	}

	public void setPoolSize(int poolSize) {
		this.poolSize = poolSize;
	}
	
	@Override
	public boolean isSupportMany() {
		return false;
	}

	@Override
	public Result[] send(String[] mobiles, String content,
			Map<String, Object> params) {
		throw new UnsupportedOperationException("unsupport send(String[],String,Map)");
	}

	@Override
	public Result send(String mobile, String content, Map<String, Object> params) {
		
		Result r = new Result();
		r.setSuccess(true);
		try { 
			HttpClient httpclient = new DefaultHttpClient();
			httpclient.getParams().setParameter(CoreProtocolPNames.PROTOCOL_VERSION,HttpVersion.HTTP_1_1);
			httpclient.getParams().setParameter(CoreProtocolPNames.HTTP_CONTENT_CHARSET,"UTF-8");
			httpclient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 2000);
			String url = this.smsSendUrl.replace("$mobile$", mobile).replace("$msg$", URLEncoder.encode(content, "UTF-8"));
			log.debug("url = " + url);
			HttpGet httpGet = new HttpGet(url);
			
			HttpResponse response = httpclient.execute(httpGet);
			if(response.getStatusLine().getStatusCode()!=200) {
				r.setSuccess(false);
				r.setMobile(mobile);
				r.setErrorType(Result.ROUTEWAY_ERROR);
				r.setErrorInfo(content);
		    }	
		} catch(Exception e){
			r.setSuccess(false);
			r.setMobile(mobile);
			r.setErrorType(Result.ROUTEWAY_ERROR);
			String eMsg = e.getMessage();
			if(eMsg != null && eMsg.length() > 500){
				eMsg = e.getMessage().substring(0, 500);
			}
			r.setErrorInfo(eMsg);
		}
		return r;
	}

}
