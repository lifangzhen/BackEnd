/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.template;

import java.io.Reader;
import java.io.Writer;
import java.util.Map;

public interface TemplateEngine {
	void evaluate(Map context, Writer out, String logTag, String instring);

	void evaluate(Map context, Writer writer, String logTag, Reader reader);

	void evaluate(String templateName, Map context, Writer writer);

	void evaluate(String templateName, String encoding, Map context,
			Writer writer);

	String evaluate(Map context, String logTag, String instring);

	String evaluate(Map context, String logTag, Reader reader);

	String evaluate(String templateName, Map context);

	String evaluate(String templateName, String encoding, Map context);

}
