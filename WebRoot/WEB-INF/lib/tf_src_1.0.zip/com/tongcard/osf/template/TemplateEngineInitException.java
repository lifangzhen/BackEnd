/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.template;

public class TemplateEngineInitException extends RuntimeException{
	public TemplateEngineInitException(){
		super();
	}
	
	public TemplateEngineInitException(String msg){
		super(msg);
	}
	
	public TemplateEngineInitException(String msg, Throwable cause){
		super(msg, cause);
	}
	
	public TemplateEngineInitException(Throwable cause){
		super(cause);
	}
}
