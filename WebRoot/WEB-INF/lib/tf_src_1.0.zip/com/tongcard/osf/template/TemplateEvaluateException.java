/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.template;

public class TemplateEvaluateException extends RuntimeException{
	public TemplateEvaluateException(){
		super();
	}
	
	public TemplateEvaluateException(String msg){
		super(msg);
	}
	
	public TemplateEvaluateException(String msg, Throwable cause){
		super(msg, cause);
	}
	
	public TemplateEvaluateException(Throwable cause){
		super(cause);
	}
}
