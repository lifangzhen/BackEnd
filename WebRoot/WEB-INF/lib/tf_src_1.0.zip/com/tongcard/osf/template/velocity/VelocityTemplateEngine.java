/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.template.velocity;

import java.io.InputStream;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.ui.velocity.CommonsLoggingLogSystem;

import com.tongcard.osf.template.TemplateEngine;
import com.tongcard.osf.template.TemplateEngineInitException;
import com.tongcard.osf.template.TemplateEvaluateException;

public class VelocityTemplateEngine implements InitializingBean, TemplateEngine {
	protected final Log logger = LogFactory.getLog(getClass());

	private Properties velocityProperties;

	private Map tools = new HashMap();

	private Resource configLocation;

	private boolean overrideLogging = true;

	private VelocityEngine velocityEngine;

	public boolean isOverrideLogging() {
		return overrideLogging;
	}

	public void setOverrideLogging(boolean overrideLogging) {
		this.overrideLogging = overrideLogging;
	}

	public Resource getConfigLocation() {
		return configLocation;
	}

	public void setConfigLocation(Resource configLocation) {
		this.configLocation = configLocation;
	}

	public Properties getVelocityProperties() {
		return velocityProperties;
	}

	public void setVelocityProperties(Properties properties) {
		this.velocityProperties = properties;
	}

	public Map getTools() {
		return tools;
	}

	public void setTools(Map tools) {
		this.tools = tools;
	}

	public void afterPropertiesSet() throws Exception {
		velocityEngine = new VelocityEngine();
		Properties props = new Properties();

		// Load config file if set.
		if (this.configLocation != null) {
			if (logger.isInfoEnabled()) {
				logger.info("Loading Velocity config from ["
						+ this.configLocation + "]");
			}
			InputStream is = this.configLocation.getInputStream();
			try {
				props.load(is);
			} finally {
				is.close();
			}
		}

		// Merge local properties if set.
		if (this.velocityProperties != null && !this.velocityProperties.isEmpty()) {
			props.putAll(this.velocityProperties);
		}

		// Log via Commons Logging?
		if (this.overrideLogging) {
			props.put(RuntimeConstants.RUNTIME_LOG_LOGSYSTEM,
					new CommonsLoggingLogSystem());
		}
		// Apply properties to VelocityEngine.
		for (Iterator it = props.entrySet().iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			if (!(entry.getKey() instanceof String)) {
				throw new IllegalArgumentException("Illegal property key ["
						+ entry.getKey() + "]: only Strings allowed");
			}
			velocityEngine.setProperty((String) entry.getKey(), entry
					.getValue());
		}

		try {
			// Perform actual initialization.
			velocityEngine.init();
		} catch (Exception ex) {
			logger.error("Init VelocityEngine failed!", ex);
			throw new TemplateEngineInitException(ex);
		}

	}

	public void evaluate(Map context, Writer writer, String logTag,
			String instring) {
		try {
			Map model = new HashMap(context);
			if(this.tools != null)
			model.putAll(this.tools);
			VelocityContext velocityContext = new VelocityContext(model);
			velocityEngine.evaluate(velocityContext, writer, logTag, instring);

		} catch (Exception ex) {
			logger.error("Evaluate template[" + instring + "] failed!", ex);
			throw new TemplateEvaluateException(ex);
		}
	}

	public void evaluate(Map context, Writer writer, String logTag,
			Reader reader) {
		try {
			Map model = new HashMap(context);
			if(this.tools != null)
			model.putAll(this.tools);
			VelocityContext velocityContext = new VelocityContext(model);
			velocityEngine.evaluate(velocityContext, writer, logTag, reader);

		} catch (Exception ex) {
			logger.error("Evaluate template failed!", ex);
			throw new TemplateEvaluateException(ex);
		}
	}

	public void evaluate(String templateName, Map context, Writer writer) {
		try {
			
			Map model = new HashMap(context);
			if(this.tools != null)
			model.putAll(this.tools);
			VelocityContext velocityContext = new VelocityContext(model);
			velocityEngine.mergeTemplate(templateName, velocityContext, writer);
		} catch (Exception ex) {
			logger.error(
					"Evaluate template named " + templateName + " failed!", ex);
			throw new TemplateEvaluateException(ex);
		}
	}

	public void evaluate(String templateName, String encoding, Map context,
			Writer writer) {
		try {
			Map model = new HashMap(context);
			if(this.tools != null)
			model.putAll(this.tools);
			VelocityContext velocityContext = new VelocityContext(model);
			velocityEngine.mergeTemplate(templateName, encoding,
					velocityContext, writer);
		} catch (Exception ex) {
			logger.error(
					"Evaluate template named " + templateName + " failed!", ex);
			throw new TemplateEvaluateException(ex);
		}
	}

	public String evaluate(Map context, String logTag, String instring) {
		StringWriter result = new StringWriter();
		evaluate(context, result, logTag, instring);
		return result.toString();
	}

	public String evaluate(Map context, String logTag, Reader reader) {
		StringWriter result = new StringWriter();
		evaluate(context, result, logTag, reader);
		return result.toString();
	}

	public String evaluate(String templateName, Map context) {
		StringWriter result = new StringWriter();
		evaluate(templateName, context, result);
		return result.toString();
	}

	public String evaluate(String templateName, String encoding, Map context) {
		StringWriter result = new StringWriter();
		evaluate(templateName, encoding, context, result);
		return result.toString();
	}
}
