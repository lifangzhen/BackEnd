/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-12-24
 TODO
 */
package com.tongcard.osf.util;

/**
 * @author linyong
 *
 */
public class ChartData {
	private String propName;
	private String propType="";
	private Double propQuantity;
	public String getPropName() {
		//java.lang.
		return propName;
	}
	public void setPropName(String propName) {
		this.propName = propName;
	}
	public Double getPropQuantity() {
		return propQuantity;
	}
	public void setPropQuantity(Double propQuantity) {
		this.propQuantity = propQuantity;
	}
	public String getPropType() {
		return propType;
	}
	public void setPropType(String propType) {
		this.propType = propType;
	}
}
