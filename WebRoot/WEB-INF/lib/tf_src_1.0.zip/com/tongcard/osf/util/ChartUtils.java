/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-12-24
 TODO
 */
package com.tongcard.osf.util;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.servlet.ServletUtilities;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.StandardEntityCollection;
import java.util.List;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import java.util.Iterator;
import org.jfree.data.general.DefaultPieDataset;
import java.math.BigDecimal;
import java.awt.Color;
import java.awt.Font;

import org.jfree.chart.plot.*;

/**
 * @author linyong
 * 
 */
public class ChartUtils {

	private String chartTitle = "";

	private String chartWidth = "600";

	private String chartHight = "400";

	private String chartX = "";

	private String chartY = "";
	
	private String chartZ = "";
	
	private static String noData = "没有数据输出!";
	
	private static Font fontTitle = new Font("SansSerif", Font.PLAIN, 13);

	private static String prefixUrl = "/servlet/DisplayChart?filename=";

	public String createChartBar(HttpServletRequest request, List datelist)
			throws Exception {

		DefaultCategoryDataset data = new DefaultCategoryDataset();

		for (int i = 0; i < datelist.size(); i++) {
			ChartData chartData = (ChartData) datelist.get(i);
			if (chartData.getPropQuantity() != null&&chartData.getPropName()!=null)
				data.setValue(chartData.getPropQuantity(), "", chartData
						.getPropName());
		}

		JFreeChart chart = ChartFactory.createBarChart(chartTitle, // tilte
				chartX, // X
				chartY, // Y
				data, // dataset
				PlotOrientation.VERTICAL, // view direction
				true, // 
				false, // 
				false // 
				);
		chart.getTitle().setFont(fontTitle);
		chart.setBackgroundPaint(java.awt.Color.white);
		CategoryPlot plot = (CategoryPlot) chart.getPlot();
		// plot.setBackgroundPaint(Color.lightGray);
		plot.setRangeGridlinePaint(Color.lightGray);
		plot.setRangeGridlinesVisible(true);
		plot.setDomainGridlinesVisible(true);

		final CategoryItemRenderer renderer3 = new LineAndShapeRenderer();
		plot.setRenderer(2, renderer3);
		plot.mapDatasetToRangeAxis(2, 1);

		// change the rendering order so the primary dataset appears "behind"
		// the
		// other datasets...
		plot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);

		// plot.getDomainAxis().setCategoryLabelPositions(CategoryLabelPositions.UP_45);
		plot.setNoDataMessage(noData);
		plot.setNoDataMessagePaint(Color.RED);
		ChartRenderingInfo info = new ChartRenderingInfo(
				new StandardEntityCollection());
		String filename = ServletUtilities.saveChartAsPNG(chart, Integer
				.parseInt(chartWidth), Integer.parseInt(chartHight), info,
				request.getSession());
		String graphURL = request.getContextPath() + prefixUrl + filename;
		return graphURL;

	}
	
	public String createChartBarOverLaid(HttpServletRequest request, List datelist,List datelistOverLaid)
	throws Exception {

		DefaultCategoryDataset data = new DefaultCategoryDataset();
		
		for (int i = 0; i < datelist.size(); i++) {
			ChartData chartData = (ChartData) datelist.get(i);
			if (chartData.getPropQuantity() != null&&chartData.getPropName()!=null)
				data.setValue(chartData.getPropQuantity(), chartData.getPropType(), chartData
						.getPropName());
		}
		
		JFreeChart chart = ChartFactory.createBarChart(chartTitle, // tilte
				chartX, // X
				chartY, // Y
				data, // dataset
				PlotOrientation.VERTICAL, // view direction
				true, // 
				false, // 
				false // 
				);
		chart.getTitle().setFont(fontTitle);
		chart.setBackgroundPaint(java.awt.Color.white);
		CategoryPlot plot = (CategoryPlot) chart.getPlot();
		// plot.setBackgroundPaint(Color.lightGray);
		plot.setRangeGridlinePaint(Color.lightGray);
		plot.setRangeGridlinesVisible(true);
		plot.setDomainGridlinesVisible(true);
		
		//...
		final ValueAxis rangeAxis = new NumberAxis(chartZ);
		plot.setRangeAxis(1, rangeAxis);
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		for (int i = 0; i < datelistOverLaid.size(); i++) {
			ChartData chartData = (ChartData) datelistOverLaid.get(i);
			if (chartData.getPropQuantity() != null&&chartData.getPropName()!=null)
				dataset.addValue(chartData.getPropQuantity(), chartData.getPropType(), chartData
						.getPropName());
		}
		
		plot.setDataset(2, dataset);
		final CategoryItemRenderer renderer = new LineAndShapeRenderer();
		plot.setRenderer(2, renderer);
		plot.mapDatasetToRangeAxis(2, 1);
		
		// change the rendering order so the primary dataset appears "behind"
		// the
		// other datasets...
		plot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
		
		    //plot.getRangeAxis().ssetCategoryLabelPositions(CategoryLabelPositions.UP_45);
		plot.setNoDataMessage(noData);
		plot.setNoDataMessagePaint(Color.RED);
		ChartRenderingInfo info = new ChartRenderingInfo(
				new StandardEntityCollection());
		String filename = ServletUtilities.saveChartAsPNG(chart, Integer
				.parseInt(chartWidth), Integer.parseInt(chartHight), info,
				request.getSession());
		String graphURL = request.getContextPath() + prefixUrl + filename;
		return graphURL;

}
	public String createChartLine(HttpServletRequest request, List datelist)
			throws Exception {

		DefaultCategoryDataset data = new DefaultCategoryDataset();

		for (int i = 0; i < datelist.size(); i++) {
			ChartData chartData = (ChartData) datelist.get(i);
			if (chartData.getPropQuantity() != null&&chartData.getPropName()!=null)
				data.setValue(chartData.getPropQuantity(), chartData.getPropType(), chartData
						.getPropName());
			// data.setValue(chartData.getPropQuantity() + 500, "Classes",
			// chartData
			// .getPropName());
			// data.setValue(chartData.getPropQuantity() + 800, "Classes",
			// chartData
			// .getPropName());
		}

		JFreeChart chart = ChartFactory.createLineChart(chartTitle, // tilte
				chartX, // X
				chartY, // Y
				data, // dataset
				PlotOrientation.VERTICAL, // view direction
				true, // 
				true, // 
				false // 
				);
		chart.getTitle().setFont(fontTitle);
		chart.setBackgroundPaint(java.awt.Color.white);
		CategoryPlot plot = (CategoryPlot) chart.getPlot();
		// plot.setBackgroundPaint(Color.lightGray);
		plot.setRangeGridlinePaint(Color.lightGray);
		plot.setRangeGridlinesVisible(true);
		plot.setDomainGridlinesVisible(true);
		final CategoryItemRenderer renderer = new LineAndShapeRenderer();
		/*
		 * LineAndShapeRenderer renderer = (LineAndShapeRenderer)
		 * plot.getRenderer(); renderer.setShapesVisible(true);
		 * renderer.setDrawOutlines(true); renderer.setUseFillPaint(true);
		 * //renderer.setFillPaint(Color.green);
		 */
		plot.setRenderer(renderer);
		plot.setNoDataMessage(noData);
		plot.setNoDataMessagePaint(Color.RED);
		ChartRenderingInfo info = new ChartRenderingInfo(new StandardEntityCollection());
		String filename = ServletUtilities.saveChartAsPNG(chart, Integer.parseInt(chartWidth), Integer.parseInt(chartHight), info,
				request.getSession());
		String graphURL = request.getContextPath() + prefixUrl + filename;
		return graphURL;
	}

	public String createChartPie(HttpServletRequest request, List datelist)
			throws Exception {
		DefaultPieDataset data = new DefaultPieDataset();
		List list = getRatio(datelist);
		for (int i = 0; i < list.size(); i++) {
			ChartData chartData = (ChartData) list.get(i);
			if (chartData.getPropQuantity() != null&&chartData.getPropName()!=null)
				data.setValue(chartData.getPropName(), chartData
						.getPropQuantity());
		}
		// PiePlot plot = new PiePlot(data);

		// JFreeChart chart = new JFreeChart(chartTitle,
		// JFreeChart.DEFAULT_TITLE_FONT,
		// plot, true);

		final JFreeChart chart = ChartFactory.createPieChart(chartTitle, // chart
																			// title
				data, // dataset
				true, // include 
				true, false);
		final PiePlot plot = (PiePlot) chart.getPlot();
		plot.setNoDataMessage(noData);
		plot.setNoDataMessagePaint(Color.RED);
		plot.setExplodePercent(1, 0.30);
		plot.setBackgroundPaint(Color.white);
		// plot.setLegendLabelGenerator(new
		// StandardPieSectionLabelGenerator("{0}: ({1}M, {2})"));
		// plot.setPercentFormatString("#,###0.0#%");
		// plot.setLegendLabelGenerator(new PieSectionLabelGenerator("{0}:
		// ({1}M, {2})"));

		chart.getTitle().setFont(fontTitle);
		chart.setBackgroundPaint(java.awt.Color.white);
		ChartRenderingInfo info = new ChartRenderingInfo(
				new StandardEntityCollection());
		String filename = ServletUtilities.saveChartAsPNG(chart, Integer
				.parseInt(chartWidth), Integer.parseInt(chartHight), info,
				request.getSession());
		String graphURL = request.getContextPath() + prefixUrl + filename;
		return graphURL;
	}

	private List getRatio(List list) {
		List newList = new ArrayList();
		double result = 0.00;
		double total = 0.00;
		Iterator iter = list.iterator();
		while (iter.hasNext()) {
			ChartData chartData = (ChartData) iter.next();
			total += chartData.getPropQuantity();
		}
		if(total==0){
			return newList;
		}
		Iterator iter1 = list.iterator();
		while (iter1.hasNext()) {
			ChartData chartData = (ChartData) iter1.next();
			result = div((chartData.getPropQuantity() / total) * 10000, 100,2);
			chartData.setPropName(result + "%" + "  " + chartData.getPropName());
			newList.add(chartData);
		}

		return newList;
	}

	private static double div(double v1, double v2, int scale) {
		BigDecimal b1 = new BigDecimal(Double.toString(v1));
		BigDecimal b2 = new BigDecimal(Double.toString(v2));
		return b1.divide(b2, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	public String getChartHight() {
		return chartHight;
	}

	public void setChartHight(String chartHight) {
		this.chartHight = chartHight;
	}

	public String getChartTitle() {
		return chartTitle;
	}

	public void setChartTitle(String chartTitle) {
		this.chartTitle = chartTitle;
	}

	public String getChartWidth() {
		return chartWidth;
	}

	public void setChartWidth(String chartWidth) {
		this.chartWidth = chartWidth;
	}

	public String getChartX() {
		return chartX;
	}

	public void setChartX(String chartX) {
		this.chartX = chartX;
	}

	public String getChartY() {
		return chartY;
	}

	public void setChartY(String chartY) {
		this.chartY = chartY;
	}

	public String getChartZ() {
		return chartZ;
	}

	public void setChartZ(String chartZ) {
		this.chartZ = chartZ;
	}

}
