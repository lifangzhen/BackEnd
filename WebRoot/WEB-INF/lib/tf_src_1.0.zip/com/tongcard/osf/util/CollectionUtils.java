/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.util;

import java.util.Collection;
import java.util.Iterator;

public class CollectionUtils {
	public static String arrayToString(Object[] array){
		
		if(array == null || array.length == 0) return "";
		StringBuffer sb = new StringBuffer();
		for(int i = 0; i < array.length; i ++){
			sb.append(array[i]);
			if(i != array.length -1)
				sb.append(",");
		}
		return sb.toString();
	}
	
	public static String collectionToString(Collection collection){
		if(collection == null || collection.size() == 0) return "";
		Iterator iterator = collection.iterator();
		StringBuffer sb = new StringBuffer();
		while(iterator.hasNext()){
		
			sb.append(iterator.next());
			if(iterator.hasNext())
				sb.append(",");
		}
		return sb.toString();
	}
	
	public static boolean isInArray(Object value, Object[] array){
		if(array == null || array.length == 0) return false;
		for(int i = 0; i < array.length; i ++){
			if(array[i].equals(value)) return true;
		}
		return false;
	}
}
