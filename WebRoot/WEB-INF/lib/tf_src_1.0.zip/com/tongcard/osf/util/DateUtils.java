/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class DateUtils {
	public static String firstDayInYear(String year) {
		return year + "-01-01";
	}

	public static String lastDayInYear(String year) {
		return year + "-12-31";
	}

	public static String firstDayInMonth(String month) {
		return month + "-01";
	}

	public static String lastDayInMonth(String month) {
		return month + "-31";
	}

	public static Date afterDaysFromNow(int days) {
		Calendar current = Calendar.getInstance();
		long milliSeconds = current.getTimeInMillis();
		milliSeconds += days * 24 * 3600 * 1000L;
		return new Date(milliSeconds);
	}

	public static Date beforeDaysFromNow(int days) {
		Date current = new Date();
		long milliSeconds = current.getTime();

		milliSeconds = milliSeconds - days * 24 * 3600 * 1000L;
		return new Date(milliSeconds);
	}

	public static Date beforeDays(Date date, int days) {
		long milliSeconds = date.getTime();
		milliSeconds -= days * 24 * 3600 * 1000L;
		return new Date(milliSeconds);
	}

	public static Date afterDays(Date date, int days) {
		long milliSeconds = date.getTime();
		milliSeconds += days * 24 * 3600 * 1000L;
		return new Date(milliSeconds);
	}

	public static Date now() {
		return Calendar.getInstance().getTime();
	}

	public static Date fromString(String date, String pattern)throws Exception {
		try {
			if(date == null || date.length() == 0) return null;
			SimpleDateFormat format = new SimpleDateFormat(pattern);
			return format.parse(date);
		} catch (ParseException ex) {
			throw new Exception(ex);
		}
	}

	public static String toString(Date date, String pattern) {
		if(date == null ) return null;
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		return format.format(date);

	}

}
