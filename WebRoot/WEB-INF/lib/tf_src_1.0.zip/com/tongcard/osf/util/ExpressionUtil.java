package com.tongcard.osf.util;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


import org.apache.oro.text.regex.MalformedPatternException;
import org.apache.oro.text.regex.MatchResult;
import org.apache.oro.text.regex.Pattern;
import org.apache.oro.text.regex.PatternCompiler;
import org.apache.oro.text.regex.PatternMatcher;
import org.apache.oro.text.regex.PatternMatcherInput;
import org.apache.oro.text.regex.Perl5Compiler;
import org.apache.oro.text.regex.Perl5Matcher;

/**
 * 模板变量替换
 * @author admin
 *
 */
public abstract class ExpressionUtil {
	public static final String expressionPattern = "\\[[^\\[,^\\]]*\\]";
	public static String replace(String expression, Map context){

		for(Iterator iter = context.entrySet().iterator(); iter.hasNext();){
			Map.Entry entry = (Map.Entry)iter.next();
			if(entry.getValue() != null && entry.getValue().getClass().isArray()){
			   if(entry.getValue() instanceof String[]){
				   entry.setValue(convert((String[])entry.getValue()));
			   }
			   else if(entry.getValue() instanceof int[]){
				   entry.setValue(convert((int[])entry.getValue()));
			   }
			   else if(entry.getValue() instanceof long[]){
				   entry.setValue(convert((long[])entry.getValue()));
			   }
			   else if(entry.getValue() instanceof BigDecimal[]){
				   entry.setValue(convert((BigDecimal[])entry.getValue()));
			   }
			}
			else if(entry.getValue() instanceof String){
				;
			}
		}
		
		StringBuffer sb = new StringBuffer();
		
		int groups;
		PatternMatcher matcher;
		PatternCompiler compiler;
		Pattern pattern = null;
		PatternMatcherInput input;
		MatchResult result;
		 
		compiler = new Perl5Compiler();
		matcher  = new Perl5Matcher();
		
		try {
		  pattern = compiler.compile(expressionPattern);
		} catch(MalformedPatternException e) {
		
		}
		input   = new PatternMatcherInput(expression);

		int offset = 0;
		while(matcher.contains(input, pattern)) {
			result = matcher.getMatch();
			   groups = result.groups();

			   sb.append(expression.substring(offset, result.beginOffset(0)));

			   Object v = context.get(expression.substring(result.beginOffset(0) + 1, result.endOffset(0)-1));
			   if(v != null)
				   sb.append(v);
			   else
				   sb.append(expression.substring(result.beginOffset(0), result.endOffset(0)));

			   offset = result.endOffset(0);
		}

		sb.append(expression.substring(offset));
		return sb.toString();
	}
	private static String convert(String[] source){
		StringBuffer sb = new StringBuffer();
		if(source.length == 0){
			return "";
		}
		for(int i = 0; i < source.length;i ++ ){
			sb//.append('"')
				.append(source[i])
				//.append('"')
				.append(',');
		}
		sb.deleteCharAt(sb.length()-1);
		return sb.toString();
	}
	private static String convert(int[] source){
		StringBuffer sb = new StringBuffer();
		if(source.length == 0){
			return "";
		}
		for(int i = 0; i < source.length;i ++ ){

			sb.append(source[i])
				.append(',');
		}
		sb.deleteCharAt(sb.length()-1);
		return sb.toString();
	}
	private static String convert(long[] source){
		StringBuffer sb = new StringBuffer();
		if(source.length == 0){
			return "";
		}
		for(int i = 0; i < source.length;i ++ ){

			sb.append(source[i])
				.append(',');
		}
		sb.deleteCharAt(sb.length()-1);
		return sb.toString();
	}
	private static String convert(BigDecimal[] source){
		StringBuffer sb = new StringBuffer();
		if(source.length == 0){
			return "";
		}
		for(int i = 0; i < source.length;i ++ ){

			sb.append(source[i])
				.append(',');
		}
		sb.deleteCharAt(sb.length()-1);
		return sb.toString();
	}
	public static void main(String[] args) {
		HashMap a = new HashMap();
		//a.put("v1", new Long(123));
		a.put("v2", new String[]{"XYZ","FFFFF"});
		a.put("v3", "XXXXX");
		a.put("v4", new int[]{7,8,9});
		ExpressionUtil.replace("t.stage = [v1] and t.eee in [[v2]] and t.aaa=[[v3]] and t.num in [v4]]", a);

	}
}
