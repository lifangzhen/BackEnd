/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.util;

import java.util.HashMap;
import java.util.Map;

public class LanguageEncodingMap {
	private Map encodingByLanguageMap = new HashMap();

	public Map getEncodingByLanguageMap() {
		return encodingByLanguageMap;
	}

	public void setEncodingByLanguageMap(Map encodingByLanguageMap) {
		this.encodingByLanguageMap = encodingByLanguageMap;
	}
	
	public String getEncoding(String language){
		String encoding = (String)encodingByLanguageMap.get(language);
		if(encoding == null) encoding = (String)encodingByLanguageMap.get("default");
		return encoding;
	}
}
