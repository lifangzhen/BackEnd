/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.util;

import java.util.Locale;

public class LocaleUtils {
	public static Locale fromString(String locale){
		String[] elements = locale.split("_");
		if(elements.length == 0)
			return Locale.getDefault();
		else if(elements.length == 1)
			return new Locale(elements[0]);
		else if(elements.length == 2)
			return new Locale(elements[0], elements[1]);
		else 
			return new Locale(elements[0], elements[1], elements[2]);
	}
}
