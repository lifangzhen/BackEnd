/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.util;

import javax.xml.namespace.QName;

public interface OSFConstants {
	String SAVEPOINT_PREFIX = "osf.savepoint.";
	String LAST_REQUEST_URL = "osf.lastRequestUrl";
	String dataSource = "dataSource___";
	
	String SP_EMAY = "_EMay";
	String SP_M2 = "_M2";
	String SP_MODEM = "_Modem";
	
    //短信单价	
	public static final Integer SHORT_MESSAGE_PRICE = 10;
	
	//广告单价
	public static final Integer AD_PRICE = 100;
	
	//通卡收费比率
	public static final Integer TONGCARD_RATE = 10;
	
	//
	public static final QName SERVICE_NAME = new QName("http://intermobiz.com/", "Service");
	
	public static final String wsdl ="http://td.qykx.net/intermobizService.asmx?WSDL";
}
