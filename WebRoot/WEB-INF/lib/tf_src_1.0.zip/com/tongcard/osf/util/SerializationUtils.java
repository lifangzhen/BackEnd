/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.util;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerializationUtils {
	public static String encodeToXml(Serializable object) {

		ByteArrayOutputStream bo = new ByteArrayOutputStream();
		XMLEncoder encoder = new XMLEncoder(new BufferedOutputStream(bo));

		encoder.writeObject(object);
		encoder.close();
		return bo.toString();
	}

	public static Object decodeFromXml(String xml) {
		if (xml == null)
			return null;
		XMLDecoder d = new XMLDecoder(new BufferedInputStream(
				new ByteArrayInputStream(xml.getBytes())));
		Object result = d.readObject();
		d.close();
		return result;
	}

	public static byte[] encodeToByteArray(Serializable object) {
		ByteArrayOutputStream bo = new ByteArrayOutputStream();
		ObjectOutputStream oo = null;
		try {
			oo = new ObjectOutputStream(bo);
			oo.writeObject(object);

			return bo.toByteArray();
		} catch (IOException e) {
			e.printStackTrace();

			return null;
		} finally {
			if (oo != null) {
				try {
					oo.close();
				} catch (IOException e) {
				}
			}
		}

	}

	public static Object decodeFromByteArray(byte[] bytes) {
		ByteArrayInputStream bi = new ByteArrayInputStream(bytes);
		ObjectInputStream oi = null;

		try {
			oi = new ObjectInputStream(bi);
			Object result = oi.readObject();
			oi.close();
			return result;
		} catch (Exception e) {
			e.printStackTrace();

			return null;
		} finally {
			if (oi != null) {
				try {
					oi.close();
				} catch (IOException e1) {
				}

			}

		}
	}
}
