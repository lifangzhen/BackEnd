package com.tongcard.osf.util;

import org.aspectj.lang.ProceedingJoinPoint;
import org.perf4j.StopWatch;
import org.perf4j.commonslog.CommonsLogStopWatch;
/*
<beans xmlns="http://www.springframework.org/schema/beans"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xmlns:aop="http://www.springframework.org/schema/aop"
      xsi:schemaLocation="
http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-2.5.xsd
http://www.springframework.org/schema/aop http://www.springframework.org/schema/aop/spring-aop-2.5.xsd">

   <!-- this is the object that will be proxied by Spring's AOP infrastructure -->
   <bean id="fooService" class="x.y.service.DefaultFooService"/>

   <!-- this is the actual advice itself -->
   <bean id="profiler" class="com.tongcard.osf.util.StopWatchAspect"/>

   <aop:config>
      <aop:aspect ref="profiler">

         <aop:pointcut id="theExecutionOfSomeFooServiceMethod"
                    expression="execution(* x.y.service.FooService.getFoo(String,int))
                    and args(name, age)"/>

         <aop:around pointcut-ref="theExecutionOfSomeFooServiceMethod"
                  method="profile"/>

      </aop:aspect>
   </aop:config>

</beans>
 */
public class StopWatchAspect {
	private int order;
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public Object profile(ProceedingJoinPoint call) throws Throwable {
	      StopWatch clock = new CommonsLogStopWatch();
	      try{ 
	         return call.proceed();
	      } finally {
	         clock.stop(call.getTarget().getClass().getSimpleName() + '.' + call.toShortString());
	      }
	   }
}
