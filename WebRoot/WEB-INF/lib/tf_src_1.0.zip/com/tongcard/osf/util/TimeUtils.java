/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.util;

public class TimeUtils {
	public static boolean isTimeAfter(String time, String base) {
		if(base == null || base.length() == 0) return false;
		int hour1 = getHourFromTime(time);
		int hour2 = getHourFromTime(base);
		int min1 = getMinuteFromTime(time);
		int min2 = getMinuteFromTime(base);
		if (hour1 > hour2)
			return true;
		if (hour1 < hour2)
			return false;
		if (min1 > min2)
			return true;
		return false;
	}
	
	public static boolean isTimeBefore(String time, String base){
		if(base == null || base.length() == 0) return false;
		int hour1 = getHourFromTime(time);
		int hour2 = getHourFromTime(base);
		int min1 = getMinuteFromTime(time);
		int min2 = getMinuteFromTime(base);
		if (hour1 < hour2)
			return true;
		if (hour1 > hour2)
			return false;
		if (min1 < min2)
			return true;
		return false;
	}

	public static int getHourFromTime(String time) {
		String hour = time.substring(0, 2);
		if (time.endsWith("PM"))
			return Integer.parseInt(hour) + 12;
		else
			return Integer.parseInt(hour);
	}

	public static int getMinuteFromTime(String time) {
		String min = time.substring(3, 5);
		return Integer.parseInt(min);
	}
}
