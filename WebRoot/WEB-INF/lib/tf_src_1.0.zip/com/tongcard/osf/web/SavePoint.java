/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-12-12
 TODO
 */
package com.tongcard.osf.web;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;

public class SavePoint implements Serializable {
	private String requestUrl;

	private boolean async;

	private String target;

	private Map parameters = new HashMap();

	public SavePoint() {

	}

	public SavePoint(HttpServletRequest request, boolean async, String target) {
		this(request);
		this.async = async;
		this.target = target;
	}

	public SavePoint(String requestUrl, boolean async, String target) {
		this.requestUrl = requestUrl;
		this.async = async;
		this.target = target;
	}

	public SavePoint(HttpServletRequest request) {

		requestUrl = request.getServletPath();

		int markIndex = requestUrl.indexOf("?");
		if (markIndex != -1)
			requestUrl = requestUrl.substring(0, markIndex);
		parameters.putAll(request.getParameterMap());

	}

	public String getOriginalUrl() {
		StringBuffer result = new StringBuffer();

		if (requestUrl != null)
			result.append(requestUrl);
		if (!parameters.isEmpty()) {
			result.append("?");
			Set keys = parameters.keySet();
			Iterator iterator = keys.iterator();
			int parameterCount = 0;
			while (iterator.hasNext()) {
				String parameterName = (String) iterator.next();
				String[] values = (String[]) parameters.get(parameterName);
				for (int i = 0; i < values.length; i++) {
					if (parameterCount > 0)
						result.append("&");
					result.append(parameterName);
					result.append("=");
					result.append(values[i]);
					parameterCount++;
				}

			}
		}
		return Utf8URLencode(result.toString());

	}
	
	public String Utf8URLencode(String text) {
		StringBuffer result = new StringBuffer();
		for (int i = 0; i < text.length(); i++) {
			char c = text.charAt(i);
			if (c >= 0 && c <= 255) {
				result.append(c);
			} else {
				byte[] b = new byte[0];
				try {
					b = Character.toString(c).getBytes("UTF-8");
				} catch (Exception ex) {
				}
				for (int j = 0; j < b.length; j++) {
					int k = b[j];
					if (k < 0)
						k += 256;
					result.append("%" + Integer.toHexString(k).toUpperCase());
				}
			}
		}
		return result.toString();
	}
	
	public boolean isAsync() {
		return async;
	}

	public void setAsync(boolean async) {
		this.async = async;
	}

	public Map getParameters() {
		return parameters;
	}

	public void setParameters(Map parameters) {
		this.parameters = parameters;
	}

	public String getRequestUrl() {
		return requestUrl;
	}

	public void setRequestUrl(String requestUrl) {
		this.requestUrl = requestUrl;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}
}
