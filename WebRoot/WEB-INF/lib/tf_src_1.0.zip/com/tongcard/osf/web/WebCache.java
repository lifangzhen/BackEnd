/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.web;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class WebCache implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private Map codeSets = new HashMap();
	
	public Map getCodeSet(String codeSetName){
		return (Map)codeSets.get(codeSetName);
	}
	public CodeItem getCodeItem(String codeSetName, String code){
		Map codeSet = getCodeSet(codeSetName);
		if(codeSet == null)
			return null;
		return (CodeItem)codeSet.get(code);
	}
	
	public void addCodeItem(String codeSetName, CodeItem codeItem){
		Map codeSet = getCodeSet(codeSetName);
		if(codeSet == null){
			codeSet = new LinkedHashMap();
			codeSets.put(codeSetName, codeSet);
		}
		codeSet.put(codeItem.getCode(), codeItem);
	}
	
	public String[] getCodeDescs(String codeSetName, String[] values){
		Map codeSet = getCodeSet(codeSetName);
		if(values == null || codeSet == null) return new String[0];
		String[] descs = new String[values.length];
		for(int i = 0; i < values.length; i ++)
			descs[i] = ((CodeItem)codeSet.get(values[i])).getDescription();
		return descs;
	}
}
