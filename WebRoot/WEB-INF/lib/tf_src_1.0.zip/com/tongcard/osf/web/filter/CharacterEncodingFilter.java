/*
 Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

 Author: linyong
 Created: 2007-9-28
 TODO
 */
package com.tongcard.osf.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class CharacterEncodingFilter implements Filter {
	
	private String encoding = "UTF-8";
	


	public void init(FilterConfig config) throws ServletException {
		
		String encodingConfig = config.getInitParameter("encoding");
		if(encodingConfig != null)
			encoding = encodingConfig;
	
	}

	public void destroy() {
		this.encoding = "UTF-8";
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		request.setCharacterEncoding(encoding);
		//response.setCharacterEncoding("UTF-8");
		chain.doFilter(request, response);		
	}
}
