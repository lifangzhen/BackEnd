package com.tongcard.osf.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.perf4j.StopWatch;
import org.perf4j.commonslog.CommonsLogStopWatch;

public class Perf4jFilter implements Filter {
	
	boolean isOpen = false;

	public void init(FilterConfig config) throws ServletException {
		
		String open = config.getInitParameter("open");
		if("true".equals(open))
			isOpen = true;
	}

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest r = (HttpServletRequest)request;
		
		StopWatch clock= null;
		if(isOpen)
			clock = new CommonsLogStopWatch();
		try{
			chain.doFilter(request, response);
		}
		finally{
			if(isOpen)
				clock.stop(r.getServletPath());
		}
	}
}
