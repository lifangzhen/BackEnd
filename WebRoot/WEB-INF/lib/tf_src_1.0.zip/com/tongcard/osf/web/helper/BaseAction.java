package com.tongcard.osf.web.helper;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import com.tongcard.osf.remote.ServiceFactory;
import com.tongcard.osf.service.CommonQueryService;

public abstract class BaseAction extends ActionSupport implements
		ServletRequestAware, ServletResponseAware, SessionAware, Preparable {

	protected HttpServletRequest request;

	protected CommonQueryService commonQueryService;

	protected HttpServletResponse response;

	protected Map session;

	public void setSession(Map session) {
		this.session = session;
	}


	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	protected ServiceFactory serviceFactory;

	public void setServiceFactory(ServiceFactory serviceFactory) {
		this.serviceFactory = serviceFactory;
	}

	public void prepare() throws Exception {
		// TODO
	}

	public void validate() {

	}

	public CommonQueryService getCommonQueryService() {
		return commonQueryService;
	}

	public void setCommonQueryService(CommonQueryService commonQueryService) {
		this.commonQueryService = commonQueryService;
	}

}
