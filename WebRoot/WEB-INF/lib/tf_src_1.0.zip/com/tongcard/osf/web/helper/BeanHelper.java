package com.tongcard.osf.web.helper;

import javax.servlet.ServletContext;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class BeanHelper {
	private static ApplicationContext context = null;
	
	public static void init(ServletContext sc) {
		ApplicationContext ac = WebApplicationContextUtils.getWebApplicationContext(sc);
		if (ac == null) {
			throw new RuntimeException("�");
		}
		context = ac;
	}
	
	public static Object getBean(String name) {
		if (context == null) {
			throw new RuntimeException("");
		}
		return context.getBean(name);
	}
}
