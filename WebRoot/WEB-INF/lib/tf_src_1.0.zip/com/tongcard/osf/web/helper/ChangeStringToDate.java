package com.tongcard.osf.web.helper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class ChangeStringToDate {
	/**
	 * ���ַ��������ת��Ϊ��Date����
	 * 
	 * @param dateStr
	 *            Ҫ����ת�����ַ�
	 * @param kbn
	 *            1L����?ʼ���ڣ�2������������
	 * @return
	 */
	public static Date stringToDate(String dateStr, int kbn) {
		if(null == dateStr){
			return null;
		}
		StringBuffer sbdate = new StringBuffer(dateStr);
		if (1 == kbn) {
			sbdate.append("-00-00-00");
		} else if (2 == kbn) {
			sbdate.append("-23-59-59");
		} else if (3 == kbn) {
			sbdate.append("");
		} else {
			return null;
		}
		Date dret = null;
		
		try {
			SimpleDateFormat sFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
			dret = sFormat.parse(sbdate.toString());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			return null;
		}
		return dret;
	}
	public static String DateTostring(Date date) {
		if(null == date){
			return null;
		}
		String dret = null;
		
			SimpleDateFormat sFormat = new SimpleDateFormat("yyyyMMdd");
			dret = sFormat.format(date);
		
			// TODO Auto-generated catch block
		
		
		return dret;
	}
	
	public static String DateTostringWithHMS(Date date) {
		if(null == date){
			return null;
		}
		String dret = null;
		
			SimpleDateFormat sFormat = new SimpleDateFormat("yyyyMMddHHmmss");
			dret = sFormat.format(date);
		
			// TODO Auto-generated catch block
		
		
		return dret;
	}	
	
	
	public static String DateToStrFor(Date date) {
		if(null == date){
			return null;
		}
		String dret = null;
		
			SimpleDateFormat sFormat = new SimpleDateFormat("yyyy-MM-dd");
			dret = sFormat.format(date);
		
			// TODO Auto-generated catch block
		
		
		return dret;
	}
	
	public static Date strToDate(String dateStr){
		if(null == dateStr)
			return null;
		SimpleDateFormat sFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		try {
			date = sFormat.parse(dateStr);
		} catch (ParseException e) {
			return null;
		}
		return date;
	}
	
    public static Calendar getToday() throws ParseException {
        Date today = new Date();
        SimpleDateFormat df = new SimpleDateFormat("YYYY-MM-dd");

        // This seems like quite a hack (date -> string -> date),
        // but it works ;-)
        String todayAsString = df.format(today);
        Calendar cal = new GregorianCalendar();
        cal.setTime(stringToDate(todayAsString,1));

        return cal;
    }
    
    public static Calendar getTodayWithHMS() throws ParseException {
        Date today = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");

        // This seems like quite a hack (date -> string -> date),
        // but it works ;-)
        String todayAsString = df.format(today);
        Calendar cal = new GregorianCalendar();
        cal.setTime(stringToDate(todayAsString,3));

        return cal;
    }    
	
	public static void main(String args[]) {
		Date d = new Date();
		String s = ChangeStringToDate.DateToStrFor(d);
		System.out.println(s);
		System.out.println(s + " 00:00:00");
		System.out.println(s + " 23:59:59");
	}
	
	
}
