package com.tongcard.osf.web.helper;

public class CheckString {

	public static boolean checkString16(String str){
		String check = "\\d{16}";
    	boolean bool = java.util.regex.Pattern.matches(check, str);
    	return bool;
	}
	
	public static boolean checkString6(String str){
		String check = "\\d{6}";
    	boolean bool = java.util.regex.Pattern.matches(check, str);
    	return bool;
	}
	
	public static boolean checkString4(String str){
		String check = "\\d{4}";
    	boolean bool = java.util.regex.Pattern.matches(check, str);
    	return bool;
	}
	
	public static boolean checkZipCode(String str){
		String check = "^\\d{6}$";
		boolean bool = java.util.regex.Pattern.matches(check,str);
		return bool;
	}
	
	public static boolean checkUserContactPhone_1(String str){
		String check = "^\\d{3,4}$";
		boolean bool = java.util.regex.Pattern.matches(check,str);
		return bool;
	}
	
	public static boolean checkUserContactPhone_2(String str){
		String check = "^\\d{7,8}$";
		boolean bool = java.util.regex.Pattern.matches(check,str);
		return bool;
	}
	
	public static boolean checkUserContactPhone_3(String str){
		String check = "^[0-9]*$";
		boolean bool = java.util.regex.Pattern.matches(check,str);
		return bool;
	}
	
	public static boolean checkCardNum(String str){
		String check = "^\\d{16}$";
		boolean bool = java.util.regex.Pattern.matches(check,str);
		return bool;
	}
	
	public static boolean checkpassword(String str){
		String check = "^[a-zA-z0-9]{6,16}$";
		boolean bool = java.util.regex.Pattern.matches(check,str);
		return bool;
	}
	
	public static boolean checkUserCardId(String str){
		String check = "^[a-zA-Z0-9]{15,18}$" ;
		boolean bool = java.util.regex.Pattern.matches(check,str);
		return bool;
	}
	
	public static boolean checkMobile(String str){
		String check = "^\\d{11}$" ;
		boolean bool = java.util.regex.Pattern.matches(check,str);
		return bool;
	}
	
	public static boolean isNumber(String str){
		String check = "^[a-zA-Z0-9]$" ;
		boolean bool = java.util.regex.Pattern.matches(check,str);
		return bool;
	}
	public static boolean checkGoldCard(String str){
		String check = "^\\d{9,11}$" ;
		boolean bool = java.util.regex.Pattern.matches(check,str);
		return bool;
	}
}
