package com.tongcard.osf.web.helper;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CookieUtils {

	/**
	 * 从Http请求中读取指定名称的Cookie值
	 * 
	 * @param request	HttpServletRequest对象实例
	 * @param name		Cookie名称
	 * @return
	 * 			如果指定名称的Cookie值存在，则返回该Cookie值（String类型）；
	 * 			如果不存在，则返回null
	 */
	public static String readCookie(HttpServletRequest request, String name) {
		Cookie cookies[] = request.getCookies();
		Cookie sCookie = null;
		String sname = null;
		if (cookies == null || cookies.length == 0)
			return null;

		for (int i = 0; i < cookies.length; i++) {
			sCookie = cookies[i];
			sname = sCookie.getName();
			if (sname.equals(name))
				return sCookie.getValue();
		}
		return null;
	}	
	
	/**
	 * 写入Cookie对象
	 * 
	 * @param response	HttpServletResponse对象实例
	 * @param name		Cookie名称
	 * @param value		Cookie值
	 * @param timeout	Cookie失效时间，单位秒(timeout=0表示立即失效，即清除该名称的Cookie; timeout<0表示生存期与浏览器进程相同)
	 */
	public static void writeCookie(HttpServletResponse response, String name, String value, int timeout) {
		writeCookie(response, name, value, timeout, "/");
	}	

	/**
	 * 写入Cookie对象
	 * 
	 * @param response	HttpServletResponse对象实例
	 * @param name		Cookie名称
	 * @param value		Cookie值
	 * @param timeout	Cookie失效时间，单位秒(timeout=0表示立即失效，即清除该名称的Cookie; timeout<0表示生存期与浏览器进程相同)
	 * @param path		Cookie对应的路径
	 */
	public static void writeCookie(HttpServletResponse response, String name, String value, int timeout, String path) {
		writeCookie(response, name, value, timeout, "/", null);
	}	
	
	/**
	 * 写入Cookie对象
	 * 
	 * @param response	HttpServletResponse对象实例
	 * @param name		Cookie名称
	 * @param value		Cookie值
	 * @param timeout	Cookie失效时间，单位秒(timeout=0表示立即失效，即清除该名称的Cookie; timeout<0表示生存期与浏览器进程相同)
	 * @param path		Cookie对应的路径
	 * @param domain	Cookie对应的域名
	 */
	public static void writeCookie(HttpServletResponse response, String name, String value, int timeout, String path, String domain) {
		Cookie sCookie = new Cookie(name, value);
		sCookie.setMaxAge(timeout);
		sCookie.setPath(path);
		if (domain != null)
			sCookie.setDomain(domain);
		response.addCookie(sCookie);
	}		
}
