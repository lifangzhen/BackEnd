package com.tongcard.osf.web.helper;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.ResourceBundle;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;


public class EncryptUtil {
	private static final ResourceBundle rs = ResourceBundle.getBundle("config.finance");
	public static String buildPriKeyStr(PrivateKey priKey) {
		byte[] b = priKey.getEncoded();
		return Base64.encode(b);
	}
	
	public static String buildPubKeyStr(PublicKey pubKey) {
		byte[] b = pubKey.getEncoded();
		return Base64.encode(b);
	}
	public static String signature(String content , String priKeyStr) {
		PrivateKey priKey = null;
		byte[] bprikey = Base64.decode(priKeyStr);
		try {
			PKCS8EncodedKeySpec p = new PKCS8EncodedKeySpec(bprikey);
			KeyFactory m  =  KeyFactory.getInstance("DSA");
			priKey = (PrivateKey)m.generatePrivate(p);
			Signature signalg = Signature.getInstance("DSA");
			signalg.initSign(priKey);
			byte[] message = content.getBytes();
			signalg.update(message);
			byte[] signature = signalg.sign();
			return Base64.encode(signature);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public static boolean verify(String pubKeyStr ,String orgData, String encoded) {
		byte[] raw = Base64.decode(encoded);
		byte[] bpubkey = Base64.decode(pubKeyStr);
		X509EncodedKeySpec p = new X509EncodedKeySpec (bpubkey);
		try {
			KeyFactory m  =  KeyFactory.getInstance("DSA");
			PublicKey pubKey = m.generatePublic(p);
			Signature verifyalg = Signature.getInstance("DSA");
			verifyalg.initVerify(pubKey);
			verifyalg.update(orgData.getBytes());
			if (!verifyalg.verify(raw)) {
				System.out.print("not ");
				return false;
			} else {
				System.out.println("verified");
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	

	public static boolean verify(HashMap map,String merchantCode) {
		String[] interfaceName =(String[]) map.get("interfaceName");
		String[] interfaceVersion =(String[]) map.get("interfaceVersion");
		String[] curType =(String[]) map.get("curType");
		String[] verifyJoinFlag =(String[]) map.get("verifyJoinFlag");
		String[] notifyType =(String[]) map.get("notifyType");
		String[] merURL =(String[]) map.get("merURL");
		String[] resultType =(String[]) map.get("resultType");
		
		String content = interfaceName[0] + interfaceVersion[0] + curType[0] 
				+ verifyJoinFlag[0] + notifyType[0] + merURL[0] + resultType[0] ; 

		String pubkeystr = getPubKey(merchantCode);
		String[] merSignMsg =(String[]) map.get("merSignMsg");
		return verify(pubkeystr , content, merSignMsg[0]);
	}
	
	public static String getPubKey(String merchantCode){
		return rs.getString("pubKey."+merchantCode);
	}
	public static String getPriKey(String merchantCode) {
		return rs.getString("priKey."+merchantCode);
	}
	
	public static void main(String[] args) throws Exception {
		
	}


}
