package com.tongcard.osf.web.helper;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LoginFilter implements Filter {

	private static Log log = LogFactory.getLog(LoginFilter.class);
	
	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest)request;
		String uri = req.getRequestURI();
		if (uri == null)
			return;
		if (!uri.endsWith(".do") && !uri.endsWith(".jsp") && !uri.endsWith("/")) {
			chain.doFilter(request, response);
			return;
		}
		
		HttpSession session = ((HttpServletRequest)request).getSession();
		HttpServletResponse res = ((HttpServletResponse)response);
		String contextPath = ((HttpServletRequest)request).getContextPath();
		if(session.getAttribute("user") == null){
			log.debug("LoginFilter + =========================");
			res.sendRedirect(contextPath + "/login/login.do");
			return;
		}
		chain.doFilter(request, response);

	}

	public void init(FilterConfig config) throws ServletException {
	}

}
