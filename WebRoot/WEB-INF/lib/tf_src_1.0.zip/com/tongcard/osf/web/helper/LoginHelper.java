package com.tongcard.osf.web.helper;


public class LoginHelper {

	private static String cookieDomain = null;
	
	
	public static String getCookieDomain() {
		return cookieDomain;
	}

	public static void setCookieDomain(String cookieDomain) {
		LoginHelper.cookieDomain = cookieDomain;
	}


}
