package com.tongcard.osf.web.helper;

public class MapEntryName {
	public static final String RESULT = "ret";
	public static final String RESULT_INFO = "info";
}	
