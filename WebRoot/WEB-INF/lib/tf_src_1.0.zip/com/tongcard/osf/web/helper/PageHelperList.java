package com.tongcard.osf.web.helper;


import java.util.List;
public class PageHelperList {
	int totalRowsAmount;

	int pageSize = 2;

	int totalPages;

	int currentPage = 1;

	int nextPage;

	int previousPage;

	boolean hasNext;

	boolean hasPrevious;

	boolean first=false;
	
	boolean last=false;
	
	int pageStartRow;

	int pageEndRow;

	private List data;

	public PageHelperList(int totalRows, int currentPage) {
		setPageHelperList(totalRows, currentPage);
	}

	public PageHelperList(int totalRows, int currentPage, int pageSize) {
		this.pageSize = pageSize;
		this.setPageHelperList(totalRows, currentPage);
	}

	public void setPageHelperList(int totalRows, int currentPage) {

		setTotalRowsAmount(totalRows);
		setCurrentPage(currentPage);
	}

	private void setTotalRowsAmount(int rows) {

		if (rows < 0) {
			totalRowsAmount = 0;
		} else {
			totalRowsAmount = rows;
		}

		if (totalRowsAmount % pageSize == 0) {
			this.totalPages = totalRowsAmount / pageSize;
		} else {
			this.totalPages = totalRowsAmount / pageSize + 1;
		}
	}

	private void setCurrentPage(int curPage) {

		if (curPage <= 0) {
			currentPage = 1;
		} else if (curPage > totalPages) {
			currentPage = totalPages;
		} else  {
			currentPage = curPage;
		}

		if (currentPage <= 1) {
			hasPrevious = false;
			first=true;
		} else {
			hasPrevious = true;
		}

		if (currentPage == totalPages) {
			hasNext = false;
			last=true;
		} else {
			hasNext = true;
		}


		nextPage = currentPage + 1;
		previousPage = currentPage - 1;
		
		//-----------------------
		if (currentPage != totalPages) {

			pageStartRow = (currentPage - 1) * pageSize + 1;

		} else {
			pageStartRow = (currentPage - 1) * pageSize + 1;
		}

		pageStartRow -= 0;

		if (pageStartRow < 0) {
			pageStartRow = 0;
		}
		//---------------------------------------------
		
		pageEndRow = pageStartRow + pageSize - 1;

		if (pageEndRow > totalRowsAmount) {
			pageEndRow = totalRowsAmount;
		}

	}
	
	
	
	
	public int getCurrentPage() {
		return currentPage;
	}

	public boolean getHasNext() {
		return hasNext;
	}

	public boolean getHasPrevious() {
		return hasPrevious;
	}

	public int getNextPage() {
		return nextPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public int getPreviousPage() {
		return previousPage;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public int getTotalRowsAmount() {
		return totalRowsAmount;
	}

	public int getPageStartRow() {
		return pageStartRow;
	}

	public int getPageEndRow() {
		return pageEndRow;
	}

	public String description() {
		String description = "Total:" + this.getTotalRowsAmount() + " items "
				+ this.getTotalPages() + " pages,Current page:"
				+ this.currentPage + " Previous " + this.hasPrevious + " Next:"
				+ this.hasNext + " start row:" + this.pageStartRow
				+ " end row:" + this.pageEndRow;
		return description;
	}

	public void setData(List data) {
		this.data = data;
	}

	public List getData() {
		return data;
	}

	public boolean isFirst() {
		return first;
	}

	public void setFirst(boolean first) {
		this.first = first;
	}

	public boolean isLast() {
		return last;
	}

	public void setLast(boolean last) {
		this.last = last;
	}
}