package com.tongcard.osf.web.helper;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;


public abstract class StringUtils {

	private static final char[] multiChar = {'０', '１', '２', '３', '４', '５',
        '６', '７', '８', '９', 'Ｑ', 'Ｗ', 'Ｅ', 'Ｒ', 'Ｔ', 'Ｙ', 'Ｕ', 'Ｉ', 'Ｏ',
        'Ｐ', 'Ａ', 'Ｓ', 'Ｄ', 'Ｆ', 'Ｇ', 'Ｈ', 'Ｊ', 'Ｋ', 'Ｌ', 'Ｚ', 'Ｘ', 'Ｃ',
        'Ｖ', 'Ｂ', 'Ｎ', 'Ｍ', 'ｑ', 'ｗ', 'ｅ', 'ｒ', 'ｔ', 'ｙ', 'ｕ', 'ｉ', 'ｏ',
        'ｐ', 'ａ', 'ｓ', 'ｄ', 'ｆ', 'ｇ', 'ｈ', 'ｊ', 'ｋ', 'ｌ', 'ｚ', 'ｘ', 'ｃ',
        'ｖ', 'ｂ', 'ｎ', 'ｍ', '．', '－', '＿', '＠', ' ', '　'};

    private static final char[] asciiChar = {'0', '1', '2', '3', '4', '5',
            '6', '7', '8', '9', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o',
            'p', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'z', 'x', 'c',
            'v', 'b', 'n', 'm', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o',
            'p', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'z', 'x', 'c',
            'v', 'b', 'n', 'm', '.', '-', '_', '@', ' ', ' '};

    /**
     * Test a string value whether it is an integer number.
     *
     * @param text
     * @return
     */
    public static boolean isInt(String text) {
        if (text == null || text.equals(""))
            return false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '-' && i > 0)
                return false;
            if (c < '0' || c > '9')
                return false;
        }
        return true;
    }

    public static String getMD5(String text) {
        String result = "";
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            byte[] buf = text.getBytes();
            byte[] dig = md5.digest(buf);
            String hex = null;
            for (int i = 0; i < dig.length; i++) {
                int n = dig[i] < 0 ? (256 + dig[i]) : dig[i];
                hex = Integer.toHexString(n);
                if (hex.length() < 2)
                    hex = "0" + hex;
                result += hex;
            }
        } catch (NoSuchAlgorithmException e) {
            //e.printStackTrace();
            result = null;
        }
        return result;
    }

    public static String multiToAscii(String str) {
        for (int i = 0; i < multiChar.length; i++)
            str = str.replace(multiChar[i], asciiChar[i]);

        return str;
    }

    /**
     * byte[]����ת16�����ַ�Сд��
     *
     * @param data
     * @return
     */
    public static String byteToHex(byte[] data) {
        StringBuffer sb = new StringBuffer();
        String hex = null;
        for (int i = 0; i < data.length; i++) {
            int n = data[i] < 0 ? (256 + data[i]) : data[i];
            hex = Integer.toHexString(n);
            if (hex.length() < 2)
                hex = "0" + hex;
            sb.append(hex);
        }
        return sb.toString();
    }
    //public static boolean byteToHex(int iPrivilegeID) {

    public static String getOrderNum(Date dorderDate) {
        String orderNum = "";
        SimpleDateFormat sFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        orderNum = sFormat.format(dorderDate);
        //����6λ�漼��һ���ڲ��ظ�

        return orderNum;
    }

    /**
     * ��ȡָ��λ��������Сд��
     *
     * @param int
     * @return
     */
    public static String getRandomNum(int length) {
        Random ram = new Random();
        int inum = Math.abs(ram.nextInt());
        String numt = String.valueOf(inum);
        StringBuffer sbbase = new StringBuffer("0");
        for (int i = 0; i < length; i++) {
            sbbase.append("0");
        }
        String sbase = sbbase.toString();
        String snum = null;
        if (numt.length() < length) {
            snum = sbase.substring(0, length - numt.length()) + numt;
        } else {
            snum = numt.substring(0, length);
        }
        return snum;
    }

    public static String getOrderNum() {
        Date dorderDate = new Date();
        return getOrderNum(dorderDate);
    }
    
    public static boolean checkCharOrNum(String str)
    {
    	String check = "^\\w{6,16}$";
    	boolean bool = java.util.regex.Pattern.matches(check, str);
    	return bool;
    }
    
    public static boolean checkMail(String str)
    {
    	
    	if(str == "")
            return false;
        if (str.substring(0) == "." || str.substring(0) == "@" || str.indexOf('@', 0) == -1
            || str.indexOf('.', 0) == -1 || str.lastIndexOf("@") == str.length()-1 || str.lastIndexOf(".") == str.length()-1)
            return false;
        else
            return true;
    	
    	/*String check = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$"; 
    	boolean bool = java.util.regex.Pattern.matches(check, str);
    	return bool;*/
    }

    public static boolean checkCardNum(String str)
    {
    	String check = "^\\d{16}$"; 
    	boolean bool = java.util.regex.Pattern.matches(check, str);
    	return bool;
    }

    public static boolean checkCardPass(String str)
    {
    	String check = "^\\d{6}$"; 
    	boolean bool = java.util.regex.Pattern.matches(check, str);
    	return bool;
    }

    public static void main(String[] args) {
    	String temp = "111111111122111";
    	System.out.println(checkCardNum(temp));
	}

}
