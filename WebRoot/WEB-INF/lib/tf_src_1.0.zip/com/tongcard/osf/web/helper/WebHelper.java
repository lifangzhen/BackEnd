package com.tongcard.osf.web.helper;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

public class WebHelper {
    /*
      * ��request��ȡ�����в������һ��Map������
      */
    public static Map getRequestMap(HttpServletRequest request) {
        Map<String, String> newMap = new HashMap<String, String>();

        Enumeration enumeration = request.getParameterNames();
        while (enumeration.hasMoreElements()) {
            String param = (String) enumeration.nextElement();
            String value = request.getParameter(param);
            newMap.put(param, value);
        }
        return newMap;
    }
}
