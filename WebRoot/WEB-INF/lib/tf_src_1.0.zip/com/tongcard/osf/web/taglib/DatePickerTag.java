/*
Copyright (C) 2007 TongCard Technologies, Inc. All Rights Reserved. 

Author: Lin Yong
Created: 2007-12-10
TODO
*/
package com.tongcard.osf.web.taglib;
import java.io.Writer;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import org.apache.commons.lang.math.RandomUtils;
import com.tongcard.osf.util.DateUtils;
import org.apache.struts2.views.jsp.StrutsBodyTagSupport;
/**
 * 
 */
public class DatePickerTag extends StrutsBodyTagSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1183414645972997956L;

	public static final String CAL_PRE = "cal_";

	public static final String ANCHOR_PRE = "anchor_";

	public static final String FORMAT = "MM/dd/yyyy";

	public static final String TIMER_PRE = "timer_";

	public static final String DIV_PRE = "date_div";

	public static final String IMG_PATH = "/images/time.gif";

	public static final String SCRIPT_PATH = "/scripts/DatePicker.js";
	
	//protected static MessageResources messages = MessageResources.getMessageResources("org.apache.struts.taglib.html.LocalStrings");

	private String value;

	private String imgPath;

	private String scriptPath;

	private String weekStartDay;

	private String disabledDateFrom;

	private String disabledDateTo;

	private String yearOffset;

	private String pattern="yyyy-MM-dd";

	private String property;

	private String calendarName;

	private String anchorName;

	private String name;

	private String title;

	private String timerName;

	private String divName;

	private String hideDelay = "5000";

	private String isDisableRegion = "false";

	private String patternKey;

	private String bundle;
	
	private String styleClass;

	protected String size ;

	public String getSize() {
		return this.size;
	}

	public void setSize(String size) {
		this.size = size;
	}
	
	public String getStyleClass() {
		return styleClass;
	}

	public void setStyleClass(String styleClass) {
		this.styleClass = styleClass;
	}

	/**
	 * @return the patternKey
	 */
	public String getPatternKey() {
		return this.patternKey;
	}

	/**
	 * @param patternKey
	 *            the patternKey to set
	 */
	public void setPatternKey(String patternKey) {
		this.patternKey = patternKey;
	}

	public void setIsDisableRegion(String isDisableRegion) {
		this.isDisableRegion = isDisableRegion;
	}

	public String getIsDisableRegion() {
		return isDisableRegion;
	}

	public void setHideDelay(String hideDelay) {
		this.hideDelay = hideDelay;
	}

	public String getHideDelay() {
		return this.hideDelay;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTitle() {
		return this.title;
	}

	public void setName(String formId) {
		this.name = formId;
	}

	public String getName() {
		return this.name;
	}

	public void setProperty(String name) {
		this.property = name;
		String suffix = String.valueOf(RandomUtils.nextInt());
		this.calendarName = CAL_PRE + suffix;
		this.anchorName = ANCHOR_PRE + suffix;
		this.timerName = TIMER_PRE + suffix;
		this.divName = DIV_PRE + suffix;
	}

	public String getProperty() {
		return this.property;
	}

	public void setWeekStartDay(String weekStartDay) {
		this.weekStartDay = weekStartDay;
	}

	public String getWeekStartDay() {
		return this.weekStartDay;
	}

	public void setDisabledDateFrom(String disabledDateFrom) {

		this.disabledDateFrom = disabledDateFrom;
	}

	public String getDisabledDateFrom() {
		return this.disabledDateFrom;
	}

	public void setDisabledDateTo(String disabledDateTo) {
		this.disabledDateTo = disabledDateTo;
	}

	public String getDisabledDateTo() {
		return this.disabledDateTo;
	}

	public void setYearOffset(String yearOffset) {
		this.yearOffset = yearOffset;
	}

	public String getYearOffset() {
		return this.yearOffset;
	}

	public void setPattern(String format) {
		this.pattern = format;
	}

	public String getPattern() {
		return this.pattern;
	}

	/**
	 * 
	 */
	public DatePickerTag() {
		super();
	}

	public int doEndTag() throws JspException {
		Writer out = this.pageContext.getOut();
		HttpServletRequest request = (HttpServletRequest) this.pageContext
				.getRequest();
		this.scriptPath = request.getContextPath() + SCRIPT_PATH;
		this.imgPath = (request).getContextPath() + IMG_PATH;
		StringBuffer content = new StringBuffer();
		// Inculde the script

		content.append("<script type=\"text/javascript\" src=\"").append(
				this.scriptPath).append("\">").append("</script>");
		// Write style
		content
				.append("<SCRIPT LANGUAGE=\"JavaScript\">document.write(getCalendarStyles());</SCRIPT>\n");
		// Write div
		content
				.append("<div id=\"")
				.append(this.divName)
				.append(
						"\" style=\"position: absolute; visibility: hidden;z-index: 20;background-color: white;\" onMouseOut=\"set")
				.append(this.timerName).append("();\" onMouseOver=\"clear")
				.append(this.timerName).append("();\"></div>\n");
		// Write js function
		content.append(" <SCRIPT LANGUAGE=\"JavaScript\"> \n");
		content.append(" var ").append(this.calendarName).append(
				" = new CalendarPopup(\"").append(this.divName).append(
				"\"); \n");
		content.append(this.calendarName).append(".showNavigationDropdowns();");

		content.append(" var ").append(this.timerName).append("; \n");
		// Function set timer
		content.append(" function set").append(this.timerName).append("(){\n");
		content.append("clear").append(this.timerName).append("();\n");
		content.append(" \t").append(this.timerName).append(
				"=setTimeout('document.getElementById(\"").append(this.divName)
				.append("\").style.visibility=\"hidden\";',").append(
						this.hideDelay).append(");\n}\n");

		// Function clear timer
		content.append(" function clear").append(this.timerName)
				.append("(){\n");
		content.append(" \tclearTimeout(").append(this.timerName).append(
				");\n}\n");

		// Set parameters
		content.append(" ").append(this.calendarName)
				.append(".offsetX = 0; \n");
		if (this.weekStartDay != null && !"".equals(this.weekStartDay)) {
			content.append(this.calendarName).append(".setWeekStartDay(")
					.append(this.weekStartDay).append("); ").append('\n');
		}
		// set pattern
		if (patternKey != null && !"".equals(this.patternKey)) {
			// Custom format, first look in the specified bundle
			String datePattern = null;
			//datePattern = LayoutUtils.getLabel(pageContext, bundle, patternKey,
			//		null, true);
			if (datePattern == null) {
				// If not found, look in the default bundle.
			//	datePattern = LayoutUtils.getLabel(pageContext, patternKey,
			//			null);
			}
			if (datePattern != null)
				pattern = datePattern;
		}
		if (this.pattern == null || "".equals(this.pattern.trim())) {
			this.pattern = FORMAT;
		}
		// Set disable date region
		try{
		this.disabledDateFrom = this.transferFormat(this.disabledDateFrom,
				this.pattern, FORMAT);
		this.disabledDateTo = this.transferFormat(this.disabledDateTo,
				this.pattern, FORMAT);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		if (this.isDisableRegion == null
				|| this.isDisableRegion.trim().equals("")) {
			this.isDisableRegion = "false";
		}
		if (this.isDisableRegion.equalsIgnoreCase("false")
				|| this.isDisableRegion.equalsIgnoreCase("no")) {
			if (this.disabledDateFrom != null
					&& !"".equals(this.disabledDateFrom.trim())) {
				content.append(this.calendarName)
						.append(".addDisabledDates(\"").append(
								this.disabledDateFrom).append("\", null); ")
						.append('\n');
			}
			if (this.disabledDateTo != null
					&& !"".equals(this.disabledDateTo.trim())) {
				content.append(this.calendarName).append(
						".addDisabledDates(null, \"").append(
						this.disabledDateTo).append("\"); ").append('\n');
			}
		} else if (this.isDisableRegion.equalsIgnoreCase("true")
				|| this.isDisableRegion.equalsIgnoreCase("no")) {
			if (this.disabledDateFrom != null
					&& !"".equals(this.disabledDateFrom.trim())) {
				content.append(this.calendarName)
						.append(".addDisabledDates(\"");
				if (this.disabledDateTo != null
						&& !"".equals(this.disabledDateTo.trim())) {
					content.append(this.disabledDateFrom).append("\", \"");
					content.append(this.disabledDateTo);
					content.append("\"); ").append('\n');
				} else {
					content.append(this.disabledDateFrom).append("\",");
					content.append("null");
					content.append("); ").append('\n');
				}
			} else {
				content.append(this.calendarName).append(
						".addDisabledDates(null,\"");
				if (this.disabledDateTo != null
						&& !"".equals(this.disabledDateTo.trim())) {
					content.append(this.disabledDateTo);
					content.append("\"); ").append('\n');
				} else {
					content.append("null");
					content.append("); ").append('\n');
				}
			}
		}

		if (this.yearOffset != null && !"".equals(this.yearOffset.trim())) {
			content.append(this.calendarName).append(
					".setYearSelectStartOffset(").append(this.yearOffset)
					.append("); ").append('\n');
		}
		Date date=(Date)findValue(this.property);
		
		value=date == null ? "" : DateUtils.toString(date, pattern);
		int textSize = this.pattern.length()+1;
		content.append('\n').append(" </SCRIPT> ");
        content.append('\n').append("<INPUT TYPE=\"text\" class=\"ipt_of\" onfocus=\"this.className='ipt_on';\"	onblur=\"this.className='ipt_of';\" maxlength=\"16\" style=\"width:70px;\" readonly=\"readonly\" NAME=\"").append(
				this.property).append("\" VALUE=\"").append(
				value != null ? value : "").append("\" SIZE=").append(textSize).append(" onClick=\"").append(
						this.calendarName).append(
						".select(document.getElementById('").append(
						this.property).append("'),'").append(this.anchorName)
				.append("','").append(this.pattern).append(
						"'); return false;\"")
				.append(">").append('\n');
				
				
		content.append("<img style=\" cursor: hand;\" src=\"").append(imgPath)
				.append("\"").append(" onmouseup=\"set").append(this.timerName)
				.append("();\" ").append(" onClick=\"").append(
						this.calendarName).append(
						".select(document.getElementById('").append(
						this.property).append("'),'").append(this.anchorName)
				.append("','").append(this.pattern).append(
						"'); return false;\" ").append("\" NAME=\"")
				.append(this.anchorName).append("\" ID=\"").append(
						this.anchorName).append("\"/>").append('\n');
		try {
			out.write(content.toString());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return EVAL_PAGE;
	}

	/**
	 * @return the bundle
	 */
	public String getBundle() {
		return this.bundle;
	}

	/**
	 * @param bundle
	 *            the bundle to set
	 */
	public void setBundle(String bundle) {
		this.bundle = bundle;
	}

	/**
	 * @param dateText
	 * @param originFormat
	 * @param resultFormat
	 * @return
	 */
	private String transferFormat(String dateText, String originFormat,
			String resultFormat) throws Exception{
		if (dateText != null && dateText.trim().length() >= 10) {
			Date date = DateUtils.fromString(dateText, originFormat);
			return DateUtils.toString(date, resultFormat);
		} else {
			return null;
		}
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return this.value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
}