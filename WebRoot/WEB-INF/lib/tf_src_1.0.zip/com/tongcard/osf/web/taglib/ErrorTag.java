package com.tongcard.osf.web.taglib;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

/**
 * 类说明：错误信息显示代码封装<br>
 * 创建时间：2008-1-16<br>
 * 
 * @author 高一波<br>
 */
public class ErrorTag extends TagSupport {
	private static final long serialVersionUID = 1L;
	private String id;
	public int doStartTag() throws JspException {
		JspWriter out = pageContext.getOut();
		String context=((HttpServletRequest)pageContext.getRequest()).getContextPath();
		try {
			StringBuffer sb=new StringBuffer();
			sb.append("<div id=\"ediv_").append(id).append("\" style=\"text-align:left; position:absolute; height:100%; width:300px; z-index: 2;display: none; margin-top:-10px;\">");
			sb.append("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">");
				sb.append("<tr>");
					sb.append("<td width=\"4%\">");
						sb.append("<img src=\"").append(context).append("/images/no.jpg\" />");
					sb.append("</td>");
					sb.append("<td width=\"96%\">");
						sb.append("<table width=\"98%\" border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\">");
							sb.append("<tr>");
								sb.append("<td width=\"3%\">");
									sb.append("<img src=\"").append(context).append("/images/no01.jpg\" width=\"15\" height=\"46\" />");
								sb.append("</td>");
								sb.append("<td width=\"94%\" valign=\"middle\" class=\"Statusbg\" id=\"").append(id).append("\">");
								sb.append("</td>");
								sb.append("<td width=\"3%\">");
									sb.append("<img src=\"").append(context).append("/images/no03.jpg\" width=\"8\" height=\"46\" />");
								sb.append("</td>");
							sb.append("</tr>");
						sb.append("</table>");
					sb.append("</td>");
				sb.append("</tr>");
			sb.append("</table>");
			sb.append("</div>");
			out.print(sb.toString());
		} catch (Exception ex) {
			throw new JspException(ex);
		}
		return SKIP_BODY;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}



}
