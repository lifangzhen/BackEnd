package com.tongcard.osf.web.virtualSession;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;;

/**
 * 方便的Session工具类
 * @author Lizt
 *
 */
public class SessionUtil {
	
	private final static  ThreadLocal<HttpSession> sessionLocal = new ThreadLocal<HttpSession>();
	private final static  ThreadLocal<HttpServletRequest> requestLocal = new ThreadLocal<HttpServletRequest>(); 
	
	public static void setSession(HttpSession session ){
		sessionLocal.set(session);
	}
	public static void clearSession(){
		sessionLocal.remove();
	}
	public static HttpSession getSession(){
		return (HttpSession)sessionLocal.get();
	}
	
	public static void setRequest(HttpServletRequest request ){
		requestLocal.set(request);
	}
	public static void clearRequest(){
		requestLocal.remove();
	}
	public static HttpServletRequest getRequest(){
		return (HttpServletRequest)requestLocal.get();
	}
	
	public static HttpSession getSession(boolean create){
		HttpSession s = (HttpSession)sessionLocal.get();
		if(create && s == null){
			HttpServletRequest r = (HttpServletRequest)requestLocal.get();
			s = r.getSession(true);
			setSession(s);
		}
		return s;
	}
	public static void invalidateSession(){
		HttpSession s = (HttpSession)sessionLocal.get();
		if(s != null){
			s.invalidate();
		}
	}
	/**
	 * 从Session中取值
	 * @param name
	 * @return
	 */
	public static Object getAttribute(String name) {
		HttpSession session = (HttpSession) sessionLocal.get();
		if (session == null) {
			return null;
		}
		else{
			return session.getAttribute(name);
		}
	}

	/**
	 * 向Session中放值
	 * @param name
	 * @param value
	 */
	public static void setAttribute(String name,Object value) {
		HttpSession session = (HttpSession) sessionLocal.get();
		if (session == null) {
			;
		}
		else{
			session.setAttribute(name,value);
		}
	}  
	public static String USER_ID;
}
