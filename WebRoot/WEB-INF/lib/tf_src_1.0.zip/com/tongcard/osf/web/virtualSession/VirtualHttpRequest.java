package com.tongcard.osf.web.virtualSession;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.Principal;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletInputStream;
import javax.servlet.http.Cookie;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class VirtualHttpRequest implements HttpServletRequest {
	private HttpServletRequest prototypeRequest = null;
	private HttpServletResponse prototypeResponse = null;
	private VirtualSession vs = null;

	public VirtualHttpRequest(HttpServletRequest prototypeRequest, HttpServletResponse prototypeResponse) {
		this.prototypeRequest = prototypeRequest;
		this.prototypeResponse = prototypeResponse;
	}
	
	public HttpSession getSession() {
		return getSession(false);
	}

	public HttpSession getSession(boolean create) {
		if(vs == null)
			vs = VirtualSession.getVirtualSession(prototypeRequest,prototypeResponse, create);
		return vs;
	}
	
	public Object getAttribute(String arg0) {
		return prototypeRequest.getAttribute(arg0);
	}

	public Enumeration getAttributeNames() {
		return prototypeRequest.getAttributeNames();
	}

	public String getAuthType() {
		return prototypeRequest.getAuthType();
	}

	public String getCharacterEncoding() {
		return prototypeRequest.getCharacterEncoding();
	}

	public int getContentLength() {
		return prototypeRequest.getContentLength();
	}

	public String getContentType() {
		return prototypeRequest.getContentType();
	}

	public String getContextPath() {
		return prototypeRequest.getContextPath();
	}

	public Cookie[] getCookies() {
		return prototypeRequest.getCookies();
	}

	public long getDateHeader(String arg0) {
		return prototypeRequest.getDateHeader(arg0);
	}

	public String getHeader(String arg0) {
		return prototypeRequest.getHeader(arg0);
	}

	public Enumeration getHeaderNames() {
		return prototypeRequest.getHeaderNames();
	}

	public Enumeration getHeaders(String arg0) {
		return prototypeRequest.getHeaders(arg0);
	}

	public ServletInputStream getInputStream() throws IOException {
		return prototypeRequest.getInputStream();
	}

	public int getIntHeader(String arg0) {
		return prototypeRequest.getIntHeader(arg0);
	}

	public String getLocalAddr() {
		return prototypeRequest.getLocalAddr();
	}

	public Locale getLocale() {
		return prototypeRequest.getLocale();
	}

	public Enumeration getLocales() {
		return prototypeRequest.getLocales();
	}

	public String getLocalName() {
		return prototypeRequest.getLocalName();
	}

	public int getLocalPort() {
		return prototypeRequest.getLocalPort();
	}

	public String getMethod() {
		return prototypeRequest.getMethod();
	}

	public String getParameter(String arg0) {
		return prototypeRequest.getParameter(arg0);
	}

	public Map getParameterMap() {
		return prototypeRequest.getParameterMap();
	}

	public Enumeration getParameterNames() {
		return prototypeRequest.getParameterNames();
	}

	public String[] getParameterValues(String arg0) {
		return prototypeRequest.getParameterValues(arg0);
	}

	public String getPathInfo() {
		return prototypeRequest.getPathInfo();
	}

	public String getPathTranslated() {
		return prototypeRequest.getPathTranslated();
	}

	public String getProtocol() {
		return prototypeRequest.getProtocol();
	}

	public String getQueryString() {
		return prototypeRequest.getQueryString();
	}

	public BufferedReader getReader() throws IOException {
		return prototypeRequest.getReader();
	}

	public String getRealPath(String arg0) {
		return prototypeRequest.getRealPath(arg0);
	}

	public String getRemoteAddr() {
		return prototypeRequest.getRemoteAddr();
	}

	public String getRemoteHost() {
		return prototypeRequest.getRemoteHost();
	}

	public int getRemotePort() {
		return prototypeRequest.getRemotePort();
	}

	public String getRemoteUser() {
		return prototypeRequest.getRemoteUser();
	}

	public RequestDispatcher getRequestDispatcher(String arg0) {
		return prototypeRequest.getRequestDispatcher(arg0);
	}

	public String getRequestedSessionId() {
		return prototypeRequest.getRequestedSessionId();
	}

	public String getRequestURI() {
		return prototypeRequest.getRequestURI();
	}

	public StringBuffer getRequestURL() {
		return prototypeRequest.getRequestURL();
	}

	public String getScheme() {
		return prototypeRequest.getScheme();
	}

	public String getServerName() {
		return prototypeRequest.getServerName();
	}

	public int getServerPort() {
		return prototypeRequest.getServerPort();
	}

	public String getServletPath() {
		return prototypeRequest.getServletPath();
	}

	public Principal getUserPrincipal() {
		return prototypeRequest.getUserPrincipal();
	}

	public boolean isRequestedSessionIdFromCookie() {
		return prototypeRequest.isRequestedSessionIdFromCookie();
	}

	public boolean isRequestedSessionIdFromUrl() {
		return prototypeRequest.isRequestedSessionIdFromUrl();
	}

	public boolean isRequestedSessionIdFromURL() {
		return prototypeRequest.isRequestedSessionIdFromURL();
	}

	public boolean isRequestedSessionIdValid() {
		return prototypeRequest.isRequestedSessionIdValid();
	}

	public boolean isSecure() {
		return prototypeRequest.isSecure();
	}

	public boolean isUserInRole(String arg0) {
		return prototypeRequest.isUserInRole(arg0);
	}

	public void removeAttribute(String arg0) {
		prototypeRequest.removeAttribute(arg0);
	}

	public void setAttribute(String arg0, Object arg1) {
		prototypeRequest.setAttribute(arg0, arg1);
	}

	public void setCharacterEncoding(String arg0) throws UnsupportedEncodingException {
		prototypeRequest.setCharacterEncoding(arg0);
	}
	

}
