package com.tongcard.osf.web.virtualSession;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.tongcard.osf.util.EncryptUtil;

/**
 * 类说明: 实现了HttpSession接口，把对象都放入cookie中管理.
 * 
 * @author linfengqi
 * @version 1.0, Mar 17, 2008
 */
public class VirtualSession implements HttpSession {
	protected HttpServletRequest request;

	protected HttpServletResponse response;
	
	protected String userAgent = null;
	
	protected String host = null;

	protected Map<String, Cookie> cookieMap = new  HashMap<String, Cookie>();
	
	protected Map<String, Object> attributeMap = new  HashMap<String, Object>();

	protected int maxInactiveInterval = DEFAULT_MAX_INACTIVE_INTERVAL;;

	protected VirtualSession(HttpServletRequest request,
			HttpServletResponse response) {
		this.request = request;
		this.response = response;

		userAgent = request.getHeader(HEADER_MESSAGE);
		host = request.getRemoteAddr();
		
		Cookie[] cs = this.request.getCookies();
		if(cs != null)
			for (Cookie c : cs) {
				cookieMap.put(c.getName(), c);
			}
	}

	/**
	 * 获取当前虚拟的Session
	 * 
	 * @param request
	 * @param response
	 * @param create 是否创建
	 * @return
	 */
	public static VirtualSession getVirtualSession(HttpServletRequest request,
			HttpServletResponse response, boolean create) {
		//创建虚拟Session
		VirtualSession vs  = new VirtualSession(request, response);
		
		//判断是否需要创建一个新的
		if(create){
//			判断Session是否存在和有效
			if(!vs.verifySession()){
				vs.initNewSession();
			}
		}
		else{
			//判断Session是否存在和有效
			if(!vs.verifySession()){
				return null;
			}
		}
		return vs;
	}

	private void initNewSession() {
		log.debug("initialize a new session....................");
		Calendar calendar = Calendar.getInstance();
		long createTime = calendar.getTimeInMillis();
		String time = String.valueOf(createTime);
		putCookie(SESSION_CREATE_TIME, time);
		putCookie(LAST_ACCESS_TIME, time);
		
		String sessionId = genSessionId(time);
		putCookie(SESSION_ID, sessionId);
		
		
	}

	/*
	 * Returns the object bound with the specified name in this session, or null
	 * if no object is bound under the name.
	 */
	public Object getAttribute(String key) {
		
		if(this.attributeMap.containsKey(key)){
			return this.attributeMap.get(key);
		}
		Object r = null;
		
		String name = addPrefixToName(key);

		Cookie c = this.cookieMap.get(name);
		if(c == null)
			r = null;
		String value = c.getValue();
		if(value == null)
			r = value;
		//判断是否是多部分组成
		if(!value.startsWith(MULTI_COOKIE_PART_FLAG)){
			r = EncryptUtil.base64StringToObject(value);
		}
		else{
			int size = Integer.parseInt(value.substring(MULTI_COOKIE_PART_FLAG.length()-1));
			StringBuffer result = new StringBuffer();
			for(int i = 0; i < size; i++){
				result.append(this.cookieMap.get(addPrefixToName(key + '[' + i + ']')).getValue());
			}
			r = EncryptUtil.base64StringToObject(result.toString());
		}
		this.attributeMap.put(key, r);
		return r;
	}
	/*
	 * Returns an Enumeration of String objects containing the names of all the
	 * objects bound to this session.
	 */
	public Enumeration getAttributeNames() {
		StringBuffer sb = new StringBuffer();
		for (Cookie c : this.cookieMap.values()) {
			if (c.getName().startsWith(PREFIX)) {
				String name = removePrefixFromName(c.getName());
				sb.append(name + COOKIE_DELIM);
			}
		}
		return new StringTokenizer(sb.toString(), COOKIE_DELIM);
	}

	/*
	 * Returns a string containing the unique identifier assigned to this
	 * session.
	 */
	public String getId() {
		//return this.request.getSession(true).getId(); 
		return this.getExistSessionId();
	}

	/*
	 * Returns the last time the client sent a request associated with this
	 * session, as the number of milliseconds since midnight January 1, 1970
	 * GMT, and marked by the time the container received the request.
	 */
	public long getLastAccessedTime() {
		return Long.parseLong(this.getLastAccessTime());
	}

	/*
	 * Returns the maximum time interval, in seconds, that the servlet container
	 * will keep this session open between client accesses.
	 */
	public int getMaxInactiveInterval() {
		return maxInactiveInterval;
	}

	/*
	 * Returns the ServletContext to which this session belongs.
	 */
	public ServletContext getServletContext() {
		return request.getSession(true).getServletContext();
	}

	@Deprecated
	public HttpSessionContext getSessionContext() {
		return request.getSession().getSessionContext();
	}

	@Deprecated
	public Object getValue(String key) {
		return getAttribute(key);
	}

	@Deprecated
	public String[] getValueNames() {
		List<String> names = new ArrayList<String>();
		for (Cookie c : this.cookieMap.values()) {
			if (c.getName().startsWith(PREFIX)) {
				String name = removePrefixFromName(c.getName());
				names.add(name);
			}
		}
		return (String[]) names.toArray();
	}

	/*
	 * Invalidates this session then unbinds any objects bound to it.
	 */
	public void invalidate() {
		this.clear();
	}

	/*
	 * Returns true if the client does not yet know about the session or if the
	 * client chooses not to join the session.
	 */
	public boolean isNew() {
		return (this.getExistSessionId()!= null && this.getLastAccessTime() == null || this.getCreateTime().equals(this.getLastAccessTime()));
	}

	@Deprecated
	public void putValue(String key, Object value) {
		setAttribute(key, value);
	}

	/*
	 * Removes the object bound with the specified name from this session.
	 */
	public void removeAttribute(String key) {
		this.clearAttribute(key);
	}

	@Deprecated
	public void removeValue(String key) {
		removeAttribute(key);
	}

	/*
	 * Binds an object to this session, using the name specified.
	 */
	public void setAttribute(String key, Object value) {
		this.attributeMap.put(key, value);
		if (!(value instanceof Serializable))
			throw new RuntimeException("The object must be serializable");
		String cookieValue = EncryptUtil.objectToBase64String(value);
		int length = cookieValue.length();
		if (length > COOKIE_LIMIT_SIZE) {
			int multi = length / COOKIE_LIMIT_SIZE;
			if (length % COOKIE_LIMIT_SIZE != 0)
				multi = multi + 1;
			StringBuffer total = new StringBuffer();
			total.append(MULTI_COOKIE_PART_FLAG).append(multi);
			for (int i = 0; i < multi; i++) {
				String cookiePartName = key + '[' + i + ']';
				int begin = COOKIE_LIMIT_SIZE * i;
				int end = COOKIE_LIMIT_SIZE * (i + 1);
				if (i == multi - 1)
					end = cookieValue.length();

				String cookiePartValue = cookieValue.substring(begin, end);
				putCookie(addPrefixToName(cookiePartName), cookiePartValue);
			}
			putCookie(addPrefixToName(key), total.toString());
		}
		else
			putCookie(addPrefixToName(key), cookieValue);
	}

	/*
	 * Specifies the time, in seconds, between client requests before the
	 * servlet container will invalidate this session.
	 */
	public void setMaxInactiveInterval(int maxInactiveInterval) {
		this.maxInactiveInterval = maxInactiveInterval;
	}

	public void updateAccessTime() {
		Calendar calendar = Calendar.getInstance();
		long lastAccessTime = calendar.getTimeInMillis();
		this.putCookie(LAST_ACCESS_TIME, String.valueOf(lastAccessTime));
	}

	public void clear(){
		for(Iterator<Map.Entry<String,Cookie>> iter = this.cookieMap.entrySet().iterator(); iter.hasNext();){
			Map.Entry<String,Cookie> e = iter.next();
			if(e.getKey().startsWith(PREFIX)){
				clearCookie(e.getValue());
				iter.remove();
			}
		}
	}
	private void clearAttribute(String cookieName){
		Cookie c = this.cookieMap.get(this.addPrefixToName(cookieName));
		if(c != null){
			clearCookie(c);
		}
		
	}
	
	private void clearCookie(Cookie cookie){
		cookie.setMaxAge(0);
		response.addCookie(cookie);
	}
	
	private void putCookie(String key, String value){

		Cookie cookie = new Cookie(key, value);
		cookie.setPath(request.getContextPath());
		//cookie.setMaxAge(maxInactiveInterval);
		
		this.cookieMap.put(key, cookie);
		response.addCookie(cookie);
	}
	/**
	 * 验证Session是否合法
	 * @return
	 */
	private  boolean verifySession() {
		if(!isExistSession())
			return false;
		String time = getCreateTime();
		if(time == null)
			return false;
		return (genSessionId(time).equals(getExistSessionId()));
	}
	/**
	 * 生成Session
	 * @param time
	 * @return
	 */
	private String genSessionId(String time){
		String expr = this.userAgent + MIX_CODE + this.host + time;
		String result = EncryptUtil.encode(expr, ALGORITHM);
		return result;
	}
	/**
	 * 获得Session创建时间
	 * @return
	 */
	private String getCreateTime(){
		Cookie c = this.cookieMap.get(SESSION_CREATE_TIME);
		if(c != null){
			return c.getValue();
		}
		return null;
	}
	/**
	 * 获得最近一次访问时间
	 * @return
	 */
	private String getLastAccessTime(){
		Cookie c = this.cookieMap.get(LAST_ACCESS_TIME);
		if(c != null){
			return c.getValue();
		}
		return null;
	}
	/**
	 * 获得现有Session
	 * @return
	 */
	private String getExistSessionId(){
		Cookie c = this.cookieMap.get(SESSION_ID);
		if(c != null){
			return c.getValue();
		}
		return null;
	}
	/**
	 * 判断是否存在Session
	 * @param request
	 * @return
	 */
	private boolean isExistSession() {

		Cookie c = this.cookieMap.get(SESSION_ID);
		if(c == null)
			return false;
		else
			return true;
	}

	private static String addPrefixToName(String name) {
		return PREFIX + name;
	}

	private String removePrefixFromName(String name) {
		return name.substring(name.indexOf(PREFIX) + 8);
	}
	
	public long getCreationTime() {
		return Long.parseLong(this.getCreateTime());
	}
	
	protected final static Log log = LogFactory.getLog(VirtualSession.class);

	public final static int DEFAULT_MAX_INACTIVE_INTERVAL = 60 * 60 * 1000 * 24;//30 minutes
	
	public final static int COOKIE_LIMIT_SIZE = 4 * 1024; //4KB

	

	public final static String MULTI_COOKIE_PART_FLAG = "multicookie:";

	public final static String COOKIE_DELIM = ",";

	public final static String PREFIX = "_s_";
	
	public final static String LAST_ACCESS_TIME = "_session_lastAccessTime";
	
	public final static String SESSION_ID = "_session_id";
	
	public final static String SESSION_CREATE_TIME = "_session_CreateTime";

	private final static String HEADER_MESSAGE = "user-agent";

	private final static String ALGORITHM = "MD5";

	private final static String MIX_CODE = "q<iu(&(*@!&#4$ew%^&*(%#$fa>fa";

}
