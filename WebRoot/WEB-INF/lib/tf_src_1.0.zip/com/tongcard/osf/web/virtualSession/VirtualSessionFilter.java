package com.tongcard.osf.web.virtualSession;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class VirtualSessionFilter implements Filter {

	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		try{
			HttpServletRequest hsr = (HttpServletRequest) request;
			VirtualHttpRequest r = new VirtualHttpRequest((HttpServletRequest) request, (HttpServletResponse)response);
			SessionUtil.setRequest(r);
			SessionUtil.setSession(r.getSession());
			chain.doFilter(request, response);
		}
		finally{
			if(SessionUtil.getSession() != null)
				((VirtualSession)SessionUtil.getSession()).updateAccessTime();
			SessionUtil.clearSession();
			SessionUtil.clearRequest();
		}
	}

	public void init(FilterConfig arg0) throws ServletException {
		
	}

}
